<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * The whole purpose of this plugin: update the plugins it is told to manage.
 *
 * Runs under UISP's `.ucrm-plugin-running` lock — but that lock is OURS, not the
 * targets'. That is precisely what lets PluginFacade::handleUpdate() accept:
 * it refuses only when the plugin *being updated* is running. See Fleet.
 */

require_once __DIR__ . "/bootstrap.php";

use Archous\Updater\Config;
use Archous\Updater\Fleet;

if (Config::get("update_url") === null) {
    error_log("(cron) no update_url configured — nothing to do");
    exit(0);
}

$managed = Fleet::managed();

if ($managed === []) {
    error_log("(cron) no managed plugins configured — nothing to do");
    exit(0);
}

error_log(sprintf("(cron) checking %d plugin(s): %s", count($managed), implode(", ", $managed)));

foreach (Fleet::updateAll() as $r) {
    $line = sprintf("(update:%s) %s", $r["plugin"], $r["action"]);

    if ($r["from"] !== null && $r["to"] !== null) {
        $line .= sprintf(" %s -> %s", $r["from"], $r["to"]);
    }

    if ($r["detail"] !== null) {
        $line .= sprintf(" — %s", $r["detail"]);
    }

    error_log($line);
}
