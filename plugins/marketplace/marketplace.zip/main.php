<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * The whole purpose of this plugin: update the plugins it is told to manage.
 *
 * Runs under UISP's `.ucrm-plugin-running` lock — but that lock is OURS, not the
 * targets'. That is precisely what lets PluginFacade::handleUpdate() accept:
 * it refuses only when the plugin *being updated* is running. See Fleet.
 */

require_once __DIR__ . "/bootstrap.php";

use SpaethTech\Ucrm\Plugin;
use Archous\Updater\Fleet;
use SpaethTech\Ucrm\Log;

if (Plugin::get("update_url") === null) {
    Log::write("cron", "no update_url configured — nothing to do");
    exit(0);
}

$managed = Fleet::managedRefs();

if ($managed === []) {
    Log::write("cron", "no managed plugins configured — nothing to do");
    exit(0);
}

// Log the REF, not just the name. "checking provisioner-v3" and
// "checking provisioner-v3@testing" produce very different updates, and after the
// fact the log is the only record of which one this run was tracking.
Log::writef(
    "(cron) checking %d plugin(s): %s",
    count($managed),
    implode(", ", array_map(
        static fn(array $s): string => $s["name"] . "@" . $s["ref"],
        $managed
    ))
);

foreach (Fleet::updateAll() as $r) {
    $line = sprintf("(update:%s) %s", $r["plugin"], $r["action"]);

    if ($r["from"] !== null && $r["to"] !== null) {
        $line .= sprintf(" %s -> %s", $r["from"], $r["to"]);
    }

    if ($r["detail"] !== null) {
        $line .= sprintf(" — %s", $r["detail"]);
    }

    // $line already carries its own (update:<plugin>) token, assembled above.
    Log::writef($line);
}
