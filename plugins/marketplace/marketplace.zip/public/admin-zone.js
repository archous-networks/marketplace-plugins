/**
 * Loaded by UISP on every admin zone page.
 *
 * Cache-busting loader only — the real code is in admin-zone.uncached.js. UISP
 * appends ?v=<plugin version>, which does not change while developing, so a
 * stale copy would be very sticky on a file that loads everywhere.
 *
 * ⚠️ public/ is served WITHOUT AUTHENTICATION. Nothing here may be trusted, and
 * nothing secret may live here.
 */
(function () {
  "use strict";

  var TARGET = "admin-zone.uncached.js";

  var self =
    document.currentScript ||
    Array.prototype.slice.call(document.getElementsByTagName("script")).filter(function (s) {
      return s.src && s.src.indexOf("admin-zone.js") !== -1;
    }).pop();

  if (!self || !self.src) {
    console.warn("[marketplace] cannot resolve public path; not loading " + TARGET);
    return;
  }

  var script = document.createElement("script");
  script.src = self.src.replace(/\/admin-zone\.js.*$/, "") + "/" + TARGET + "?v=" + Date.now();
  script.type = "text/javascript";
  (self.parentNode || document.head).insertBefore(script, self.nextSibling);
})();
