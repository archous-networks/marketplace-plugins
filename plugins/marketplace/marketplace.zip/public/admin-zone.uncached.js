/**
 * Marketplace PoC: inject an "Archous Plugins" section into UISP's plugin page.
 *
 * ── WHY CLIENT-SIDE ─────────────────────────────────────────────────────────
 * UISP reads its available-plugins list from a hardcoded PHP constant:
 *
 *     UbiquitiLinks::PLUGINS_LIST = 'https://raw.githubusercontent.com/
 *         Ubiquiti-App/UCRM-plugins/master/plugins.json'
 *
 * wired into a Guzzle client via `!php/const`. It is not a setting, a parameter,
 * or a database row — so pointing UISP at our catalogue would mean editing its
 * source, which a UISP upgrade silently reverts. admin-zone.js is the supported
 * extension point, so the section is rendered here instead.
 *
 * Consequences worth knowing: this needs JavaScript, and UISP's own
 * "update available" badges will not know about our plugins — we draw our own.
 *
 * ── ACTIONS ─────────────────────────────────────────────────────────────────
 * Install and Update POST to public.php, which authenticates the caller against
 * /crm/current-user and requires permissions["system/plugins"] === "edit" before
 * doing anything. The X-Requested-With header below is not decoration: it is half
 * of the CSRF defence, since a plain cross-origin form cannot set it without a
 * preflight the endpoint never answers.
 *
 * Nothing here is a security control. This file is served unauthenticated and a
 * caller can skip it entirely — the server decides.
 */
(function () {
  "use strict";

  if (!/^\/crm\/system\/plugins\/?$/.test(window.location.pathname)) {
    return; // runs on every admin page; do nothing anywhere else
  }

  var PLUGIN = "marketplace";

  var api = (function () {
    var s = Array.prototype.slice.call(document.getElementsByTagName("script")).filter(function (x) {
      return x.src && x.src.indexOf("admin-zone.uncached.js") !== -1;
    }).pop();
    return s && s.src
      ? s.src.replace(/\/public\/admin-zone\.uncached\.js.*$/, "/public.php")
      : "/crm/_plugins/" + PLUGIN + "/public.php";
  })();

  function el(tag, attrs, text) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    if (text !== undefined) { n.textContent = text; }
    return n;
  }

  function render(data) {
    if (document.getElementById("archous-marketplace")) { return; }

    var box = el("div", { id: "archous-marketplace", style: "margin:24px 0;padding:16px;border:1px solid #d9d9d9;border-radius:4px;background:#fff" });
    box.appendChild(el("h3", { style: "margin:0 0 4px" }, "Archous Plugins"));
    box.appendChild(el("p", { style: "margin:0 0 12px;color:#666;font-size:12px" },
      "From the marketplace catalogue. Actions require plugin-edit permission."));

    if (!data || !data.plugins || !data.plugins.length) {
      box.appendChild(el("p", { style: "color:#a00;font-size:13px" },
        (data && data.error) ? data.error : "Catalogue unavailable."));
      mount(box);
      return;
    }

    var table = el("table", { style: "width:100%;border-collapse:collapse;font-size:13px" });
    var head = el("tr");
    ["Plugin", "Catalogue", "Installed", "Status", ""].forEach(function (h) {
      var th = el("th", { style: "text-align:left;padding:6px 8px;border-bottom:1px solid #eee;color:#666;font-weight:600" }, h);
      head.appendChild(th);
    });
    table.appendChild(head);

    data.plugins.forEach(function (p) {
      var tr = el("tr");

      [p.displayName || p.name, p.version || "?", p.installed || "—", p.status || "unknown"]
        .forEach(function (c, i) {
          var td = el("td", { style: "padding:6px 8px;border-bottom:1px solid #f5f5f5" }, c);
          if (i === 3) {
            td.style.color = c === "update available" ? "#c47f00" : (c === "not installed" ? "#666" : "#2a7");
          }
          tr.appendChild(td);
        });

      var actions = el("td", { style: "padding:6px 8px;border-bottom:1px solid #f5f5f5;text-align:right" });

      if (p.status === "not installed") {
        actions.appendChild(button("Install", "/install", p.name));
      } else if (p.status === "update available") {
        actions.appendChild(button("Update", "/update", p.name));
      }

      tr.appendChild(actions);
      table.appendChild(tr);
    });

    box.appendChild(table);
    mount(box);
  }

  function button(label, route, name) {
    var b = el("button", {
      type: "button",
      style: "padding:4px 12px;font-size:12px;cursor:pointer;border:1px solid #bbb;border-radius:3px;background:#fafafa",
    }, label);

    b.addEventListener("click", function () {
      b.disabled = true;
      b.textContent = label === "Install" ? "Installing…" : "Updating…";

      fetch(api + "?route=" + route, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          // Half the CSRF defence — see the header comment.
          "X-Requested-With": "marketplace",
        },
        body: JSON.stringify({ name: name }),
      })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
        .then(function (res) {
          if (!res.ok || res.body.error) {
            b.textContent = "Failed";
            b.title = res.body.error || "request failed";
            b.disabled = false;
            return;
          }

          // Reload rather than patching the row: an install changes what UISP
          // itself shows on this page, and its markup is not ours to keep in sync.
          b.textContent = "Done — reloading";
          setTimeout(function () { window.location.reload(); }, 800);
        })
        .catch(function (e) {
          b.textContent = "Failed";
          b.title = String(e);
          b.disabled = false;
        });
    });

    return b;
  }

  function mount(box) {
    // Prepend into the page's own content column so the panel appears WITH the
    // plugin list rather than after it.
    //
    // The first attempt appended to the first match of
    // "[class*='content'], main, body". Nothing but `body` matched, so the panel
    // landed outside the layout at y=744 on a 720px viewport — rendered
    // correctly, invisible without scrolling, and reported as "no section".
    //
    // Selectors are tried most- to least-specific and every one is a guess about
    // markup that is not a contract, so the body fallback stays — but it now
    // prepends, which keeps the panel visible even when the guesses all miss.
    var anchor =
      document.querySelector(".content--inner") ||
      document.querySelector(".content--fixed") ||
      document.querySelector("main") ||
      document.body;

    if (anchor.firstChild) {
      anchor.insertBefore(box, anchor.firstChild);
    } else {
      anchor.appendChild(box);
    }
  }

  // The catalogue is fetched by the PLUGIN, not the browser: it lives on another
  // origin, and going through public.php avoids a CORS dependency on GitHub while
  // letting the server compare against what is actually installed.
  fetch(api + "?route=/catalogue", { credentials: "same-origin" })
    .then(function (r) { return r.json(); })
    .then(render)
    .catch(function (e) { render({ error: String(e) }); });
})();
