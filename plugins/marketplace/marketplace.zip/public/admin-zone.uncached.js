/**
 * Marketplace: an "Archous plugins" section on UISP's plugin page.
 *
 * ── WHY CLIENT-SIDE ─────────────────────────────────────────────────────────
 * UISP reads its available-plugins list from a hardcoded PHP constant:
 *
 *     UbiquitiLinks::PLUGINS_LIST = 'https://raw.githubusercontent.com/
 *         Ubiquiti-App/UCRM-plugins/master/plugins.json'
 *
 * wired into a Guzzle client via `!php/const` — not a setting, not a parameter,
 * not a database row. Pointing UISP at our catalogue would mean editing its
 * source, which an upgrade silently reverts. admin-zone.js is the supported
 * extension point, so the section is rendered here instead.
 *
 * ── WHY IT USES UISP'S OWN CLASS NAMES ──────────────────────────────────────
 * Every element below is built with the classes UISP uses for its own plugin
 * list (plugin-list__item, plugin-list__item__heading, button--primary-fill …),
 * read off the live page. Reusing them rather than approximating with inline
 * styles means the section inherits the real stylesheet — spacing, fonts,
 * colours, hover states — and keeps matching when Ubiquiti restyles or a theme
 * changes. Hand-tuned CSS would drift the first time they touched it.
 *
 * The cost: those class names are not a contract. If a redesign renames them,
 * the section degrades to unstyled markup — still visible, still usable, just
 * plain. That is the right failure mode, and better than a pixel-copy that would
 * look subtly wrong forever.
 *
 * ── ACTIONS ─────────────────────────────────────────────────────────────────
 * Install and Update POST to public.php, which authenticates the caller against
 * /crm/current-user and requires permissions["system/plugins"] === "edit" before
 * doing anything. X-Requested-With is half the CSRF defence — a cross-origin
 * form cannot set it without a preflight the endpoint never answers.
 *
 * Nothing here is a security control. This file is served unauthenticated and a
 * caller can skip it entirely — the server decides.
 */
(function () {
  "use strict";

  if (!/^\/crm\/system\/plugins\/?$/.test(window.location.pathname)) {
    return; // loaded on every admin page; do nothing anywhere else
  }

  var PLUGIN = "marketplace";
  var SECTION_ID = "archous-marketplace";

  var api = (function () {
    var s = Array.prototype.slice.call(document.getElementsByTagName("script")).filter(function (x) {
      return x.src && x.src.indexOf("admin-zone.uncached.js") !== -1;
    }).pop();
    return s && s.src
      ? s.src.replace(/\/public\/admin-zone\.uncached\.js.*$/, "/public.php")
      : "/crm/_plugins/" + PLUGIN + "/public.php";
  })();

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text !== undefined) { n.textContent = text; }
    return n;
  }

  /** One row, structured exactly like a native plugin-list item. */
  function item(p) {
    // The left edge colour is how UISP signals state; reuse the same modifier so
    // ours reads identically rather than merely similarly.
    var row = el("div", "plugin-list__item" + (p.installed ? " plugin-list__item--enabled" : ""));

    var content = el("div", "plugin-list__item__content");
    var header = el("div", "plugin-list__item__header");

    // Installed plugins link to their UISP detail page exactly as native rows
    // do; uninstalled ones link out to the project instead.
    var heading;
    if (p.pluginId) {
      heading = el("a", "plugin-list__item__heading", p.displayName || p.name);
      heading.href = "/crm/system/plugins/" + p.pluginId;
    } else if (p.url) {
      heading = el("a", "plugin-list__item__heading", p.displayName || p.name);
      heading.href = p.url;
      heading.target = "_blank";
    } else {
      heading = el("span", "plugin-list__item__heading", p.displayName || p.name);
    }
    header.appendChild(heading);
    // Native markup carries a whitespace text node here (its template renders
    // `</a> <span>`); without it the version butts against the name.
    header.appendChild(document.createTextNode(" "));
    header.appendChild(el("span", "plugin-list__item__meta", "v" + (p.installed || p.version)));
    content.appendChild(header);

    var desc = el("div", "plugin-list__item__description");
    desc.appendChild(document.createTextNode((p.description || "") + " "));

    if (p.url) {
      var more = el("a", null, "Learn more");
      more.href = p.url;
      more.target = "_blank";
      desc.appendChild(more);
    }

    content.appendChild(desc);
    row.appendChild(content);

    var actions = el("div", "plugin-list__item__actions");
    var primary = el("div", "plugin-list__item__actions__primary");

    // Only uninstalled plugins reach this list, so the action is always Install.
    // Updates are injected into UISP's own installed row instead — see
    // decorateInstalled().
    primary.appendChild(action("Install", "/install", p.name, "button button--medium button--text-larger button--primary-fill"));

    actions.appendChild(primary);

    if (p.pluginId) {
      var secondary = el("div", "plugin-list__item__actions__secondary");
      var details = el("a", null, "See details");
      details.href = "/crm/system/plugins/" + p.pluginId;
      secondary.appendChild(details);
      actions.appendChild(secondary);
    }

    row.appendChild(actions);
    return row;
  }

  function action(label, route, name, cls) {
    var b = el("a", cls || "button button--primary-fill", label);
    b.href = "#";

    b.addEventListener("click", function (e) {
      e.preventDefault();

      if (b.dataset.busy) { return; }
      b.dataset.busy = "1";
      b.textContent = label === "Install" ? "Installing…" : "Updating…";

      fetch(api + "?route=" + route, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "X-Requested-With": "marketplace",
        },
        body: JSON.stringify({ name: name }),
      })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
        .then(function (res) {
          if (!res.ok || res.body.error || res.body.action === "failed") {
            b.textContent = "Failed";
            b.title = res.body.error || res.body.detail || "request failed";
            b.className = "button button--danger-fill";
            delete b.dataset.busy;
            return;
          }

          // Reload rather than patching the row: an install changes UISP's own
          // list too, and its markup is not ours to keep in sync.
          b.textContent = "Done";
          setTimeout(function () { window.location.reload(); }, 600);
        })
        .catch(function (err) {
          b.textContent = "Failed";
          b.title = String(err);
          b.className = "button";
          delete b.dataset.busy;
        });
    });

    return b;
  }

  function notice(text) {
    var row = el("div", "plugin-list__item");
    var c = el("div", "plugin-list__item__content");
    c.appendChild(el("div", "plugin-list__item__description", text));
    row.appendChild(c);
    return row;
  }

  /**
   * Put an Update action on UISP's OWN installed row, the way native updates
   * appear.
   *
   * Native renders, inside the installed item's actions:
   *
   *   <a class="button button--warning-fill">Update</a>
   *   <div class="plugin-list__item__actions__update">v1.2.3 available</div>
   *
   * so reusing those classes makes ours indistinguishable. Rows are matched by
   * the plugin id in their links — scoped to outside our own section, since ours
   * carry the same hrefs.
   */
  function decorateInstalled(all) {
    all.forEach(function (p) {
      if (p.status !== "update available" || !p.pluginId) { return; }

      var link = document.querySelector('.plugin-list__item a[href="/crm/system/plugins/' + p.pluginId + '"]');
      if (!link) { return; }

      var row = link.closest(".plugin-list__item");
      if (!row || row.closest("#" + SECTION_ID)) { return; }

      if (row.querySelector(".archous-update")) { return; }

      var actions = row.querySelector(".plugin-list__item__actions");
      var primary = row.querySelector(".plugin-list__item__actions__primary");
      if (!actions || !primary) { return; }

      var btn = action("Update", "/update", p.name, "button button--warning-fill archous-update");
      primary.appendChild(btn);

      var note = el("div", "plugin-list__item__actions__update", "v" + p.version + " available");
      var secondary = row.querySelector(".plugin-list__item__actions__secondary");

      if (secondary) {
        actions.insertBefore(note, secondary);
      } else {
        actions.appendChild(note);
      }
    });
  }

  function render(data) {
    var existing = document.getElementById(SECTION_ID);
    if (existing) { existing.parentElement.removeChild(existing); }

    // `verticalRhythm` is UISP's own 24px bottom-spacing utility. Native sections
    // get their separation from the page template; ours is inserted between them
    // and has none, so without this the next heading sits flush against our last
    // card — measured gap 0 versus ~24 elsewhere.
    var wrap = el("div", "verticalRhythm");
    wrap.id = SECTION_ID;

    var header = el("div", "plugin-list__header verticalRhythmHalf");
    header.appendChild(el("div", "plugin-list__header__heading", "Archous plugins"));
    wrap.appendChild(header);

    // Native lists wrap their rows in `.plugin-list__items`, which is where the
    // list's own spacing comes from. Without it the section sits noticeably
    // tighter against whatever follows.
    var items = el("div", "plugin-list__items");

    var all = (data && data.plugins) || [];

    // Mirror UISP: a plugin appears in the AVAILABLE list or the INSTALLED list,
    // never both. Its own PluginListDataProvider::removeInstalledPlugins() does
    // exactly this, and showing a plugin twice made the page read as duplicated.
    var available = all.filter(function (p) { return p.status === "not installed"; });

    if (data && data.error) {
      items.appendChild(notice(data.error));
    } else if (!available.length) {
      // Deliberately still rendered. If the section vanished when everything was
      // installed, "catalogue reachable, nothing to do" would look identical to
      // "catalogue broken".
      items.appendChild(notice(
        all.length ? "All Archous plugins are installed." : "Catalogue unavailable — check the Update URL in this plugin's settings."
      ));
    } else {
      available.forEach(function (p) { items.appendChild(item(p)); });
    }

    wrap.appendChild(items);

    decorateInstalled(all);

    mount(wrap);
  }

  /**
   * Place the section between UISP's "Installed plugins" and "Available plugins"
   * lists, so it reads as one more section of the same page.
   *
   * Anchored on heading TEXT rather than position: the two lists are siblings
   * with identical classes, so an index would silently pick the wrong one the
   * moment a third section appeared.
   *
   * Fallbacks descend to the content column. An earlier version fell through to
   * document.body, which put the panel outside the layout and below the fold —
   * rendered, and invisible.
   */
  function mount(wrap) {
    var headers = Array.prototype.slice.call(document.querySelectorAll(".plugin-list__header"));

    var available = headers.filter(function (h) {
      return /available plugins/i.test(h.textContent || "");
    })[0];

    if (available && available.parentElement) {
      available.parentElement.insertBefore(wrap, available);
      return;
    }

    var installed = headers.filter(function (h) {
      return /installed plugins/i.test(h.textContent || "");
    })[0];

    if (installed && installed.parentElement) {
      installed.parentElement.appendChild(wrap);
      return;
    }

    var content = document.querySelector(".content--inner") || document.querySelector(".content--fixed");
    (content || document.body).appendChild(wrap);
  }

  /**
   * Re-apply after UISP finishes rendering its own list.
   *
   * The plugin list is populated ASYNCHRONOUSLY — UISP ships
   * plugin_list_item_loading.html.twig for the interim state. Our script runs
   * early, mounts against the headers (which exist immediately), and decorates
   * rows that are then replaced when the real list arrives. Everything looked
   * correct when run by hand afterwards, which is exactly why this was invisible:
   * the logic was fine, the timing was not.
   *
   * A MutationObserver re-runs the work whenever nodes land, and is debounced so
   * a burst of insertions costs one pass. Our own writes are ignored, otherwise
   * decorating would retrigger the observer forever.
   */
  function watch(data) {
    var pending = null;
    var applying = false;

    var observer = new MutationObserver(function () {
      if (applying) { return; }

      clearTimeout(pending);
      pending = setTimeout(function () {
        applying = true;
        try {
          render(data);
        } finally {
          // Let the observer settle before listening again, so our own DOM
          // writes do not queue another pass.
          setTimeout(function () { applying = false; }, 0);
        }
      }, 50);
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  // Fetched by the PLUGIN, not the browser: the catalogue is on another origin,
  // and going through public.php avoids a CORS dependency while letting the
  // server compare against what is actually installed.
  fetch(api + "?route=/catalogue", { credentials: "same-origin" })
    .then(function (r) { return r.json(); })
    .then(function (data) { render(data); watch(data); })
    .catch(function (e) { render({ error: String(e) }); });
})();
