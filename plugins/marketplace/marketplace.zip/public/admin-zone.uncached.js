/**
 * Marketplace PoC: inject an "Archous Plugins" section into UISP's plugin page.
 *
 * ── WHY CLIENT-SIDE ─────────────────────────────────────────────────────────
 * UISP reads its available-plugins list from a hardcoded PHP constant:
 *
 *     UbiquitiLinks::PLUGINS_LIST = 'https://raw.githubusercontent.com/
 *         Ubiquiti-App/UCRM-plugins/master/plugins.json'
 *
 * wired into a Guzzle client via `!php/const`. It is not a setting, a parameter,
 * or a database row — so pointing UISP at our catalogue would mean editing its
 * source, which a UISP upgrade silently reverts. admin-zone.js is the supported
 * extension point, so the section is rendered here instead.
 *
 * Consequences worth knowing: this needs JavaScript, and UISP's own
 * "update available" badges will not know about our plugins — we draw our own.
 *
 * ── STATUS: PROOF OF CONCEPT ────────────────────────────────────────────────
 * Renders the catalogue and reports what is installed. The install/update
 * buttons are deliberately NOT wired up yet: they must POST to an endpoint that
 * authenticates the caller against /crm/current-user and requires
 * permissions["system/plugins"] === "edit". public.php is unauthenticated, so an
 * install-from-URL endpoint without that check is remote code execution on the
 * UISP host. See docs/security.md in the plugins skill.
 */
(function () {
  "use strict";

  if (!/^\/crm\/system\/plugins\/?$/.test(window.location.pathname)) {
    return; // runs on every admin page; do nothing anywhere else
  }

  var PLUGIN = "marketplace";

  var api = (function () {
    var s = Array.prototype.slice.call(document.getElementsByTagName("script")).filter(function (x) {
      return x.src && x.src.indexOf("admin-zone.uncached.js") !== -1;
    }).pop();
    return s && s.src
      ? s.src.replace(/\/public\/admin-zone\.uncached\.js.*$/, "/public.php")
      : "/crm/_plugins/" + PLUGIN + "/public.php";
  })();

  function el(tag, attrs, text) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    if (text !== undefined) { n.textContent = text; }
    return n;
  }

  function render(data) {
    if (document.getElementById("archous-marketplace")) { return; }

    var box = el("div", { id: "archous-marketplace", style: "margin:24px 0;padding:16px;border:1px solid #d9d9d9;border-radius:4px;background:#fff" });
    box.appendChild(el("h3", { style: "margin:0 0 4px" }, "Archous Plugins"));
    box.appendChild(el("p", { style: "margin:0 0 12px;color:#666;font-size:12px" },
      "From the marketplace catalogue. Proof of concept — actions are not wired up yet."));

    if (!data || !data.plugins || !data.plugins.length) {
      box.appendChild(el("p", { style: "color:#a00;font-size:13px" },
        (data && data.error) ? data.error : "Catalogue unavailable."));
      mount(box);
      return;
    }

    var table = el("table", { style: "width:100%;border-collapse:collapse;font-size:13px" });
    var head = el("tr");
    ["Plugin", "Catalogue", "Installed", "Status"].forEach(function (h) {
      var th = el("th", { style: "text-align:left;padding:6px 8px;border-bottom:1px solid #eee;color:#666;font-weight:600" }, h);
      head.appendChild(th);
    });
    table.appendChild(head);

    data.plugins.forEach(function (p) {
      var tr = el("tr");
      var cells = [
        p.displayName || p.name,
        p.version || "?",
        p.installed || "—",
        p.status || "unknown",
      ];
      cells.forEach(function (c, i) {
        var td = el("td", { style: "padding:6px 8px;border-bottom:1px solid #f5f5f5" }, c);
        if (i === 3) {
          td.style.color = c === "update available" ? "#c47f00" : (c === "not installed" ? "#666" : "#2a7");
        }
        tr.appendChild(td);
      });
      table.appendChild(tr);
    });

    box.appendChild(table);
    mount(box);
  }

  function mount(box) {
    // Attach after the page's own content rather than assuming a specific
    // container: UISP's markup is not a contract and will change.
    var anchor = document.querySelector("[class*='content'], main, body");
    (anchor || document.body).appendChild(box);
  }

  // The catalogue is fetched by the PLUGIN, not the browser: it lives on another
  // origin, and going through public.php avoids a CORS dependency on GitHub while
  // letting the server compare against what is actually installed.
  fetch(api + "?route=/catalogue", { credentials: "same-origin" })
    .then(function (r) { return r.json(); })
    .then(render)
    .catch(function (e) { render({ error: String(e) }); });
})();
