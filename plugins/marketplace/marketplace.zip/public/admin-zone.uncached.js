/**
 * Marketplace: UISP's plugin pages, extended.
 *
 * Two pages, two jobs:
 *
 *   /crm/system/plugins       an "Archous plugins" section, plus Update actions
 *                             on UISP's own installed rows
 *   /crm/system/plugins/{id}  full-width card, a log that wraps, a Clear button
 *
 * ── WHY CLIENT-SIDE ─────────────────────────────────────────────────────────
 * UISP reads its available-plugins list from a hardcoded PHP constant:
 *
 *     UbiquitiLinks::PLUGINS_LIST = 'https://raw.githubusercontent.com/
 *         Ubiquiti-App/UCRM-plugins/master/plugins.json'
 *
 * wired into a Guzzle client via `!php/const` — not a setting, not a parameter,
 * not a database row. Pointing UISP at our catalogue would mean editing its
 * source, which an upgrade silently reverts. admin-zone.js is the supported
 * extension point, so the section is rendered here instead.
 *
 * ── WHY IT USES UISP'S OWN CLASS NAMES ──────────────────────────────────────
 * Every element below is built with the classes UISP uses for its own plugin
 * list (plugin-list__item, plugin-list__item__heading, button--primary-fill …),
 * read off the live page. Reusing them rather than approximating with inline
 * styles means the section inherits the real stylesheet — spacing, fonts,
 * colours, hover states — and keeps matching when Ubiquiti restyles or a theme
 * changes. Hand-tuned CSS would drift the first time they touched it.
 *
 * The cost: those class names are not a contract. If a redesign renames them,
 * the section degrades to unstyled markup — still visible, still usable, just
 * plain. That is the right failure mode, and better than a pixel-copy that would
 * look subtly wrong forever.
 *
 * ── ACTIONS ─────────────────────────────────────────────────────────────────
 * Install and Update POST to public.php, which authenticates the caller against
 * /crm/current-user and requires permissions["system/plugins"] === "edit" before
 * doing anything. X-Requested-With is half the CSRF defence — a cross-origin
 * form cannot set it without a preflight the endpoint never answers.
 *
 * Nothing here is a security control. This file is served unauthenticated and a
 * caller can skip it entirely — the server decides.
 */
(function () {
  "use strict";

  var PLUGIN = "marketplace";
  var SECTION_ID = "archous-marketplace";

  var LIST_PATH   = /^\/crm\/system\/plugins\/?$/;
  var DETAIL_PATH = /^\/crm\/system\/plugins\/(\d+)\/?$/;

  var detail = DETAIL_PATH.exec(window.location.pathname);

  if (!detail && !LIST_PATH.test(window.location.pathname)) {
    return; // loaded on every admin page; do nothing anywhere else
  }

  /**
   * This plugin's own public.php.
   *
   * `document.currentScript` FIRST, and it matters: every Archous plugin ships an
   * admin-zone.uncached.js, so matching on that filename finds all of them and
   * whichever UISP happened to load last wins. That produced a 404 against
   * provisioner-v3's public.php — a bug that only appeared once a second plugin
   * with zone JS was installed, and that load order alone decided.
   *
   * currentScript is set while a script executes synchronously, which is the case
   * here — admin-zone.js inserts this one and the browser runs it on arrival. The
   * fallbacks narrow by OUR plugin path rather than by filename.
   */
  var api = (function () {
    var self = document.currentScript;

    if (!self) {
      self = Array.prototype.slice.call(document.getElementsByTagName("script")).filter(function (x) {
        return x.src && x.src.indexOf("/_plugins/" + PLUGIN + "/public/admin-zone.uncached.js") !== -1;
      }).pop();
    }

    return self && self.src
      ? self.src.replace(/\/public\/admin-zone\.uncached\.js.*$/, "/public.php")
      : "/crm/_plugins/" + PLUGIN + "/public.php";
  })();

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text !== undefined) { n.textContent = text; }
    return n;
  }

  /** One row, structured exactly like a native plugin-list item. */
  function item(p) {
    // The left edge colour is how UISP signals state; reuse the same modifier so
    // ours reads identically rather than merely similarly.
    var row = el("div", "plugin-list__item" + (p.installed ? " plugin-list__item--enabled" : ""));

    var content = el("div", "plugin-list__item__content");
    var header = el("div", "plugin-list__item__header");

    // Installed plugins link to their UISP detail page exactly as native rows
    // do; uninstalled ones link out to the project instead.
    var heading;
    if (p.pluginId) {
      heading = el("a", "plugin-list__item__heading", p.displayName || p.name);
      heading.href = "/crm/system/plugins/" + p.pluginId;
    } else if (p.url) {
      heading = el("a", "plugin-list__item__heading", p.displayName || p.name);
      heading.href = p.url;
      heading.target = "_blank";
    } else {
      heading = el("span", "plugin-list__item__heading", p.displayName || p.name);
    }
    header.appendChild(heading);
    // Native markup carries a whitespace text node here (its template renders
    // `</a> <span>`); without it the version butts against the name.
    header.appendChild(document.createTextNode(" "));
    header.appendChild(el("span", "plugin-list__item__meta", "v" + (p.installed || p.version)));
    content.appendChild(header);

    var desc = el("div", "plugin-list__item__description");
    desc.appendChild(document.createTextNode((p.description || "") + " "));

    if (p.url) {
      var more = el("a", null, "Learn more");
      more.href = p.url;
      more.target = "_blank";
      desc.appendChild(more);
    }

    content.appendChild(desc);
    row.appendChild(content);

    var actions = el("div", "plugin-list__item__actions");
    var primary = el("div", "plugin-list__item__actions__primary");
    var cls     = "button button--medium button--text-larger button--primary-fill";

    // Only uninstalled plugins reach this list, so the action is always Install.
    // Updates are injected into UISP's own installed row instead — see
    // decorateInstalled().
    // Both of these are catalogue faults the operator cannot fix, so the button
    // says what is wrong instead of failing on click. They are worded apart
    // because they are different faults: one names something we do not
    // distribute, the other a loop in what we do.
    var fault = (p.unresolved || []).length
      ? "Cannot install — depends on " + list(p.unresolved) + ", which the catalogue does not offer."
      : (p.cycle || []).length
        ? "Cannot install — the catalogue has a dependency loop through " + list(p.cycle) + "."
        : null;

    if (fault) {
      primary.appendChild(blocked("Install", cls, fault));
    } else {
      var install = action("Install", "/install", p.name, cls);

      if ((p.requires || []).length) {
        // Not a warning — a statement of what the click does. The install goes
        // ahead either way; the operator should not be surprised by what else
        // appears afterwards.
        tooltip(install, "Also installs " + list(p.requires) + ".");
      }

      primary.appendChild(install);
    }

    actions.appendChild(primary);

    if (p.pluginId) {
      var secondary = el("div", "plugin-list__item__actions__secondary");
      var details = el("a", null, "See details");
      details.href = "/crm/system/plugins/" + p.pluginId;
      secondary.appendChild(details);
      actions.appendChild(secondary);
    }

    row.appendChild(actions);
    return row;
  }

  function action(label, route, name, cls) {
    var b = el("a", cls || "button button--primary-fill", label);
    b.href = "#";

    b.addEventListener("click", function (e) {
      e.preventDefault();

      if (b.dataset.busy) { return; }
      b.dataset.busy = "1";
      b.textContent = label === "Install"
        ? "Installing…"
        : label === "Downgrade" ? "Downgrading…" : "Updating…";

      fetch(api + "?route=" + route, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "X-Requested-With": "marketplace",
        },
        body: JSON.stringify({ name: name }),
      })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
        .then(function (res) {
          if (!res.ok || res.body.error || res.body.action === "failed") {
            b.textContent = "Failed";
            b.title = res.body.error || res.body.detail || "request failed";
            b.className = "button button--danger-fill";
            delete b.dataset.busy;
            return;
          }

          // Reload rather than patching the row: an install changes UISP's own
          // list too, and its markup is not ours to keep in sync.
          b.textContent = "Done";
          setTimeout(function () { window.location.reload(); }, 600);
        })
        .catch(function (err) {
          b.textContent = "Failed";
          b.title = String(err);
          b.className = "button";
          delete b.dataset.busy;
        });
    });

    return b;
  }

  function notice(text) {
    var row = el("div", "plugin-list__item");
    var c = el("div", "plugin-list__item__content");
    c.appendChild(el("div", "plugin-list__item__description", text));
    row.appendChild(c);
    return row;
  }

  /* ── Dependency graph ─────────────────────────────────────────────────────
   *
   * Two rules, both enforced by the SERVER — Fleet::installTree() installs what a
   * plugin needs, and nothing here can approve a removal because removal is
   * UISP's own route, not ours. What follows is signposting: it turns an action
   * that would break something into one that visibly cannot be taken, with the
   * reason attached. An operator who defeats it still gets the outcome they asked
   * for, which is the right level of force for a convention we invented.
   */

  function list(names) {
    return (names || []).join(", ");
  }

  /**
   * Attach a native tooltip.
   *
   * UISP wires jQuery UI tooltips in initByContext() at page load, so anything
   * added afterwards has to be initialised by hand. `title` is the fallback: less
   * pretty, never absent.
   */
  function tooltip(node, text) {
    node.setAttribute("data-tooltip", text);

    if (window.jQuery && typeof window.initTooltip === "function") {
      try {
        window.initTooltip(window.jQuery(node));
        return;
      } catch (e) { /* fall through to title */ }
    }

    node.title = text;
  }

  /**
   * A button that is present, visibly unavailable, and explains itself.
   *
   * `<span class="… is-disabled" data-tooltip>` is UISP's OWN idiom for this —
   * it is exactly how the native list renders Install and Update for a plugin
   * that fails the version-compliancy check. Reusing it means no new styling and
   * no new interaction to learn, and a span cannot be clicked through the way a
   * neutralised anchor can.
   */
  function blocked(label, cls, reason) {
    var s = el("span", cls + " is-disabled", label);
    tooltip(s, reason);
    return s;
  }

  /** Replace one of UISP's own action links with a blocked equivalent. */
  function block(link, reason) {
    if (!link || !link.parentNode) { return; }

    var s = el("span", link.className + " is-disabled");

    // Move the children across rather than copying textContent: the detail
    // page's delete action is icon-only (`<span class="icon ucrm-icon--trash">`),
    // and reading its text would replace the icon with an empty label.
    while (link.firstChild) {
      s.appendChild(link.firstChild);
    }

    tooltip(s, reason);
    link.parentNode.replaceChild(s, link);
  }

  /**
   * Stop UISP's own Disable and Delete actions on anything another installed
   * plugin depends on.
   *
   * Scoped to rows OUTSIDE our section, which only ever lists uninstalled
   * plugins — but the hrefs are identical, so the check is cheap insurance
   * against that changing.
   */
  function guardDependencies(all, root) {
    (all || []).forEach(function (p) {
      if (!p.pluginId || !(p.dependents || []).length) { return; }

      var reason = (p.displayName || p.name) + " is required by " + list(p.dependents)
                 + ". Remove " + (p.dependents.length > 1 ? "those plugins" : "that plugin") + " first.";

      var base  = "/crm/system/plugins/" + p.pluginId + "/";
      var scope = root || document;

      ["disable", "delete"].forEach(function (verb) {
        var links = scope.querySelectorAll('a[href^="' + base + verb + '"]');

        Array.prototype.forEach.call(links, function (link) {
          if (link.closest("#" + SECTION_ID)) { return; }
          block(link, reason);
        });
      });
    });
  }

  /**
   * Put an Update action on UISP's OWN installed row, the way native updates
   * appear.
   *
   * Native renders, inside the installed item's actions:
   *
   *   <a class="button button--warning-fill">Update</a>
   *   <div class="plugin-list__item__actions__update">v1.2.3 available</div>
   *
   * so reusing those classes makes ours indistinguishable. Rows are matched by
   * the plugin id in their links — scoped to outside our own section, since ours
   * carry the same hrefs.
   */
  function decorateInstalled(all) {
    all.forEach(function (p) {
      if (p.status !== "update available" || !p.pluginId) { return; }

      var link = document.querySelector('.plugin-list__item a[href="/crm/system/plugins/' + p.pluginId + '"]');
      if (!link) { return; }

      var row = link.closest(".plugin-list__item");
      if (!row || row.closest("#" + SECTION_ID)) { return; }

      if (row.querySelector(".archous-update")) { return; }

      var actions = row.querySelector(".plugin-list__item__actions");
      var primary = row.querySelector(".plugin-list__item__actions__primary");
      if (!actions || !primary) { return; }

      // A pin is not always an upgrade — pinning to an older version is a
      // legitimate reason to reach for this, and calling that "Update" would
      // misdescribe what the button does.
      var label = p.direction === "down" ? "Downgrade" : "Update";

      var btn = action(label, "/update", p.name, "button button--warning-fill archous-update");

      if (p.pinned) {
        tooltip(btn, "Pinned to " + p.ref + " by this instance's marketplace settings.");
      }

      primary.appendChild(btn);

      var note = el(
        "div",
        "plugin-list__item__actions__update",
        p.pinned ? "pinned to v" + p.version : "v" + p.version + " available"
      );

      var secondary = row.querySelector(".plugin-list__item__actions__secondary");

      if (secondary) {
        actions.insertBefore(note, secondary);
      } else {
        actions.appendChild(note);
      }
    });
  }

  function render(data) {
    var existing = document.getElementById(SECTION_ID);
    if (existing) { existing.parentElement.removeChild(existing); }

    // `verticalRhythm` is UISP's own 24px bottom-spacing utility. Native sections
    // get their separation from the page template; ours is inserted between them
    // and has none, so without this the next heading sits flush against our last
    // card — measured gap 0 versus ~24 elsewhere.
    var wrap = el("div", "verticalRhythm");
    wrap.id = SECTION_ID;

    var header = el("div", "plugin-list__header verticalRhythmHalf");
    header.appendChild(el("div", "plugin-list__header__heading", "Archous plugins"));
    wrap.appendChild(header);

    // Native lists wrap their rows in `.plugin-list__items`, which is where the
    // list's own spacing comes from. Without it the section sits noticeably
    // tighter against whatever follows.
    var items = el("div", "plugin-list__items");

    var all = (data && data.plugins) || [];

    // Mirror UISP: a plugin appears in the AVAILABLE list or the INSTALLED list,
    // never both. Its own PluginListDataProvider::removeInstalledPlugins() does
    // exactly this, and showing a plugin twice made the page read as duplicated.
    var available = all.filter(function (p) { return p.status === "not installed"; });

    if (data && data.error) {
      items.appendChild(notice(data.error));
    } else if (!available.length) {
      // Deliberately still rendered. If the section vanished when everything was
      // installed, "catalogue reachable, nothing to do" would look identical to
      // "catalogue broken".
      items.appendChild(notice(
        all.length ? "All Archous plugins are installed." : "Catalogue unavailable — check the Update URL in this plugin's settings."
      ));
    } else {
      available.forEach(function (p) { items.appendChild(item(p)); });
    }

    wrap.appendChild(items);

    decorateInstalled(all);
    guardDependencies(all);

    mount(wrap);
  }

  /**
   * Place the section between UISP's "Installed plugins" and "Available plugins"
   * lists, so it reads as one more section of the same page.
   *
   * Anchored on heading TEXT rather than position: the two lists are siblings
   * with identical classes, so an index would silently pick the wrong one the
   * moment a third section appeared.
   *
   * Fallbacks descend to the content column. An earlier version fell through to
   * document.body, which put the panel outside the layout and below the fold —
   * rendered, and invisible.
   */
  function mount(wrap) {
    var headers = Array.prototype.slice.call(document.querySelectorAll(".plugin-list__header"));

    var available = headers.filter(function (h) {
      return /available plugins/i.test(h.textContent || "");
    })[0];

    if (available && available.parentElement) {
      available.parentElement.insertBefore(wrap, available);
      return;
    }

    var installed = headers.filter(function (h) {
      return /installed plugins/i.test(h.textContent || "");
    })[0];

    if (installed && installed.parentElement) {
      installed.parentElement.appendChild(wrap);
      return;
    }

    var content = document.querySelector(".content--inner") || document.querySelector(".content--fixed");
    (content || document.body).appendChild(wrap);
  }

  /**
   * Re-apply after UISP finishes rendering its own list.
   *
   * The plugin list is populated ASYNCHRONOUSLY — UISP ships
   * plugin_list_item_loading.html.twig for the interim state. Our script runs
   * early, mounts against the headers (which exist immediately), and decorates
   * rows that are then replaced when the real list arrives. Everything looked
   * correct when run by hand afterwards, which is exactly why this was invisible:
   * the logic was fine, the timing was not.
   *
   * A MutationObserver re-runs the work whenever nodes land, and is debounced so
   * a burst of insertions costs one pass. Our own writes are ignored, otherwise
   * decorating would retrigger the observer forever.
   */
  function watch(data) {
    var pending = null;
    var applying = false;

    var observer = new MutationObserver(function () {
      if (applying) { return; }

      clearTimeout(pending);
      pending = setTimeout(function () {
        applying = true;
        try {
          render(data);
        } finally {
          // Let the observer settle before listening again, so our own DOM
          // writes do not queue another pass.
          setTimeout(function () { applying = false; }, 0);
        }
      }, 50);
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  /* ── /crm/system/plugins/{id} ─────────────────────────────────────────────
   *
   * Three quality-of-life fixes to UISP's own plugin detail page. All of them are
   * changes to markup we do not own, so each is anchored on something structural
   * (a route in an href, a documented class) rather than on position, and each
   * fails by doing nothing.
   */

  var DETAIL_CSS_ID = "archous-plugin-detail-css";

  function detailStyles() {
    if (document.getElementById(DETAIL_CSS_ID)) { return; }

    var s = el("style");
    s.id = DETAIL_CSS_ID;

    s.textContent =
      // The log renders with `white-space: pre` (from UISP's textarea--monospace),
      // so one long line — a stack trace, a URL — puts a horizontal scrollbar
      // under the whole log and hides the right-hand end of everything else.
      // `anywhere` rather than `break-word` because log lines routinely have no
      // space to break on.
      ".archous-log { white-space: pre-wrap; overflow-wrap: anywhere; overflow-x: hidden; }" +
      // Native has a single right-aligned button in this block. space-between
      // leaves Disable/Enable exactly where it was and puts Clear on the far left.
      ".archous-actions { display: flex; align-items: center; justify-content: space-between; }";

    document.head.appendChild(s);
  }

  /**
   * Clear the plugin's log.
   *
   * Confirmation is UISP's OWN dialog, not one of ours: setting data-confirm /
   * -title / -okay is all its confirm module needs, and it is bound as a DELEGATED
   * handler on `document`. That ordering is the whole trick below — a listener on
   * the element runs in the target phase, i.e. BEFORE the document handler, so the
   * first click has to bail out and let the event bubble. The module then re-clicks
   * the element with its `confirmed` flag set, and the second pass falls through to
   * the request. Matches how native Disable and Delete behave, for free.
   */
  function clearButton(id, textarea) {
    var MESSAGE = "Do you really want to clear this plugin's log?";

    var b = el("a", "button button--medium button--wide archous-clear", "Clear");
    b.href = "#";
    b.setAttribute("data-confirm", MESSAGE);
    b.setAttribute("data-confirm-title", "Clear log");
    b.setAttribute("data-confirm-okay", "Clear");

    b.addEventListener("click", function (e) {
      e.preventDefault(); // href is "#"; nothing here should ever navigate

      var $ = window.jQuery;

      if ($) {
        if ($(b).data("confirmed") === undefined) {
          return; // first click — let UISP's dialog take it
        }

        // Re-arm, but ONLY once this click has finished propagating. Clearing the
        // flag here and now would leave the page unusable: the event still has to
        // reach the confirm module's own handler on `document`, which re-opens the
        // dialog for anything it does not see as already confirmed. That re-open
        // lands mid-fade — it clearTimeout()s the pending `removeClass('on')` while
        // opacity is still 0 — so #confirm stays mounted, invisible, and swallowing
        // every click on the page including the sidebar. Deferring past the
        // dispatch lets that handler see `confirmed` and stand down.
        setTimeout(function () { $(b).removeData("confirmed"); }, 0);
      } else if (!window.confirm(MESSAGE)) {
        // jQuery gone means the dialog is gone. Degrade to the browser's own
        // prompt rather than silently dropping the confirmation.
        return;
      }

      if (b.dataset.busy) { return; }
      b.dataset.busy = "1";
      b.textContent = "Clearing…";

      fetch(api + "?route=/clear&plugin=" + encodeURIComponent(id), {
        method: "POST",
        credentials: "same-origin",
        headers: { "X-Requested-With": "marketplace" },
      })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
        .then(function (res) {
          delete b.dataset.busy;

          if (!res.ok || res.body.error) {
            b.textContent = "Failed";
            b.title = res.body.error || "request failed";
            return;
          }

          // Show what the server says is on disk — a single "log cleared by …"
          // line, not nothing. Repainting the field rather than reloading keeps
          // the scroll position on a page whose whole point is reading the log.
          if (textarea) { textarea.value = res.body.content || ""; }

          b.textContent = "Cleared";
          b.title = "";
          setTimeout(function () { b.textContent = "Clear"; }, 1500);
        })
        .catch(function (err) {
          delete b.dataset.busy;
          b.textContent = "Failed";
          b.title = String(err);
        });
    });

    return b;
  }

  function enhanceDetail(id) {
    detailStyles();

    // Full width. The template hardcodes `col--lg6 col--md12`, which is fine for a
    // card of metadata and far too narrow for the log below it. Dropping the lg
    // modifier lets col--md12 govern at every breakpoint — no CSS override, no
    // guess at what the grid does.
    var column = document.querySelector(".content--fixed .row > .col--lg6");
    if (column) { column.classList.remove("col--lg6"); }

    var textarea = document.querySelector(".card textarea.textarea--monospace");
    if (textarea) { textarea.classList.add("archous-log"); }

    // Anchored on the enable/disable route rather than on the block's position,
    // since `.card-block--pad` appears more than once in this card. It is also the
    // permission check for free: UISP omits this whole block for an admin who
    // cannot edit plugins, and clearing is exactly as privileged as disabling.
    //
    // Prefix match, not suffix: those hrefs end in a CSRF `_token` query string,
    // so `$=` matches nothing.
    var base = "/crm/system/plugins/" + id + "/";
    var toggle = document.querySelector(
      '.card a[href^="' + base + 'disable"], .card a[href^="' + base + 'enable"]'
    );

    var actions = toggle && toggle.closest(".card-block");
    if (!actions || actions.querySelector(".archous-clear")) { return; }

    actions.classList.add("archous-actions");
    actions.insertBefore(clearButton(id, textarea), actions.firstChild);
  }

  // Fetched by the PLUGIN, not the browser: the catalogue is on another origin,
  // and going through public.php avoids a CORS dependency while letting the
  // server compare against what is actually installed.
  function catalogue() {
    return fetch(api + "?route=/catalogue", { credentials: "same-origin" })
      .then(function (r) { return r.json(); });
  }

  if (detail) {
    // Layout first and without waiting: the three cosmetic fixes need no server
    // data, and deferring them behind a request would show the narrow, unwrapped
    // page and then visibly reflow it.
    enhanceDetail(detail[1]);

    // The guard does need the catalogue — this page knows the plugin's id, only
    // the server knows its name and who depends on it. A catalogue that cannot be
    // reached leaves the native buttons alone; the page is UISP's and works
    // without us.
    catalogue()
      .then(function (data) { guardDependencies((data && data.plugins) || []); })
      .catch(function () { /* no catalogue, no claim to make */ });
  } else {
    catalogue()
      .then(function (data) { render(data); watch(data); })
      .catch(function (e) { render({ error: String(e) }); });
  }
})();
