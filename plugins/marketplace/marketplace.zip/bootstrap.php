<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

require_once __DIR__ . "/vendor/autoload.php";

ini_set("display_errors", "0");
ini_set("log_errors", "1");
error_reporting(E_ALL);

if (!is_dir(__DIR__ . "/data")) {
    @mkdir(__DIR__ . "/data", 0775, true);
}

$__log = __DIR__ . "/data/plugin.log";

// Created permissively: this plugin runs as the web user from public.php and as
// the CLI user from main.php, and error_log() fails SILENTLY when it cannot
// write — an ownership mismatch would cost every log line with no indication.
if (!file_exists($__log)) {
    @touch($__log);
    @chmod($__log, 0666);
}

ini_set("error_log", $__log);
unset($__log);
