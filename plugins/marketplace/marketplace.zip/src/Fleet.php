<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

use Archous\Updater\Ucrm\Server;
use ZipArchive;

/**
 * Updates OTHER plugins, using UISP's own update path.
 *
 * ── WHY A SEPARATE PLUGIN ───────────────────────────────────────────────────
 * `PluginFacade::updatePlugin()` opens with:
 *
 *     if ($this->pluginDataFileManager->isRunning($plugin)) {
 *         throw new PluginUploadException('Plugin you are trying to update is currently running.');
 *     }
 *
 * `plugins.sh` holds `.ucrm-plugin-running` for the whole of a plugin's `main.php`,
 * so a plugin can never use that facade **on itself**. From here the lock belongs
 * to *this* plugin, the target's is free, and the guard passes — so UISP performs
 * the entire update: stage data/, replace files, rescan for zone JS, record the
 * version, recreate the web-root symlink, invalidate its caches.
 *
 * That removes the whole class of problems a self-updating plugin has: nothing
 * replaces the files it is executing from, so there is no autoload-after-swap
 * hazard, no detached process, and no race with the scheduler.
 *
 * And when a target *is* mid-run, the facade refuses and we simply try again next
 * tick — the guard becomes the feature rather than the obstacle.
 *
 * ── CATALOGUE ───────────────────────────────────────────────────────────────
 * `update_url` points at a directory serving `plugins.json`, whose shape follows
 * Ubiquiti's own index (Ubiquiti-App/UCRM-plugins) with `sha256` added:
 *
 *   { "plugins": [ { "name", "version", "zipUrl", "sha256", ... } ] }
 *
 * ONE fetch describes the whole catalogue. The earlier design read a per-plugin
 * `latest` file, which cost one request per managed plugin, per poll, per
 * instance — against an unauthenticated raw host that scales badly.
 *
 * `zipUrl` is expected to pin a commit SHA rather than a branch, so a published
 * version means one exact byte sequence permanently. `sha256` is enforced
 * whenever the catalogue provides it.
 *
 * ── THIS PLUGIN IS NOT SELF-UPDATING ────────────────────────────────────────
 * Deliberately. It is the one plugin maintained by hand, which is what lets every
 * other plugin be updated safely. It must never appear in its own `plugins` list.
 */
final class Fleet
{
    /** @return array<int,array{plugin:string,action:string,from:?string,to:?string,detail:?string}> */
    public static function updateAll(): array
    {
        $results = [];

        foreach (self::managed() as $plugin) {
            $results[] = self::updateOne($plugin);
        }

        return $results;
    }

    /**
     * @return array{plugin:string,action:string,from:?string,to:?string,detail:?string}
     */
    public static function updateOne(string $plugin): array
    {
        $r = static fn(string $action, ?string $from = null, ?string $to = null, ?string $detail = null): array
            => ["plugin" => $plugin, "action" => $action, "from" => $from, "to" => $to, "detail" => $detail];

        if ($plugin === Config::name()) {
            // Updating ourselves would hit exactly the isRunning() guard this
            // plugin exists to avoid.
            return $r("skipped", null, null, "refusing to manage itself");
        }

        $dir = Config::pluginsDir() . "/" . $plugin;

        if (!is_dir($dir)) {
            return $r("skipped", null, null, "not installed");
        }

        $from  = self::installedVersion($dir);
        $entry = self::catalogue()[$plugin] ?? null;

        if ($entry === null) {
            return $r("skipped", $from, null, "not in the catalogue");
        }

        $to = (string) ($entry["version"] ?? "");

        if (preg_match('/^\d+\.\d+\.\d+/', $to) !== 1) {
            return $r("skipped", $from, null, "catalogue entry has no usable version");
        }

        if (!version_compare($to, $from, ">")) {
            return $r("current", $from, $to);
        }

        $zip = self::download($plugin, $entry);

        if ($zip === null) {
            return $r("failed", $from, $to, "download failed");
        }

        $bad = self::verify($zip, $plugin, $to, $entry["sha256"] ?? null);

        if ($bad !== null) {
            @unlink($zip);
            return $r("failed", $from, $to, $bad);
        }

        // handleUpdate() resolves the archive by BASENAME inside the system temp
        // directory, so it has to live there under a name we can pass through.
        $staged = sys_get_temp_dir() . "/" . basename($zip);

        if ($staged !== $zip && !@rename($zip, $staged)) {
            @unlink($zip);
            return $r("failed", $from, $to, "could not stage the archive in the temp directory");
        }

        $backup = Backup::take($dir);

        $out = Server::kernel(sprintf(
            '$f = $container->get("AppBundle\\\\Facade\\\\PluginFacade");
             try { $p = $f->handleUpdate(%s); echo "OK:", $p->getVersion(), PHP_EOL; }
             catch (\\Throwable $e) { echo "ERR:", get_class($e), ": ", $e->getMessage(), PHP_EOL; }',
            var_export(basename($staged), true)
        ));

        @unlink($staged);

        if ($out === null || !str_contains($out, "OK:")) {
            $detail = $out === null ? "kernel call failed" : trim(explode("ERR:", $out, 2)[1] ?? $out);
            Backup::restore($dir, $backup);
            return $r("failed", $from, $to, $detail);
        }

        if (!Health::check($dir)) {
            // UISP's facade has no rollback of its own; this is ours. An archive
            // can extract perfectly and still be unloadable, and without this the
            // first symptom would be every request to that plugin failing.
            Backup::restore($dir, $backup);
            Server::console("crm:plugin:update-database-information");
            Server::console("crm:plugin:symlink");
            Server::console("crm:plugin:ucrm-config");
            return $r("rolled-back", $from, $to, "new version failed its health check");
        }

        Backup::discard($backup);

        // UISP invalidated its caches inside the facade call — but that ran under
        // CLI, and APCu segments are per-SAPI, so the copy php-fpm reads is still
        // stale. This is the one step the shipped code cannot do from here.
        Server::invalidateZoneJsCache();

        return $r("updated", $from, $to);
    }

    /** @return string[] */
    public static function managed(): array
    {
        $raw = (string) (Config::get("plugins") ?? "");

        $names = preg_split('/[\s,]+/', trim($raw)) ?: [];

        return array_values(array_filter(
            array_map("trim", $names),
            static fn(string $n): bool => $n !== "" && $n !== Config::name()
        ));
    }

    private static function installedVersion(string $dir): string
    {
        $m = json_decode((string) @file_get_contents($dir . "/manifest.json"), true);

        return (string) ($m["information"]["version"] ?? "0.0.0");
    }

    /**
     * The catalogue, keyed by plugin name. Fetched once per run.
     *
     * @return array<string,array<string,mixed>>
     */
    public static function catalogue(bool $refresh = false): array
    {
        static $cache = null;

        if ($cache !== null && !$refresh) {
            return $cache;
        }

        $url = rtrim((string) Config::get("update_url"), "/") . "/plugins.json";

        $body = Http::get($url, 20, 8);

        if ($body === null) {
            error_log(sprintf("(catalogue) unreachable: %s", $url));
            return $cache = [];
        }

        $data = json_decode($body, true);

        if (!is_array($data) || !is_array($data["plugins"] ?? null)) {
            error_log("(catalogue) response is not a plugins.json document");
            return $cache = [];
        }

        $byName = [];

        foreach ($data["plugins"] as $entry) {
            if (is_array($entry) && isset($entry["name"])) {
                $byName[(string) $entry["name"]] = $entry;
            }
        }

        return $cache = $byName;
    }

    /** @param array<string,mixed> $entry */
    private static function download(string $plugin, array $entry): ?string
    {
        $url = (string) ($entry["zipUrl"] ?? "");

        if ($url === "") {
            return null;
        }

        $body = Http::get($url);

        if ($body === null || $body === "") {
            return null;
        }

        $tmp = sprintf("%s/%s-%s-%d.zip", sys_get_temp_dir(), $plugin, $entry["version"] ?? "0", getmypid());

        return @file_put_contents($tmp, $body) !== false ? $tmp : null;
    }

    /** @return string|null error, or null when acceptable */
    private static function verify(string $zipPath, string $plugin, string $version, ?string $expected): ?string
    {
        if ($expected !== null && $expected !== "") {
            // Optional, because a catalogue that omits it still works — but
            // enforced strictly when present.
            $expected = strtolower(trim($expected));

            if (preg_match('/^[0-9a-f]{64}$/', $expected) !== 1) {
                return "catalogue sha256 is not a digest";
            }

            if (hash_file("sha256", $zipPath) !== $expected) {
                return "checksum mismatch";
            }
        }

        $zip = new ZipArchive();

        if ($zip->open($zipPath) !== true) {
            return "not a readable ZIP";
        }

        try {
            $raw = $zip->getFromName("manifest.json");

            if ($raw === false) {
                return "no manifest.json at the ZIP root";
            }

            $m = json_decode($raw, true);

            if (($m["information"]["name"] ?? null) !== $plugin) {
                return sprintf("ZIP is for '%s', expected '%s'", (string) ($m["information"]["name"] ?? "?"), $plugin);
            }

            if (($m["information"]["version"] ?? null) !== $version) {
                return sprintf("ZIP says %s but 'latest' advertised %s", (string) ($m["information"]["version"] ?? "?"), $version);
            }
        } finally {
            $zip->close();
        }

        return null;
    }

}
