<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

use SpaethTech\Ucrm\Server;
use ZipArchive;
use SpaethTech\Ucrm\Plugin;
use SpaethTech\Ucrm\Http;
use SpaethTech\Ucrm\Log;

/**
 * Updates OTHER plugins, using UISP's own update path.
 *
 * ── WHY A SEPARATE PLUGIN ───────────────────────────────────────────────────
 * `PluginFacade::updatePlugin()` opens with:
 *
 *     if ($this->pluginDataFileManager->isRunning($plugin)) {
 *         throw new PluginUploadException('Plugin you are trying to update is currently running.');
 *     }
 *
 * `plugins.sh` holds `.ucrm-plugin-running` for the whole of a plugin's `main.php`,
 * so a plugin can never use that facade **on itself**. From here the lock belongs
 * to *this* plugin, the target's is free, and the guard passes — so UISP performs
 * the entire update: stage data/, replace files, rescan for zone JS, record the
 * version, recreate the web-root symlink, invalidate its caches.
 *
 * That removes the whole class of problems a self-updating plugin has: nothing
 * replaces the files it is executing from, so there is no autoload-after-swap
 * hazard, no detached process, and no race with the scheduler.
 *
 * And when a target *is* mid-run, the facade refuses and we simply try again next
 * tick — the guard becomes the feature rather than the obstacle.
 *
 * ── CATALOGUE ───────────────────────────────────────────────────────────────
 * `update_url` points at a directory serving `plugins.json`, whose shape follows
 * Ubiquiti's own index (Ubiquiti-App/UCRM-plugins) with `sha256` added:
 *
 *   { "plugins": [ { "name", "version", "zipUrl", "sha256", ... } ] }
 *
 * ONE fetch describes the whole catalogue. The earlier design read a per-plugin
 * `latest` file, which cost one request per managed plugin, per poll, per
 * instance — against an unauthenticated raw host that scales badly.
 *
 * `zipUrl` is expected to pin a commit SHA rather than a branch, so a published
 * version means one exact byte sequence permanently. `sha256` is enforced
 * whenever the catalogue provides it.
 *
 * ── THIS PLUGIN IS NOT SELF-UPDATING ────────────────────────────────────────
 * Deliberately. It is the one plugin maintained by hand, which is what lets every
 * other plugin be updated safely. It must never appear in its own `plugins` list.
 */
final class Fleet
{
    /** @return array<int,array{plugin:string,action:string,from:?string,to:?string,detail:?string}> */
    public static function updateAll(): array
    {
        $results = [];

        foreach (self::managed() as $plugin) {
            $results[] = self::updateOne($plugin);
        }

        return $results;
    }

    /**
     * @return array{plugin:string,action:string,from:?string,to:?string,detail:?string}
     */
    public static function updateOne(string $plugin): array
    {
        $r = static fn(string $action, ?string $from = null, ?string $to = null, ?string $detail = null): array
            => ["plugin" => $plugin, "action" => $action, "from" => $from, "to" => $to, "detail" => $detail];

        if ($plugin === Plugin::name()) {
            // Updating ourselves would hit exactly the isRunning() guard this
            // plugin exists to avoid.
            return $r("skipped", null, null, "refusing to manage itself");
        }

        $dir = Plugin::pluginsDir() . "/" . $plugin;

        if (!is_dir($dir)) {
            return $r("skipped", null, null, "not installed");
        }

        $from   = self::installedVersion($dir);
        $target = self::target($plugin);

        if ($target["error"] !== null) {
            return $r("skipped", $from, null, $target["error"]);
        }

        $to = $target["version"];

        if (preg_match('/^\d+\.\d+\.\d+/', $to) !== 1) {
            return $r("skipped", $from, null, "no usable version for ref '" . $target["ref"] . "'");
        }

        // A PIN means "be exactly this", so it moves in either direction — the
        // whole point of pinning to an older version is to go back to it. @latest
        // and a branch only ever move forward, where a lower advertised version
        // means the index regressed, not that a downgrade was asked for.
        $needed = $target["kind"] === "version"
            ? $to !== $from
            : version_compare($to, $from, ">");

        if (!$needed) {
            return $r("current", $from, $to);
        }

        $zip = self::download($plugin, $target["zipUrl"], $to);

        if ($zip === null) {
            return $r("failed", $from, $to, "download failed: " . $target["zipUrl"]);
        }

        $bad = self::verify($zip, $plugin, $to, $target["sha256"]);

        if ($bad !== null) {
            @unlink($zip);
            return $r("failed", $from, $to, $bad);
        }

        // handleUpdate() resolves the archive by BASENAME inside the system temp
        // directory, so it has to live there under a name we can pass through.
        $staged = sys_get_temp_dir() . "/" . basename($zip);

        if ($staged !== $zip && !@rename($zip, $staged)) {
            @unlink($zip);
            return $r("failed", $from, $to, "could not stage the archive in the temp directory");
        }

        // PREFLIGHT. handleUpdate() deletes the old tree before writing the new
        // one, so a directory this process cannot write gets the plugin half
        // destroyed before anything notices — and then Backup::restore() hits the
        // same wall, because the update and its own safety net need the identical
        // permission. Learned the hard way: a plugin left root-owned by an
        // out-of-band run lost its data/ contents and could not be rolled back.
        //
        // Everything in normal operation runs as the web user (plugins.sh for cron,
        // php-fpm for the routes), so this should never fire. When it does, the
        // install is already inconsistent and refusing is the only safe move.
        $blocked = self::unwritable($dir);

        if ($blocked !== null) {
            return $r("skipped", $from, $to, sprintf(
                "%s is not writable by %s — refusing to start an update that could not be rolled back",
                $blocked,
                self::whoami()
            ));
        }

        $backup = Backup::take($dir);

        $out = Server::kernel(sprintf(
            '$f = $container->get("AppBundle\\\\Facade\\\\PluginFacade");
             try { $p = $f->handleUpdate(%s); echo "OK:", $p->getVersion(), PHP_EOL; }
             catch (\\Throwable $e) { echo "ERR:", get_class($e), ": ", $e->getMessage(), PHP_EOL; }',
            var_export(basename($staged), true)
        ));

        @unlink($staged);

        if ($out === null || !str_contains($out, "OK:")) {
            $detail = $out === null ? "kernel call failed" : trim(explode("ERR:", $out, 2)[1] ?? $out);
            Backup::restore($dir, $backup);
            return $r("failed", $from, $to, $detail);
        }

        if (!Health::check($dir)) {
            // UISP's facade has no rollback of its own; this is ours. An archive
            // can extract perfectly and still be unloadable, and without this the
            // first symptom would be every request to that plugin failing.
            Backup::restore($dir, $backup);
            Server::console("crm:plugin:update-database-information");
            Server::console("crm:plugin:symlink");
            Server::console("crm:plugin:ucrm-config");
            return $r("rolled-back", $from, $to, "new version failed its health check");
        }

        Backup::discard($backup);

        // UISP invalidated its caches inside the facade call — but that ran under
        // CLI, and APCu segments are per-SAPI, so the copy php-fpm reads is still
        // stale. This is the one step the shipped code cannot do from here.
        Server::invalidateZoneJsCache();

        return $r("updated", $from, $to);
    }

    /**
     * Install a plugin that is not yet present.
     *
     * Distinct from updateOne(): UISP's facade has separate entry points, and
     * handleInstall() takes a URL it fetches itself rather than a staged archive.
     * It refuses if the plugin already exists, so this checks first and reports
     * that plainly rather than surfacing UISP's exception.
     *
     * Deliberately does NOT enable the result. UISP leaves a freshly installed
     * plugin disabled until it is configured, and silently enabling something
     * unconfigured would be a surprise — the operator enables it.
     *
     * @return array{plugin:string,action:string,from:?string,to:?string,detail:?string}
     */
    public static function install(string $plugin): array
    {
        $r = static fn(string $action, ?string $to = null, ?string $detail = null): array
            => ["plugin" => $plugin, "action" => $action, "from" => null, "to" => $to, "detail" => $detail];

        if ($plugin === Plugin::name()) {
            return $r("skipped", null, "refusing to manage itself");
        }

        if (is_dir(Plugin::pluginsDir() . "/" . $plugin)) {
            return $r("skipped", null, "already installed");
        }

        $target = self::target($plugin);

        if ($target["error"] !== null) {
            return $r("failed", null, $target["error"]);
        }

        $url = $target["zipUrl"];
        $to  = $target["version"];

        if ($url === "") {
            return $r("failed", $to, "no artifact URL for ref '" . $target["ref"] . "'");
        }

        $out = Server::kernel(sprintf(
            '$f = $container->get("AppBundle\\Facade\\PluginFacade");
             try { $p = $f->handleInstall(%s); echo "OK:", $p->getVersion(), PHP_EOL; }
             catch (\Throwable $e) { echo "ERR:", $e->getMessage(), PHP_EOL; }',
            var_export($url, true)
        ));

        if ($out === null || !str_contains($out, "OK:")) {
            $detail = $out === null ? "kernel call failed" : trim(explode("ERR:", $out, 2)[1] ?? $out);
            return $r("failed", $to, $detail);
        }

        // A newly installed plugin may ship zone JS; UISP recorded that under CLI,
        // where the cache php-fpm reads cannot be touched.
        Server::invalidateZoneJsCache();

        return $r("installed", $to);
    }

    /**
     * Install a plugin AND whatever it needs, dependencies first.
     *
     * Auto-installing rather than refusing until the operator has satisfied the
     * graph by hand: the catalogue already knows the answer, and a button that
     * says "cannot install, go install these two first" is asking a person to do
     * a machine's arithmetic.
     *
     * Stops at the first failed dependency and does NOT install the requested
     * plugin. Installing something whose dependency is missing produces a plugin
     * that is present and broken, which is harder to diagnose than one that was
     * never installed.
     *
     * Deliberately does NOT roll back dependencies already installed when a later
     * one fails. They are complete, working installs of things the catalogue
     * offers, and tearing them out would turn one failure into several.
     *
     * @return array{plugin:string,action:string,from:?string,to:?string,detail:?string,dependencies:array<int,array<string,mixed>>}
     */
    public static function installTree(string $plugin): array
    {
        $fail = static fn(string $detail, array $deps = []): array => [
            "plugin"       => $plugin,
            "action"       => "failed",
            "from"         => null,
            "to"           => null,
            "detail"       => $detail,
            "dependencies" => $deps,
        ];

        $resolution = Dependencies::resolve($plugin);

        // Both of these mean the catalogue is wrong. Name the offending entries
        // rather than failing with something the operator cannot act on.
        if ($resolution["cycle"] !== []) {
            return $fail("dependency cycle through: " . implode(", ", $resolution["cycle"]));
        }

        if ($resolution["unresolved"] !== []) {
            return $fail("depends on plugins not in the catalogue: " . implode(", ", $resolution["unresolved"]));
        }

        $installed = [];

        foreach ($resolution["order"] as $dependency) {
            $result      = self::install($dependency);
            $installed[] = $result;

            if ($result["action"] === "failed") {
                return $fail(
                    sprintf("dependency '%s' failed to install: %s", $dependency, (string) $result["detail"]),
                    $installed
                );
            }
        }

        return self::install($plugin) + ["dependencies" => $installed];
    }

    /**
     * The `plugins` setting, parsed. Each entry is `name` or `name@ref`.
     *
     * @return array<int,array{name:string,ref:string,kind:string}>
     */
    public static function managedRefs(): array
    {
        // Memoised, and not only to save the parse: refFor() calls this once per
        // plugin per request, so without it every warning below is logged as many
        // times as there are catalogue entries.
        static $specs = null;

        if ($specs !== null) {
            return $specs;
        }

        $raw    = (string) (Plugin::get("plugins") ?? "");
        $tokens = preg_split('/[\s,]+/', trim($raw)) ?: [];
        $specs  = [];
        $seen   = [];

        foreach ($tokens as $token) {
            $token = trim($token);

            if ($token === "") {
                continue;
            }

            $spec = Ref::parse($token);

            if ($spec === null) {
                // Loud, because a typo here silently stops managing a plugin —
                // which looks exactly like "nothing to update".
                Log::writef("(config) ignoring unparseable plugins entry: %s", $token);
                continue;
            }

            // Managing ourselves would hit the isRunning() guard this plugin
            // exists to avoid.
            if ($spec["name"] === Plugin::name()) {
                continue;
            }

            if (isset($seen[$spec["name"]])) {
                // First wins, but say so. Two entries for one plugin can only be
                // a mistake, and the failure otherwise is "my pin does nothing".
                Log::writef(
                    "(config) duplicate plugins entry for %s — keeping @%s, ignoring @%s",
                    $spec["name"],
                    $seen[$spec["name"]],
                    $spec["ref"]
                );
                continue;
            }

            $seen[$spec["name"]] = $spec["ref"];
            $specs[]             = $spec;
        }

        return $specs;
    }

    /** @return string[] */
    public static function managed(): array
    {
        return array_values(array_map(
            static fn(array $spec): string => $spec["name"],
            self::managedRefs()
        ));
    }

    /**
     * The first directory under $dir this process could not modify, or null.
     *
     * DIRECTORIES, not files — deleting a file needs write on its parent, not on
     * the file, so a read-only file inside a writable directory is not a problem
     * and flagging it would refuse updates that would have worked. The root is
     * included: removing `data/` from it is what failed in the case this exists
     * to prevent.
     */
    private static function unwritable(string $dir): ?string
    {
        if (!is_writable($dir)) {
            return $dir;
        }

        $walk = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($walk as $path) {
            if ($path->isDir() && !is_writable((string) $path)) {
                return (string) $path;
            }
        }

        return null;
    }

    /** Best-effort process owner, for an error message that says who to chown to. */
    private static function whoami(): string
    {
        if (function_exists("posix_getpwuid") && function_exists("posix_geteuid")) {
            $user = @posix_getpwuid(posix_geteuid());

            if (is_array($user) && isset($user["name"])) {
                return (string) $user["name"];
            }
        }

        return "this process";
    }

    private static function installedVersion(string $dir): string
    {
        $m = json_decode((string) @file_get_contents($dir . "/manifest.json"), true);

        return (string) ($m["information"]["version"] ?? "0.0.0");
    }

    /**
     * The catalogue at `update_url`, keyed by plugin name.
     *
     * @return array<string,array<string,mixed>>
     */
    public static function catalogue(bool $refresh = false): array
    {
        return self::index(rtrim((string) Plugin::get("update_url"), "/"), $refresh);
    }

    /**
     * The catalogue served under any base URL, keyed by plugin name.
     *
     * Cached per base, because a run that resolves several branch-pinned plugins
     * would otherwise refetch the same index once per plugin.
     *
     * @return array<string,array<string,mixed>>
     */
    public static function index(string $base, bool $refresh = false): array
    {
        static $cache = [];

        $base = rtrim($base, "/");

        if (isset($cache[$base]) && !$refresh) {
            return $cache[$base];
        }

        $url  = $base . "/plugins.json";
        $body = Http::get($url, 20, 8);

        if ($body === null) {
            Log::writef("(catalogue) unreachable: %s", $url);
            return $cache[$base] = [];
        }

        $data = json_decode($body, true);

        if (!is_array($data) || !is_array($data["plugins"] ?? null)) {
            Log::writef("(catalogue) not a plugins.json document: %s", $url);
            return $cache[$base] = [];
        }

        $byName = [];

        foreach ($data["plugins"] as $entry) {
            if (is_array($entry) && isset($entry["name"])) {
                $byName[(string) $entry["name"]] = $entry;
            }
        }

        return $cache[$base] = $byName;
    }

    /**
     * Which build of a plugin we are tracking, from the `plugins` setting.
     *
     * A plugin not listed there is treated as `@latest`. That covers the whole
     * catalogue rather than only managed plugins, which is what lets the plugin
     * list page describe an install we do not manage.
     *
     * @return array{name:string,ref:string,kind:string}
     */
    public static function refFor(string $plugin): array
    {
        foreach (self::managedRefs() as $spec) {
            if ($spec["name"] === $plugin) {
                return $spec;
            }
        }

        return ["name" => $plugin, "ref" => Ref::LATEST, "kind" => Ref::LATEST];
    }

    /**
     * Where a plugin's tracked build lives, and what version it is.
     *
     * The single point that turns a ref into an artifact. `error` is set instead
     * of throwing so a broken entry for one plugin does not stop a fleet update —
     * and so the reason reaches the log rather than a stack trace.
     *
     * @return array{ref:string,kind:string,version:string,zipUrl:string,sha256:?string,error:?string}
     */
    public static function target(string $plugin): array
    {
        $spec = self::refFor($plugin);

        $out = static fn(string $version, string $zipUrl, ?string $sha256, ?string $error = null): array => [
            "ref"     => $spec["ref"],
            "kind"    => $spec["kind"],
            "version" => $version,
            "zipUrl"  => $zipUrl,
            "sha256"  => $sha256,
            "error"   => $error,
        ];

        // @latest — the catalogue we already fetch, unchanged. Keeps its sha256.
        if ($spec["kind"] === Ref::LATEST) {
            $entry = self::catalogue()[$plugin] ?? null;

            return $entry === null
                ? $out("", "", null, "not in the catalogue")
                : $out(
                    (string) ($entry["version"] ?? ""),
                    (string) ($entry["zipUrl"] ?? ""),
                    isset($entry["sha256"]) ? (string) $entry["sha256"] : null
                );
        }

        $base = Ref::rebase((string) Plugin::get("update_url"), $spec["ref"]);

        if ($base === null) {
            // update_url is not `<base>/<ref>`, so there is no segment to swap.
            // Say that rather than fabricate a URL and report its 404 as a missing
            // version.
            return $out("", "", null, "update_url has no ref segment to pin against");
        }

        // @<branch> — the same catalogue, published from another ref. Reading it
        // is what yields the branch's current version AND its sha256, so a branch
        // pin keeps the integrity check that a version pin cannot have.
        if ($spec["kind"] === "branch") {
            $entry = self::index($base)[$plugin] ?? null;

            return $entry === null
                ? $out("", "", null, sprintf("not in the catalogue on '%s'", $spec["ref"]))
                : $out(
                    (string) ($entry["version"] ?? ""),
                    (string) ($entry["zipUrl"] ?? ""),
                    isset($entry["sha256"]) ? (string) $entry["sha256"] : null
                );
        }

        // @<version> — no catalogue. An index only ever describes what is current,
        // and a pin exists precisely to reach what is not. The tag is per-plugin
        // because one repo holds several.
        $version = Ref::version($spec["ref"]);
        $tagged  = Ref::rebase((string) Plugin::get("update_url"), sprintf("%s-v%s", $plugin, $version));

        return $out(
            $version,
            sprintf("%s/plugins/%s/%s.zip", $tagged, $plugin, $plugin),
            null // nothing publishes a digest for a version the index has moved past
        );
    }

    private static function download(string $plugin, string $url, string $version): ?string
    {
        if ($url === "") {
            return null;
        }

        $body = Http::get($url);

        if ($body === null || $body === "") {
            return null;
        }

        $tmp = sprintf("%s/%s-%s-%d.zip", sys_get_temp_dir(), $plugin, $version, getmypid());

        return @file_put_contents($tmp, $body) !== false ? $tmp : null;
    }

    /** @return string|null error, or null when acceptable */
    private static function verify(string $zipPath, string $plugin, string $version, ?string $expected): ?string
    {
        if ($expected !== null && $expected !== "") {
            // Optional, because a catalogue that omits it still works — but
            // enforced strictly when present.
            $expected = strtolower(trim($expected));

            if (preg_match('/^[0-9a-f]{64}$/', $expected) !== 1) {
                return "catalogue sha256 is not a digest";
            }

            if (hash_file("sha256", $zipPath) !== $expected) {
                return "checksum mismatch";
            }
        }

        $zip = new ZipArchive();

        if ($zip->open($zipPath) !== true) {
            return "not a readable ZIP";
        }

        try {
            $raw = $zip->getFromName("manifest.json");

            if ($raw === false) {
                return "no manifest.json at the ZIP root";
            }

            $m = json_decode($raw, true);

            if (($m["information"]["name"] ?? null) !== $plugin) {
                return sprintf("ZIP is for '%s', expected '%s'", (string) ($m["information"]["name"] ?? "?"), $plugin);
            }

            if (($m["information"]["version"] ?? null) !== $version) {
                return sprintf("ZIP says %s but 'latest' advertised %s", (string) ($m["information"]["version"] ?? "?"), $version);
            }
        } finally {
            $zip->close();
        }

        return null;
    }

}
