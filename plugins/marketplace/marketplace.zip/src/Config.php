<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

use RuntimeException;

/**
 * This plugin's own configuration and location.
 *
 * data/config.json ships with defaults — supported by UISP ("you don't need to
 * create this file unless you want to set default values"). Because data/ is
 * preserved across updates, those defaults apply on first install and never
 * overwrite an operator's edits afterwards.
 */
final class Config
{
    /** @var array<string,mixed>|null */
    private static ?array $config = null;

    public static function dir(): string
    {
        return dirname(__DIR__);
    }

    /** Our own plugin name, derived from the install directory so it cannot drift. */
    public static function name(): string
    {
        return basename(self::dir());
    }

    /** The directory UISP installs every plugin into — our own parent. */
    public static function pluginsDir(): string
    {
        return dirname(self::dir());
    }

    /**
     * This plugin's own public.php as reachable from INSIDE UISP.
     *
     * Built from ucrm.json's scheme/host and pluginPublicUrl's path. Note that
     * ucrmLocalUrl is "http://localhost/crm/" — it already carries the /crm prefix
     * that the path also has, so naive concatenation yields /crm/crm/... which
     * UISP accepts and then never serves.
     */
    public static function localUrl(string $route = ""): string
    {
        $path = self::dir() . "/ucrm.json";

        if (!is_readable($path)) {
            throw new RuntimeException("cannot read $path");
        }

        $u = json_decode((string) file_get_contents($path), true);

        $scheme = parse_url((string) ($u["ucrmLocalUrl"] ?? ""), PHP_URL_SCHEME);
        $host   = parse_url((string) ($u["ucrmLocalUrl"] ?? ""), PHP_URL_HOST);
        $port   = parse_url((string) ($u["ucrmLocalUrl"] ?? ""), PHP_URL_PORT);
        $p      = parse_url((string) ($u["pluginPublicUrl"] ?? ""), PHP_URL_PATH);

        if (!is_string($scheme) || !is_string($host) || !is_string($p) || $p === "") {
            throw new RuntimeException("ucrm.json missing or malformed ucrmLocalUrl / pluginPublicUrl");
        }

        return $scheme . "://" . $host . ($port !== null ? ":" . $port : "") . $p
             . ($route !== "" ? "?route=" . $route : "");
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        if (self::$config === null) {
            $path = self::dir() . "/data/config.json";

            if (!is_readable($path)) {
                throw new RuntimeException("cannot read $path — has UISP finished installing the plugin?");
            }

            $data = json_decode((string) file_get_contents($path), true);

            if (!is_array($data)) {
                throw new RuntimeException("$path is not valid JSON");
            }

            self::$config = $data;
        }

        $value = self::$config[$key] ?? $default;

        return ($value === "" ) ? $default : $value;
    }
}
