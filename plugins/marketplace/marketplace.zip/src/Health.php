<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

use SpaethTech\Ucrm\Log;

/**
 * Does an updated plugin actually load?
 *
 * UISP's facade verifies the ARCHIVE, not the result — an archive can extract
 * perfectly and still be unloadable (a truncated vendor/, a missing autoloader).
 * Without this the first symptom is every request to that plugin failing, long
 * after the update looked successful.
 *
 * Runs in a fresh process so it sees the new files rather than anything this
 * process already holds.
 */
final class Health
{
    public static function check(string $dir): bool
    {
        $probe = <<<'PHP'
            $dir = $argv[1];
            foreach (["manifest.json", "main.php"] as $required) {
                if (!is_file("$dir/$required")) { fwrite(STDERR, "missing $required\n"); exit(1); }
            }
            $m = json_decode((string) file_get_contents("$dir/manifest.json"), true);
            if (!is_array($m) || ($m["information"]["version"] ?? null) === null) {
                fwrite(STDERR, "manifest unreadable\n"); exit(1);
            }
            // vendor/ is optional — not every plugin uses Composer — but if it is
            // present it must load, since that is the usual casualty of a bad ZIP.
            if (is_dir("$dir/vendor") && !@include_once("$dir/vendor/autoload.php")) {
                fwrite(STDERR, "vendor present but autoload failed\n"); exit(1);
            }
            exit(0);
            PHP;

        exec(
            sprintf("%s -r %s %s 2>&1", escapeshellarg(\SpaethTech\Ucrm\Server::php()), escapeshellarg($probe), escapeshellarg($dir)),
            $out,
            $code
        );

        if ($code !== 0) {
            Log::writef("(health) %s failed: %s", basename($dir), implode(" | ", $out));
        }

        return $code === 0;
    }
}
