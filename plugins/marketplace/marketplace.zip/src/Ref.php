<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

/**
 * `name@ref` — which build of a managed plugin to track.
 *
 * ── SYNTAX ──────────────────────────────────────────────────────────────────
 *
 *   provisioner-v3                  same as @latest
 *   provisioner-v3@latest           the catalogue's current version
 *   provisioner-v3@3.7.2            pinned to exactly that version
 *   provisioner-v3@testing          tracks the tip of that branch
 *
 * Go modules and npm both spell it this way, so `@` is one namespace of refs
 * rather than two axes to keep straight. A ref that parses as a version is a
 * version; anything else is a branch. There is no separate channel axis —
 * "which catalogue" and "which build" collapse into the same question, which is
 * exactly why one separator is enough.
 *
 * ── WHAT A REF RESOLVES TO ──────────────────────────────────────────────────
 * By CONVENTION on the artifact host, not by asking it. `update_url`'s last path
 * segment is the git ref, so swapping that segment reaches any other ref:
 *
 *   https://raw.githubusercontent.com/archous-networks/marketplace-plugins/main
 *   └──────────────────── base ────────────────────────────────────────┘ └ref┘
 *
 *   @latest    read the catalogue at update_url, unchanged
 *   @<branch>  read the catalogue at <base>/<branch>/plugins.json
 *   @<version> no catalogue — go straight to
 *              <base>/<name>-v<version>/plugins/<name>/<name>.zip
 *
 * The version case is deliberately catalogue-free: a pin has to reach a build
 * that is no longer current, and an index only ever describes what is. It has a
 * real cost — **no `sha256` to check a pinned archive against**, because nothing
 * publishes one for a version the index has moved past. `Fleet::verify()` still
 * opens the ZIP and rejects a manifest whose name or version is not the one asked
 * for, so a wrong artifact is still caught; a tampered one is not.
 *
 * This also means **published versions must be tagged** `<name>-v<version>`, which
 * `bin/publish.sh` in `marketplace-plugins` does on release. The tag is per-plugin
 * because one repo holds several, and a bare `v3.7.2` could not say whose.
 */
final class Ref
{
    public const LATEST = "latest";

    /**
     * Parse one entry from the `plugins` setting.
     *
     * @return array{name:string,ref:string,kind:string}|null null when the token
     *         is not a usable `name` or `name@ref`
     */
    public static function parse(string $token): ?array
    {
        $token = trim($token);

        if ($token === "") {
            return null;
        }

        $at   = strpos($token, "@");
        $name = $at === false ? $token : substr($token, 0, $at);
        $ref  = $at === false ? self::LATEST : trim(substr($token, $at + 1));

        // Same alphabet the install path is built from — see the plugin manifest
        // docs. A name outside it cannot be a plugin directory.
        if (preg_match('/^[a-zA-Z0-9_-]+$/', $name) !== 1) {
            return null;
        }

        if ($ref === "") {
            $ref = self::LATEST;
        }

        // Git refs are permissive; this is the subset that survives being a path
        // segment in an artifact URL.
        if (preg_match('~^[A-Za-z0-9._/-]+$~', $ref) !== 1) {
            return null;
        }

        return ["name" => $name, "ref" => $ref, "kind" => self::kind($ref)];
    }

    /** "latest" | "version" | "branch" */
    public static function kind(string $ref): string
    {
        if ($ref === self::LATEST) {
            return self::LATEST;
        }

        // Accept a leading v so `@v3.7.2` and `@3.7.2` mean the same thing —
        // people write both, and refusing one would be a papercut with no upside.
        return preg_match('/^v?\d+\.\d+\.\d+/', $ref) === 1 ? "version" : "branch";
    }

    /** A version ref, without any leading `v`. */
    public static function version(string $ref): string
    {
        return ltrim($ref, "vV");
    }

    /**
     * `update_url` with its trailing ref segment replaced.
     *
     * Returns null when update_url is not shaped like `<base>/<ref>` — in which
     * case pinning cannot work and the caller should say so rather than guess at
     * a URL and report a 404 as if the version were missing.
     */
    public static function rebase(string $updateUrl, string $ref): ?string
    {
        $trimmed = rtrim($updateUrl, "/");
        $cut     = strrpos($trimmed, "/");

        // Needs to be a real path segment, not the "//" of the scheme.
        if ($cut === false || $cut < 8 || substr($trimmed, $cut - 1, 1) === "/") {
            return null;
        }

        return substr($trimmed, 0, $cut) . "/" . $ref;
    }
}
