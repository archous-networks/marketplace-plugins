<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

/**
 * Copy a plugin aside so a failed update can be undone.
 *
 * UISP's facade has no rollback: `PluginFileManager::upgrade()` deletes and
 * extracts, and a bad archive leaves the plugin broken with nothing to restore
 * from. This supplies that.
 *
 * The backup lives OUTSIDE the target directory, as a sibling under the plugins
 * directory — `upgrade()` calls `delete($plugin)`, which removes the target
 * wholesale, so a backup kept inside it would be destroyed by the very operation
 * it exists to protect. Sibling placement also keeps it on the same filesystem,
 * which matters because rename() cannot cross mounts (/tmp is a separate mount
 * inside the ucrm container — a lesson from the provisioner's own updater).
 *
 * A copy, not a rename: the target must stay in place for UISP to update it.
 */
final class Backup
{
    /** @return string|null the backup path, or null if it could not be taken */
    public static function take(string $dir): ?string
    {
        $backup = sprintf("%s/.backup-%s-%d", dirname($dir), basename($dir), getmypid());

        self::remove($backup);

        if (!self::copyTree($dir, $backup)) {
            self::remove($backup);
            error_log(sprintf("(backup) could not back up %s — continuing WITHOUT a rollback path", basename($dir)));
            return null;
        }

        return $backup;
    }

    /**
     * Put the previous version back.
     *
     * Best-effort and deliberately noisy only in the log: this runs when an update
     * has already failed, and the priority is leaving something that works, not
     * reporting perfectly.
     */
    public static function restore(string $dir, ?string $backup): bool
    {
        if ($backup === null || !is_dir($backup)) {
            error_log(sprintf("(backup) no backup available for %s — cannot roll back", basename($dir)));
            return false;
        }

        self::remove($dir);

        if (!@rename($backup, $dir)) {
            // Fall back to copying: rename can fail if something still holds the
            // path. Losing the backup here would be the worst outcome.
            if (!self::copyTree($backup, $dir)) {
                error_log(sprintf("(backup) ROLLBACK FAILED for %s — backup left at %s", basename($dir), $backup));
                return false;
            }

            self::remove($backup);
        }

        error_log(sprintf("(backup) rolled %s back to the previous version", basename($dir)));

        return true;
    }

    public static function discard(?string $backup): void
    {
        if ($backup !== null) {
            self::remove($backup);
        }
    }

    private static function copyTree(string $src, string $dst): bool
    {
        if (!is_dir($src)) {
            return false;
        }

        if (!is_dir($dst) && !@mkdir($dst, 0775, true)) {
            return false;
        }

        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($src, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($items as $item) {
            $target = $dst . "/" . substr($item->getPathname(), strlen($src) + 1);

            if ($item->isLink()) {
                @symlink((string) readlink($item->getPathname()), $target);
                continue;
            }

            if ($item->isDir()) {
                if (!is_dir($target) && !@mkdir($target, 0775, true)) {
                    return false;
                }
                continue;
            }

            if (!@copy($item->getPathname(), $target)) {
                return false;
            }
        }

        return true;
    }

    private static function remove(string $path): void
    {
        if (is_link($path) || is_file($path)) {
            @unlink($path);
            return;
        }

        if (!is_dir($path)) {
            return;
        }

        foreach (scandir($path) ?: [] as $name) {
            if ($name !== "." && $name !== "..") {
                self::remove($path . "/" . $name);
            }
        }

        @rmdir($path);
    }
}
