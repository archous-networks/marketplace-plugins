<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater\Ucrm;

use PDO;
use RuntimeException;
use Symfony\Component\Yaml\Yaml;

/**
 * Direct access to UISP's own Postgres database.
 *
 * Used ONLY where UISP exposes no supported API. Today that means webhook
 * endpoint registration — see the `ucrm-api` skill: webhook endpoint CRUD exists
 * solely as admin-UI routes, confirmed against both the container's route cache
 * and the published API blueprint. Everything else must go through the REST API.
 *
 * Connection parameters come from UISP's own `parameters.yml`, which the plugin
 * can read because it runs inside the `ucrm` container as the same user. Nothing
 * is hardcoded and no credential is stored by the plugin.
 */
final class Database
{
    private const PARAMETERS = "/usr/src/ucrm/app/config/parameters.yml";

    private static ?PDO $ucrm = null;

    /** @var array<string,mixed>|null */
    private static ?array $parameters = null;

    /**
     * PDO handle with the search path set to UISP's CRM schema.
     */
    public static function ucrm(): PDO
    {
        if (self::$ucrm instanceof PDO) {
            return self::$ucrm;
        }

        $p = self::parameters();

        $dsn = sprintf(
            "pgsql:host=%s;port=%s;dbname=%s",
            $p["database_host"],
            $p["database_port"],
            $p["database_name"]
        );

        $pdo = new PDO($dsn, (string) $p["database_user"], (string) $p["database_password"], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);

        // Schema name is configuration, not a constant — read it rather than
        // assuming "ucrm".
        $schema = (string) ($p["database_schema_ucrm"] ?? "ucrm");
        $pdo->exec(sprintf('SET search_path TO %s', $pdo->quote($schema) === "''" ? "ucrm" : $schema));

        return self::$ucrm = $pdo;
    }

    /**
     * @return array<string,mixed>
     */
    private static function parameters(): array
    {
        if (self::$parameters !== null) {
            return self::$parameters;
        }

        if (!is_readable(self::PARAMETERS)) {
            throw new RuntimeException(
                "cannot read " . self::PARAMETERS . " — is this running inside the ucrm container?"
            );
        }

        $parsed = Yaml::parseFile(self::PARAMETERS);
        $params = $parsed["parameters"] ?? null;

        if (!is_array($params)) {
            throw new RuntimeException("no `parameters` key in " . self::PARAMETERS);
        }

        foreach (["database_host", "database_port", "database_name", "database_user", "database_password"] as $required) {
            if (!array_key_exists($required, $params)) {
                throw new RuntimeException("missing `$required` in " . self::PARAMETERS);
            }
        }

        return self::$parameters = $params;
    }
}
