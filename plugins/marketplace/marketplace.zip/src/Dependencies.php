<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;
use SpaethTech\Ucrm\Plugin;

/**
 * Which Archous plugins need which other Archous plugins.
 *
 * ── WHERE THE EDGES COME FROM ───────────────────────────────────────────────
 * The CATALOGUE, via an optional `"dependencies": []` on each plugins.json entry.
 * Not manifest.json — UISP validates that file against its own schema and has no
 * dependency concept, so an extra key there is a bet on validation staying lax.
 * The catalogue is ours and already has to be fetched.
 *
 * The cost is worth naming: the catalogue describes the LATEST version of each
 * plugin, so what is read here are the dependencies of the version we would
 * install, not necessarily of the version on disk. In practice they move together;
 * where they do not, the graph errs toward over-protecting an installed plugin,
 * which is the safe direction.
 *
 * ── SCOPE ───────────────────────────────────────────────────────────────────
 * Only plugins in our catalogue participate. A Ubiquiti plugin cannot depend on
 * one of ours and cannot be depended upon, so its rows are never touched. That is
 * a deliberate boundary, not a gap: this plugin has no standing to block an action
 * on something it does not distribute.
 */
final class Dependencies
{
    /**
     * Dependencies a plugin declares, per the catalogue.
     *
     * A self-reference is dropped rather than reported as a cycle — it can only be
     * a typo, and treating it as a cycle would make one wrong character block the
     * install with a confusing message.
     *
     * @return string[]
     */
    public static function declared(string $plugin): array
    {
        $entry = Fleet::catalogue()[$plugin] ?? null;
        $deps  = is_array($entry) ? ($entry["dependencies"] ?? []) : [];

        if (!is_array($deps)) {
            return [];
        }

        $out = [];

        foreach ($deps as $dep) {
            $dep = trim((string) $dep);

            if ($dep !== "" && $dep !== $plugin) {
                $out[] = $dep;
            }
        }

        return array_values(array_unique($out));
    }

    public static function isInstalled(string $plugin): bool
    {
        return is_dir(Plugin::pluginsDir() . "/" . $plugin);
    }

    /**
     * What installing $plugin would also have to install, in the order to do it.
     *
     * `order` is post-order depth-first, so every entry precedes anything that
     * needs it, and it lists only what is actually missing — an installed
     * dependency is a satisfied one, whatever version it is at.
     *
     * `unresolved` and `cycle` are reported rather than thrown so a caller can put
     * them in front of the operator. Both mean the catalogue is wrong, and the
     * operator is not the one who can fix it — but "Install" silently doing nothing
     * is worse than a message naming the broken entry.
     *
     * @return array{order:string[],unresolved:string[],cycle:string[]}
     */
    public static function resolve(string $plugin): array
    {
        $state      = [];
        $visited    = [];
        $unresolved = [];
        $cycle      = [];

        self::visit($plugin, $state, $visited, $unresolved, $cycle);

        $order = [];

        foreach ($visited as $name) {
            if ($name !== $plugin && !self::isInstalled($name)) {
                $order[] = $name;
            }
        }

        return [
            "order"      => $order,
            "unresolved" => array_values(array_unique($unresolved)),
            "cycle"      => array_values(array_unique($cycle)),
        ];
    }

    /**
     * Installed plugins that declare $plugin as a dependency.
     *
     * DIRECT dependents only, which is sufficient for guarding removal: in a chain
     * A → B → C, C is held by B and B is held by A, so no link can be pulled out
     * from the middle. Walking transitively would only add names the operator would
     * have to remove later anyway.
     *
     * @return string[]
     */
    public static function dependents(string $plugin): array
    {
        $out = [];

        foreach (array_keys(Fleet::catalogue()) as $name) {
            $name = (string) $name;

            if ($name === $plugin || !self::isInstalled($name)) {
                continue;
            }

            if (in_array($plugin, self::declared($name), true)) {
                $out[] = $name;
            }
        }

        sort($out);

        return $out;
    }

    /**
     * @param array<string,int> $state    0/absent = unseen, 1 = on the stack, 2 = done
     * @param string[]          $visited  post-order accumulator
     * @param string[]          $unresolved
     * @param string[]          $cycle
     */
    private static function visit(
        string $plugin,
        array &$state,
        array &$visited,
        array &$unresolved,
        array &$cycle
    ): void {
        $seen = $state[$plugin] ?? 0;

        if ($seen === 2) {
            return;
        }

        if ($seen === 1) {
            // Back edge: this name is still on the stack, so following it again
            // would not terminate.
            $cycle[] = $plugin;
            return;
        }

        $state[$plugin] = 1;

        $catalogue = Fleet::catalogue();

        foreach (self::declared($plugin) as $dep) {
            if (!isset($catalogue[$dep])) {
                // Named but not distributed by us. Not something an operator can
                // resolve by installing something else.
                $unresolved[] = $dep;
                continue;
            }

            self::visit($dep, $state, $visited, $unresolved, $cycle);
        }

        $state[$plugin] = 2;
        $visited[]      = $plugin;
    }
}
