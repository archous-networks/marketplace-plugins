<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

use SpaethTech\Ucrm\Auth as Ucrm;
use SpaethTech\Ucrm\Log;

/**
 * Who is calling public.php?
 *
 * `public.php` is served with NO authentication — Ubiquiti's own docs say so —
 * and this plugin can install arbitrary archives. An unauthenticated install
 * endpoint is remote code execution on the UISP host, so nothing that mutates
 * state may run before `requireAdmin()` has passed.
 *
 * ── WHAT IS HERE AND WHAT IS NOT ────────────────────────────────────────────
 * Identifying the caller is not this plugin's problem — `SpaethTech\Ucrm\Auth` asks
 * UISP who the session belongs to and applies the `system/plugins` check, and it
 * does so identically for every Archous plugin. This class used to carry its own
 * copy of that cookie-and-loopback dance; the copies had already drifted, which
 * is exactly the argument for having one.
 *
 * What stays here is the part that is genuinely this plugin's own: **CSRF via a
 * custom request header**. That works because every call into this plugin is a
 * `fetch()` from admin-zone.js and never an ordinary form post — the opposite of
 * provisioner-v3, whose pages ARE form posts and which therefore needs a real
 * token. Same threat, two mechanisms, chosen by how the request arrives.
 */
final class Auth
{
    /**
     * Refuse unless the caller is an authenticated admin who may edit plugins.
     *
     * Terminates the request on failure — callers should treat a return as
     * authorisation. Deliberately fail-closed: any doubt is a refusal.
     *
     * @return array<string,mixed>
     */
    public static function requireAdmin(): array
    {
        self::requireSameOrigin();

        $user = Ucrm::admin();

        // One refusal for "no session", "a client session" and "an admin without
        // the plugin permission" alike. The difference is only useful to someone
        // probing, and the response body was already identical for all three.
        if ($user === null || !Ucrm::canEdit()) {
            self::deny(403, "not an admin who may edit plugins");
        }

        return $user;
    }

    /**
     * Reject cross-site requests.
     *
     * Cookies alone are not enough: an authenticated admin browsing a hostile
     * page would otherwise have their session used to install something. Two
     * cheap, independent checks:
     *
     *  - a custom header, which a plain cross-origin form cannot set without a
     *    CORS preflight this endpoint never answers;
     *  - Origin, when the browser sends one.
     */
    private static function requireSameOrigin(): void
    {
        if (($_SERVER["HTTP_X_REQUESTED_WITH"] ?? "") !== "marketplace") {
            self::deny(403, "missing X-Requested-With");
        }

        $origin = $_SERVER["HTTP_ORIGIN"] ?? "";

        if ($origin !== "") {
            $host = parse_url($origin, PHP_URL_HOST);

            if (!is_string($host) || $host !== ($_SERVER["HTTP_HOST"] ?? "")) {
                self::deny(403, "cross-origin request");
            }
        }
    }

    private static function deny(int $status, string $why): void
    {
        Log::writef("(auth) denied: %s", $why);

        http_response_code($status);
        echo json_encode(["error" => "Forbidden"]);
        exit;
    }
}
