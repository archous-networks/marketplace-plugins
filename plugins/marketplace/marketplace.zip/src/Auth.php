<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Updater;

/**
 * Who is calling public.php?
 *
 * `public.php` is served with NO authentication — Ubiquiti's own docs say so —
 * and this plugin can install arbitrary archives. An unauthenticated install
 * endpoint is remote code execution on the UISP host, so nothing that mutates
 * state may run before `requireAdmin()` has passed.
 *
 * Plugin pages run on UISP's own domain and therefore receive its cookies. The
 * supported way to identify the caller is to hand those back to UISP and ask —
 * see docs/security.md in the `plugins` skill:
 *
 *   GET /crm/current-user  with  nms-crm-php-session-id + nms-session
 *
 * 403 means not authenticated. A 200 carries `isClient`, `permissions` and
 * `specialPermissions`.
 *
 * Note the cookies changed in UISP 1.0: the old `PHPSESSID` / `/current-user`
 * shape belongs to standalone UCRM 2.x and does not apply here.
 */
final class Auth
{
    /** Editing plugins is the permission that gates installing and updating them. */
    private const PERMISSION = "system/plugins";

    /**
     * Refuse unless the caller is an authenticated admin who may edit plugins.
     *
     * Terminates the request on failure — callers should treat a return as
     * authorisation. Deliberately fail-closed: any doubt is a refusal.
     */
    public static function requireAdmin(): array
    {
        self::requireSameOrigin();

        $user = self::currentUser();

        if ($user === null) {
            self::deny(401, "not authenticated");
        }

        if (($user["isClient"] ?? true) !== false) {
            // A client-zone session is authenticated but must never reach this.
            self::deny(403, "client sessions may not manage plugins");
        }

        if (($user["permissions"][self::PERMISSION] ?? null) !== "edit") {
            self::deny(403, sprintf("requires '%s' = edit", self::PERMISSION));
        }

        return $user;
    }

    /**
     * Reject cross-site requests.
     *
     * Cookies alone are not enough: an authenticated admin browsing a hostile
     * page would otherwise have their session used to install something. Two
     * cheap, independent checks:
     *
     *  - a custom header, which a plain cross-origin form cannot set without a
     *    CORS preflight this endpoint never answers;
     *  - Origin, when the browser sends one.
     */
    private static function requireSameOrigin(): void
    {
        if (($_SERVER["HTTP_X_REQUESTED_WITH"] ?? "") !== "marketplace") {
            self::deny(403, "missing X-Requested-With");
        }

        $origin = $_SERVER["HTTP_ORIGIN"] ?? "";

        if ($origin !== "") {
            $host = parse_url($origin, PHP_URL_HOST);

            if (!is_string($host) || $host !== ($_SERVER["HTTP_HOST"] ?? "")) {
                self::deny(403, "cross-origin request");
            }
        }
    }

    /**
     * Ask UISP who the session belongs to, or null when it says nobody.
     */
    private static function currentUser(): ?array
    {
        $cookies = [];

        foreach (["nms-crm-php-session-id", "nms-session"] as $name) {
            $raw = $_COOKIE[$name] ?? "";

            // Session ids are opaque tokens; strip anything that is not one so a
            // crafted cookie cannot inject a header.
            $clean = preg_replace('~[^a-zA-Z0-9._-]~', '', (string) $raw);

            if ($clean !== "") {
                $cookies[] = $name . "=" . $clean;
            }
        }

        if ($cookies === []) {
            return null;
        }

        // Loopback, so no public hostname or certificate is involved.
        $url = rtrim(Config::ucrmLocalUrl(), "/") . "/current-user";

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER     => [
                "Content-Type: application/json",
                "Cookie: " . implode("; ", $cookies),
            ],
        ]);

        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code !== 200 || !is_string($body)) {
            return null;
        }

        $user = json_decode($body, true);

        return is_array($user) ? $user : null;
    }

    private static function deny(int $status, string $why): void
    {
        error_log(sprintf("(auth) denied: %s", $why));

        http_response_code($status);
        echo json_encode(["error" => "Forbidden"]);
        exit;
    }
}
