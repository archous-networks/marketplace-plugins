<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Minimal HTTP entry point. This plugin has no UI — the only reason it exists is
 * that UISP's zone-JS cache lives in php-fpm's APCu segment, which a CLI process
 * cannot reach. Server::invalidateZoneJsCache() calls the route below over
 * loopback so the deletion happens in the right process.
 *
 * No routing framework: one route, matched by hand, is cheaper than a dependency.
 */

require_once __DIR__ . "/bootstrap.php";

header("Content-Type: application/json");

$route  = $_GET["route"] ?? "";
$remote = $_SERVER["REMOTE_ADDR"] ?? "";

// Loopback only. public.php is unauthenticated and there is no reason for this to
// be reachable from outside.
if ($route !== "/_internal/invalidate-zone-js-cache"
    || !in_array($remote, ["127.0.0.1", "::1"], true)
    || ($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    http_response_code(404);
    echo json_encode(["error" => "Not Found"]);
    exit;
}

if (!function_exists("apcu_cache_info")) {
    echo json_encode(["supported" => false, "deleted" => 0]);
    exit;
}

$info    = @apcu_cache_info(false);
$deleted = 0;

foreach (($info["cache_list"] ?? []) as $entry) {
    // Symfony URL-encodes the Doctrine result-cache id, so match on the decoded key.
    if (stripos(rawurldecode((string) ($entry["info"] ?? "")), "PluginCustomJavaScriptLoader") !== false) {
        if (apcu_delete($entry["info"])) {
            $deleted++;
        }
    }
}

echo json_encode(["supported" => true, "deleted" => $deleted]);
