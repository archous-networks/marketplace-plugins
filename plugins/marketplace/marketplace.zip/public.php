<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Minimal HTTP entry point. Everything here backs admin-zone.js, which is where
 * this plugin's UI actually lives — there are no pages of our own.
 *
 *   /catalogue                          read-only, what we offer vs what is installed
 *   /install  /update  /clear           authenticated, change state
 *   /_internal/invalidate-zone-js-cache loopback only
 *
 * The last one is why public.php existed at all: UISP's zone-JS cache lives in
 * php-fpm's APCu segment, which a CLI process cannot reach, so
 * Server::invalidateZoneJsCache() calls it over loopback to land the deletion in
 * the right process.
 *
 * No routing framework: a handful of routes matched by hand is cheaper than a
 * dependency.
 */

require_once __DIR__ . "/bootstrap.php";

header("Content-Type: application/json");

$route  = $_GET["route"] ?? "";
$remote = $_SERVER["REMOTE_ADDR"] ?? "";

/**
 * Read-only catalogue view for admin-zone.js.
 *
 * READ ONLY, deliberately. It reports what the catalogue offers and what is
 * installed; it installs nothing. Anything that mutates state must first
 * authenticate the caller against /crm/current-user and require
 * permissions["system/plugins"] === "edit" — public.php is unauthenticated, so an
 * install endpoint without that check is remote code execution on this host.
 *
 * Even this leaks a little (plugin names and versions) to anyone who can reach
 * the URL. That is judged acceptable for a catalogue that is public by design;
 * it would not be for anything instance-specific.
 */
if ($route === "/catalogue") {
    try {
        $catalogue = \Archous\Updater\Fleet::catalogue();
        $managed   = \Archous\Updater\Fleet::managed();
        $pluginsDir = \Archous\Updater\Config::pluginsDir();

        // UISP's own plugin ids, so installed rows can link to their detail pages
        // exactly as native rows do. Best-effort: a database that cannot be read
        // costs the links, not the section.
        $ids     = [];
        $enabled = [];

        try {
            $stmt = \Archous\Updater\Ucrm\Database::ucrm()->query("SELECT id, name, enabled FROM plugin");

            foreach ($stmt->fetchAll() as $row) {
                $ids[(string) $row["name"]]     = (int) $row["id"];
                $enabled[(string) $row["name"]] = (bool) $row["enabled"];
            }
        } catch (\Throwable $e) {
            error_log(sprintf("(catalogue) could not read plugin ids — %s", $e->getMessage()));
        }

        $out = [];

        foreach ($catalogue as $name => $entry) {
            $manifest  = $pluginsDir . "/" . $name . "/manifest.json";
            $installed = null;

            if (is_readable($manifest)) {
                $m = json_decode((string) file_get_contents($manifest), true);
                $installed = $m["information"]["version"] ?? null;
            }

            // What we TRACK, which is not necessarily what the index advertises:
            // a `name@ref` entry in the `plugins` setting can pin this to another
            // branch or an older version. Reporting the index's version here would
            // offer an update the plugin would then refuse to perform.
            $target  = \Archous\Updater\Fleet::target($name);
            $version = $target["version"] !== "" ? $target["version"] : (string) ($entry["version"] ?? "");
            $pinned  = $target["kind"] !== \Archous\Updater\Ref::LATEST;

            $direction = "same";

            if ($installed !== null && $version !== "" && $version !== (string) $installed) {
                $direction = version_compare($version, (string) $installed, ">") ? "up" : "down";
            }

            if ($installed === null) {
                $status = "not installed";
            } elseif ($target["error"] !== null) {
                $status = "unavailable";
            } elseif ($direction === "same") {
                $status = "current";
            } elseif ($pinned || $direction === "up") {
                // A pin moves in either direction, so a lower target is a real
                // action here rather than an index that regressed.
                $status = "update available";
            } else {
                $status = "current";
            }

            // The dependency graph, from both ends. `dependents` is what guards
            // removal; `requires` is what an Install would drag in with it.
            $resolution = \Archous\Updater\Dependencies::resolve($name);

            $out[] = [
                "name"         => $name,
                "displayName"  => $entry["displayName"] ?? $name,
                "description"  => $entry["description"] ?? "",
                "url"          => $entry["url"] ?? "",
                "version"      => $version,
                "installed"    => $installed,
                "enabled"      => $enabled[$name] ?? null,
                "pluginId"     => $ids[$name] ?? null,
                "status"       => $status,
                "managed"      => in_array($name, $managed, true),
                "ref"          => $target["ref"],
                "refKind"      => $target["kind"],
                "pinned"       => $pinned,
                "direction"    => $direction,
                "refError"     => $target["error"],
                "dependencies" => \Archous\Updater\Dependencies::declared($name),
                "dependents"   => \Archous\Updater\Dependencies::dependents($name),
                "requires"     => $resolution["order"],
                // Kept apart because they are different faults with different
                // fixes — one names a plugin we do not distribute, the other a
                // loop in what we do.
                "unresolved"   => $resolution["unresolved"],
                "cycle"        => $resolution["cycle"],
            ];
        }

        echo json_encode(["plugins" => $out]);
    } catch (\Throwable $e) {
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

/**
 * Install or update a plugin. AUTHENTICATED — Auth::requireAdmin() runs first and
 * terminates the request unless the caller is an admin who may edit plugins.
 *
 * These are the only routes here that change anything, and they can install
 * arbitrary archives, so the auth check is the first statement in each — not a
 * wrapper that a later edit could reorder around.
 */
if ($route === "/install" || $route === "/update") {
    if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
        http_response_code(405);
        echo json_encode(["error" => "Method Not Allowed"]);
        exit;
    }

    $user = \Archous\Updater\Auth::requireAdmin();

    $body = json_decode((string) file_get_contents("php://input"), true);
    $name = is_array($body) ? trim((string) ($body["name"] ?? "")) : "";

    // Plugin names are a constrained alphabet (manifest docs: alphanumerics,
    // dashes, underscores). Anything else cannot be a plugin and is more likely a
    // traversal attempt than a typo.
    if ($name === "" || preg_match('/^[a-zA-Z0-9_-]+$/', $name) !== 1) {
        http_response_code(400);
        echo json_encode(["error" => "invalid plugin name"]);
        exit;
    }

    try {
        // installTree() pulls in whatever the catalogue says this plugin needs,
        // dependencies first. Update takes no such path: an update replaces a
        // plugin that is already satisfied, and quietly installing new plugins
        // during one would be a much bigger action than the button promises.
        $result = $route === "/install"
            ? \Archous\Updater\Fleet::installTree($name)
            : \Archous\Updater\Fleet::updateOne($name);

        foreach (($result["dependencies"] ?? []) as $dependency) {
            error_log(sprintf(
                "(install:%s) %s as a dependency of %s%s",
                (string) $dependency["plugin"],
                (string) $dependency["action"],
                $name,
                $dependency["detail"] !== null ? " — " . $dependency["detail"] : ""
            ));
        }

        error_log(sprintf(
            "(%s:%s) %s by %s%s",
            ltrim($route, "/"),
            $name,
            $result["action"],
            (string) ($user["username"] ?? "?"),
            $result["detail"] !== null ? " — " . $result["detail"] : ""
        ));

        echo json_encode($result);
    } catch (\Throwable $e) {
        error_log(sprintf("(%s:%s) FAILED — %s", ltrim($route, "/"), $name, $e->getMessage()));
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

/**
 * Truncate a plugin's data/plugin.log. AUTHENTICATED, same gate as install/update.
 *
 * UISP renders that file on the plugin detail page and offers no way to empty it,
 * so a plugin that has been running a while shows a wall of history. admin-zone.js
 * puts a "Clear" button next to Disable and calls this.
 *
 * The plugin is named by its UISP ID, not by directory name: the id is what the
 * page already knows, and resolving it through the `plugin` table means the path
 * below is built from a row UISP itself wrote. A caller cannot name a directory —
 * only an id that either resolves or does not.
 *
 * The file is left holding ONE line rather than nothing. An empty log is ambiguous
 * — "nothing has happened yet" and "someone wiped the history" look identical, and
 * the second is the one worth knowing about when reading a log that starts
 * mid-story. The line carries who did it, so the gap is accounted for.
 */
if ($route === "/clear") {
    if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
        http_response_code(405);
        echo json_encode(["error" => "Method Not Allowed"]);
        exit;
    }

    $user = \Archous\Updater\Auth::requireAdmin();
    $id   = (int) ($_GET["plugin"] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(["error" => "invalid plugin id"]);
        exit;
    }

    try {
        $stmt = \Archous\Updater\Ucrm\Database::ucrm()->prepare("SELECT name FROM plugin WHERE id = :id");
        $stmt->execute([":id" => $id]);
        $name = (string) ($stmt->fetchColumn() ?: "");

        // Belt and braces. The name came from UISP's own table, but it is about to
        // become a filesystem path, so it is checked against the manifest alphabet
        // rather than trusted for being one query removed from us.
        if ($name === "" || preg_match('/^[a-zA-Z0-9_-]+$/', $name) !== 1) {
            http_response_code(404);
            echo json_encode(["error" => "no such plugin"]);
            exit;
        }

        $log   = \Archous\Updater\Config::pluginsDir() . "/" . $name . "/data/plugin.log";
        $bytes = file_exists($log) ? (int) filesize($log) : 0;

        // Written by hand because this line goes into ANOTHER plugin's log, so
        // error_log() — which writes to ours — cannot produce it. The timestamp
        // format is PHP's own ("d-M-Y H:i:s e", from php_log_err), reproduced so the
        // replacement line is indistinguishable from the lines it replaced.
        $line = sprintf(
            "[%s] (clear) log cleared by %s%s",
            date("d-M-Y H:i:s e"),
            (string) ($user["username"] ?? "?"),
            PHP_EOL
        );

        // Truncate rather than unlink: the file keeps its inode, owner and mode, so
        // a plugin holding it open (or error_log reopening it) keeps writing to the
        // same place. Deleting it risks the next writer recreating it as root, which
        // php-fpm then cannot write and error_log() fails at silently.
        if (@file_put_contents($log, $line, LOCK_EX) === false) {
            throw new RuntimeException("could not write $log");
        }

        error_log(sprintf(
            "(clear:%s) log cleared by %s — %d bytes",
            $name,
            (string) ($user["username"] ?? "?"),
            $bytes
        ));

        // The new contents go back so the page can show exactly what is on disk
        // instead of guessing at the line it just caused to be written.
        echo json_encode([
            "action"  => "cleared",
            "plugin"  => $name,
            "bytes"   => $bytes,
            "content" => $line,
        ]);
    } catch (\Throwable $e) {
        error_log(sprintf("(clear:%d) FAILED — %s", $id, $e->getMessage()));
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

// Loopback only. public.php is unauthenticated and there is no reason for this to
// be reachable from outside.
if ($route !== "/_internal/invalidate-zone-js-cache"
    || !in_array($remote, ["127.0.0.1", "::1"], true)
    || ($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    http_response_code(404);
    echo json_encode(["error" => "Not Found"]);
    exit;
}

if (!function_exists("apcu_cache_info")) {
    echo json_encode(["supported" => false, "deleted" => 0]);
    exit;
}

$info    = @apcu_cache_info(false);
$deleted = 0;

foreach (($info["cache_list"] ?? []) as $entry) {
    // Symfony URL-encodes the Doctrine result-cache id, so match on the decoded key.
    if (stripos(rawurldecode((string) ($entry["info"] ?? "")), "PluginCustomJavaScriptLoader") !== false) {
        if (apcu_delete($entry["info"])) {
            $deleted++;
        }
    }
}

echo json_encode(["supported" => true, "deleted" => $deleted]);
