<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Minimal HTTP entry point. This plugin has no UI — the only reason it exists is
 * that UISP's zone-JS cache lives in php-fpm's APCu segment, which a CLI process
 * cannot reach. Server::invalidateZoneJsCache() calls the route below over
 * loopback so the deletion happens in the right process.
 *
 * No routing framework: one route, matched by hand, is cheaper than a dependency.
 */

require_once __DIR__ . "/bootstrap.php";

header("Content-Type: application/json");

$route  = $_GET["route"] ?? "";
$remote = $_SERVER["REMOTE_ADDR"] ?? "";

/**
 * Read-only catalogue view for admin-zone.js.
 *
 * READ ONLY, deliberately. It reports what the catalogue offers and what is
 * installed; it installs nothing. Anything that mutates state must first
 * authenticate the caller against /crm/current-user and require
 * permissions["system/plugins"] === "edit" — public.php is unauthenticated, so an
 * install endpoint without that check is remote code execution on this host.
 *
 * Even this leaks a little (plugin names and versions) to anyone who can reach
 * the URL. That is judged acceptable for a catalogue that is public by design;
 * it would not be for anything instance-specific.
 */
if ($route === "/catalogue") {
    try {
        $catalogue = \Archous\Updater\Fleet::catalogue();
        $managed   = \Archous\Updater\Fleet::managed();
        $pluginsDir = \Archous\Updater\Config::pluginsDir();

        $out = [];

        foreach ($catalogue as $name => $entry) {
            $manifest  = $pluginsDir . "/" . $name . "/manifest.json";
            $installed = null;

            if (is_readable($manifest)) {
                $m = json_decode((string) file_get_contents($manifest), true);
                $installed = $m["information"]["version"] ?? null;
            }

            $version = (string) ($entry["version"] ?? "");

            if ($installed === null) {
                $status = "not installed";
            } elseif (version_compare($version, (string) $installed, ">")) {
                $status = "update available";
            } else {
                $status = "current";
            }

            $out[] = [
                "name"        => $name,
                "displayName" => $entry["displayName"] ?? $name,
                "version"     => $version,
                "installed"   => $installed,
                "status"      => $status,
                "managed"     => in_array($name, $managed, true),
            ];
        }

        echo json_encode(["plugins" => $out]);
    } catch (\Throwable $e) {
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

/**
 * Install or update a plugin. AUTHENTICATED — Auth::requireAdmin() runs first and
 * terminates the request unless the caller is an admin who may edit plugins.
 *
 * These are the only routes here that change anything, and they can install
 * arbitrary archives, so the auth check is the first statement in each — not a
 * wrapper that a later edit could reorder around.
 */
if ($route === "/install" || $route === "/update") {
    if (($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
        http_response_code(405);
        echo json_encode(["error" => "Method Not Allowed"]);
        exit;
    }

    $user = \Archous\Updater\Auth::requireAdmin();

    $body = json_decode((string) file_get_contents("php://input"), true);
    $name = is_array($body) ? trim((string) ($body["name"] ?? "")) : "";

    // Plugin names are a constrained alphabet (manifest docs: alphanumerics,
    // dashes, underscores). Anything else cannot be a plugin and is more likely a
    // traversal attempt than a typo.
    if ($name === "" || preg_match('/^[a-zA-Z0-9_-]+$/', $name) !== 1) {
        http_response_code(400);
        echo json_encode(["error" => "invalid plugin name"]);
        exit;
    }

    try {
        $result = $route === "/install"
            ? \Archous\Updater\Fleet::install($name)
            : \Archous\Updater\Fleet::updateOne($name);

        error_log(sprintf(
            "(%s:%s) %s by %s%s",
            ltrim($route, "/"),
            $name,
            $result["action"],
            (string) ($user["username"] ?? "?"),
            $result["detail"] !== null ? " — " . $result["detail"] : ""
        ));

        echo json_encode($result);
    } catch (\Throwable $e) {
        error_log(sprintf("(%s:%s) FAILED — %s", ltrim($route, "/"), $name, $e->getMessage()));
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

// Loopback only. public.php is unauthenticated and there is no reason for this to
// be reachable from outside.
if ($route !== "/_internal/invalidate-zone-js-cache"
    || !in_array($remote, ["127.0.0.1", "::1"], true)
    || ($_SERVER["REQUEST_METHOD"] ?? "GET") !== "POST") {
    http_response_code(404);
    echo json_encode(["error" => "Not Found"]);
    exit;
}

if (!function_exists("apcu_cache_info")) {
    echo json_encode(["supported" => false, "deleted" => 0]);
    exit;
}

$info    = @apcu_cache_info(false);
$deleted = 0;

foreach (($info["cache_list"] ?? []) as $entry) {
    // Symfony URL-encodes the Doctrine result-cache id, so match on the decoded key.
    if (stripos(rawurldecode((string) ($entry["info"] ?? "")), "PluginCustomJavaScriptLoader") !== false) {
        if (apcu_delete($entry["info"])) {
            $deleted++;
        }
    }
}

echo json_encode(["supported" => true, "deleted" => $deleted]);
