<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Runs when UISP removes the plugin.
 *
 * Deletes the webhook endpoint registered by hook_install.php. Without this,
 * UISP keeps delivering service events to a path that no longer serves anything.
 * Idempotent — safe if the endpoint is already gone.
 */

require_once __DIR__ . "/bootstrap.php";

use Archous\Provisioner\Ucrm\WebhookRegistrar;
use SpaethTech\Ucrm\Log;

try {
    $result = WebhookRegistrar::remove();

    Log::writef(
        "(hook:remove) webhook %s — %s",
        $result["removed"] ? "deleted" : "not present",
        $result["url"]
    );
} catch (\Throwable $e) {
    // Never block removal. A plugin that cannot be uninstalled is worse than a
    // stale webhook row, which an operator can delete from the admin UI.
    Log::writef(
        "(hook:remove) webhook cleanup FAILED — %s [%s:%d]",
        $e->getMessage(),
        $e->getFile(),
        $e->getLine()
    );
}
