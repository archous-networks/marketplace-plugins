/**
 * Behaviour for the plugin's own pages.
 *
 * Three jobs, none of which knows anything about provisioning:
 *
 *   1. repeating tables — add and delete rows, keeping one hidden JSON field as
 *      the single source of what will be posted
 *   2. conditional rows — show/hide a group when its controlling field changes
 *   3. small guards — confirm a delete, warn before leaving a modified form
 *
 * Deliberately plain: no framework, no build step. v2's equivalent was Svelte
 * running on a separate server behind an iframe; this ships inside the plugin
 * ZIP, and per the public-artifact rule in CLAUDE.md everything in there is
 * readable by every operator. That is fine for markup wrangling and is exactly
 * why no decision worth protecting is made here.
 *
 * ── WHAT SAME-ORIGIN BOUGHT US ──────────────────────────────────────────────
 * v2 sat in a SECOND, cross-origin iframe: UISP framed the plugin, and the plugin
 * framed the external provisioning server. That inner boundary is what forced
 * two dependencies this file does not have:
 *
 *   - `@iframe-resizer/*` — the plugin could not measure the external app's
 *     content height, so a library shipped it out over postMessage. There is no
 *     inner frame here, and UISP's own is `height:100%` inside a scrolling
 *     container, so there is nothing left to measure.
 *   - `lib/messaging.ts` — `parent.postMessage({func, args}, "*")` and a dispatcher
 *     on the other side, because the frames could not touch each other. They can
 *     now: `window.parent.document` reads fine.
 *
 * Both are gone rather than ported. The remaining use of the parent is `ucrm`
 * below, which borrows UISP's confirm dialog instead of shipping one — and every
 * call is guarded, because this page also renders correctly when opened directly
 * with no parent at all.
 *
 * ⚠️ Served WITHOUT AUTHENTICATION from public/. Nothing here may be trusted by
 * the server; every value it produces is re-normalised in PHP.
 */
(function () {
  "use strict";

  /* ── UISP's own dialog, borrowed from the parent frame ───────────────────
   *
   * Reaching `window.parent` rather than loading jQuery and app.min.js into this
   * frame: the parent has both already, and a second copy would boot UISP's
   * sockets and page wiring inside an iframe that has no use for them.
   *
   * Rendering into the PARENT's `#confirm` is also the right behaviour, not just
   * the convenient one — a modal confined to the iframe would dim a rectangle of
   * the page instead of the page.
   */
  var ucrm = (function () {
    try {
      var p = window.parent;

      // Touching .document is the same-origin test; it throws if it is not.
      if (p === window || !p.document || !p.jQuery || !p.UCRM) { return null; }
      if (!p.UCRM.templates || !p.UCRM.templates.confirm) { return null; }
      if (!p.document.getElementById("confirm")) { return null; }

      return p;
    } catch (e) {
      return null; // opened directly, or a future UISP that frames us elsewhere
    }
  })();

  /** Ask, then run `onConfirm`. Falls back to the browser's own prompt. */
  function confirmThen(options, onConfirm) {
    if (!ucrm) {
      if (window.confirm(options.content)) { onConfirm(); }
      return;
    }

    var $ = ucrm.jQuery;

    var box = $(ucrm.UCRM.templates.confirm.box({
      title: options.title,
      content: options.content,
      confirmButtonText: options.confirm || "Okay",
      cancelButtonText: "Cancel",
      confirmButtonClasses: "unifi-button " + (options.danger ? "unifi-button--danger" : ""),
      cancelButtonClasses: "unifi-button unifi-button--tertiary",
    }));

    var host = $(ucrm.document.getElementById("confirm"));

    function close() {
      host.removeClass("on").html("");
      $(ucrm.document).off("keydown.provisioner");
    }

    host.html(box).addClass("on");

    box.on("click tap", ".confirm__box__ctrl__cancel", close);
    box.on("click tap", ".confirm__box__ctrl__confirm", function () {
      close();
      onConfirm();
    });

    // Enter/Escape, matching what UISP's own confirm module binds.
    $(ucrm.document).off("keydown.provisioner").on("keydown.provisioner", function (e) {
      if (e.which === 13) { e.preventDefault(); close(); onConfirm(); }
      else if (e.which === 27) { e.preventDefault(); close(); }
    });
  }

  /* ── Repeating tables ───────────────────────────────────────────────────
   *
   * The hidden input is authoritative, not the DOM. Rows are re-rendered from
   * it after every change, so a delete cannot leave the visible table and the
   * posted array disagreeing — which is the bug indexed field names produce and
   * the reason for the single-blob encoding.
   */

  function repeats() {
    Array.prototype.forEach.call(document.querySelectorAll("[data-repeat]"), function (root) {
      var store = root.querySelector('input[type="hidden"]');
      var body = root.querySelector("[data-repeat-rows]");
      var adder = root.querySelector("[data-repeat-new]");
      var columns = root.querySelectorAll("thead th").length;

      if (!store || !body || !adder) { return; }

      var fields = Array.prototype.map.call(
        adder.querySelectorAll("[data-field]"),
        function (input) {
          return {
            field: input.getAttribute("data-field"),
            input: input,
            secret: input.type === "password",
            select: input.tagName === "SELECT",
          };
        }
      );

      function read() {
        try {
          var parsed = JSON.parse(store.value || "[]");
          return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
          return [];
        }
      }

      function write(rows) {
        store.value = JSON.stringify(rows);
        render(rows);
        store.dispatchEvent(new Event("change", { bubbles: true }));
      }

      function render(rows) {
        body.textContent = "";

        rows.forEach(function (row, index) {
          var tr = document.createElement("tr");
          tr.className = "has-actions";
          tr.setAttribute("data-index", String(index));

          fields.forEach(function (f) {
            var td = document.createElement("td");
            td.className = "column-data ";
            var value = row[f.field] == null ? "" : String(row[f.field]);

            if (f.secret) {
              // A stored secret is never echoed back into the page — only
              // whether one is set.
              td.innerHTML = '<span class="provisioner-secret"></span>';
              td.firstChild.textContent = value ? "••••••••" : "";
            } else if (f.select) {
              var option = f.input.querySelector('option[value="' + value.replace(/"/g, '\\"') + '"]');
              td.textContent = option ? option.textContent.trim() : value;
            } else {
              td.textContent = value;
            }

            tr.appendChild(td);
          });

          // Native grid-row action: unifi-button, not button. See the uisp-ui skill.
          var actions = document.createElement("td");
          actions.className = "actions ";
          var wrap = document.createElement("div");
          wrap.className = "grid__actions";
          var del = document.createElement("a");
          del.href = "#";
          del.className = "unifi-button unifi-button--compact unifi-button--danger unifi-button--half-padding";
          del.innerHTML = "<span>Delete</span>";
          del.setAttribute("data-repeat-delete", "");
          wrap.appendChild(del);
          actions.appendChild(wrap);
          tr.appendChild(actions);

          body.appendChild(tr);
        });

        // UISP's empty state: one row spanning every column, class `no-rows`.
        if (!rows.length) {
          var tr = document.createElement("tr");
          var td = document.createElement("td");
          td.colSpan = columns;
          td.className = "no-rows";
          td.textContent = "There are no rows in the table...";
          tr.appendChild(td);
          body.appendChild(tr);
        }
      }

      function add() {
        var row = {};
        var filled = false;

        fields.forEach(function (f) {
          var value = f.input.value.trim();
          row[f.field] = value;
          // A <select> always has a value, so it cannot be what makes a row
          // real — otherwise Add would happily append an empty row.
          if (value !== "" && !f.select) { filled = true; }
        });

        if (!filled) {
          var first = fields.filter(function (f) { return !f.select; })[0];
          if (first) { first.input.focus(); }
          return;
        }

        var rows = read();
        rows.push(row);
        write(rows);

        fields.forEach(function (f) { if (!f.select) { f.input.value = ""; } });

        var focus = fields.filter(function (f) { return !f.select; })[0];
        if (focus) { focus.input.focus(); }
      }

      adder.addEventListener("click", function (e) {
        if (e.target.closest("[data-repeat-add]")) {
          e.preventDefault();
          add();
        }
      });

      adder.addEventListener("keydown", function (e) {
        // Enter inside the add row means "add", not "submit the whole form" —
        // which would otherwise save everything except the row being typed.
        if (e.key === "Enter" && e.target.hasAttribute("data-field")) {
          e.preventDefault();
          add();
        }
      });

      body.addEventListener("click", function (e) {
        var trigger = e.target.closest("[data-repeat-delete]");
        if (!trigger) { return; }

        e.preventDefault();

        var tr = trigger.closest("tr");
        var index = parseInt(tr.getAttribute("data-index"), 10);
        var rows = read();

        if (index >= 0 && index < rows.length) {
          rows.splice(index, 1);
          write(rows);
        }
      });

      render(read());
    });
  }

  /* ── Conditional groups ─────────────────────────────────────────────────
   *
   * Hidden, never removed: the inputs still post, so the server reads a complete
   * record and does not have to decide whether an absent field means "off" or
   * "was not on screen".
   */

  function toggles() {
    Array.prototype.forEach.call(document.querySelectorAll("[data-toggles]"), function (control) {
      var key = control.getAttribute("data-toggles");

      function value() {
        return control.type === "checkbox" ? (control.checked ? "1" : "0") : control.value;
      }

      function apply() {
        var current = value();

        Array.prototype.forEach.call(
          document.querySelectorAll('[data-toggle-group="' + key + '"]'),
          function (group) {
            group.hidden = group.getAttribute("data-toggle-when") !== current;
          }
        );
      }

      control.addEventListener("change", apply);
      apply();
    });
  }

  /* ── Collapsible form boxes ─────────────────────────────────────────────
   *
   * Only for boxes that opted in with `toggle: true`; the default is
   * `form-box--no-toggle`, which shows no affordance. UISP's own handler is bound
   * to the parent document and never sees events in this frame, so the behaviour
   * has to be supplied here — otherwise the +/− is a control that does nothing.
   *
   * `form-box-hidden` is UISP's own class: it flips the toggle bars and sets
   * `.body { display: none }`. Nothing to style, only to toggle.
   */

  function collapsibles() {
    Array.prototype.forEach.call(
      document.querySelectorAll(".form-box:not(.form-box--no-toggle) > .header"),
      function (header) {
        function toggle() {
          header.parentElement.classList.toggle("form-box-hidden");
        }

        header.addEventListener("click", toggle);

        // The header carries tabindex="0" natively, so it is reachable — make it
        // operable too rather than focusable and inert.
        header.addEventListener("keydown", function (e) {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            toggle();
          }
        });
      }
    );
  }

  /** Submit a same-origin POST with the page's CSRF token. */
  function post(url) {
    // The layout's meta is always present; a form's hidden field is the same
    // value. Prefer the meta so a page without a form still works.
    var meta = document.querySelector('meta[name="csrf-token"]');
    var token = meta || document.querySelector('input[name="_token"]');

    var form = document.createElement("form");
    form.method = "post";
    form.action = url;

    if (token) {
      var field = document.createElement("input");
      field.type = "hidden";
      field.name = "_token";
      field.value = meta ? meta.content : token.value;
      form.appendChild(field);
    }

    document.body.appendChild(form);
    form.submit();
  }

  /* ── Guards ─────────────────────────────────────────────────────────────── */

  function guards() {
    Array.prototype.forEach.call(document.querySelectorAll("[data-confirm]"), function (link) {
      link.addEventListener("click", function (e) {
        e.preventDefault();

        confirmThen({
          title: link.getAttribute("data-confirm-title") || "Confirm",
          content: link.getAttribute("data-confirm"),
          confirm: link.getAttribute("data-confirm-okay") || "Okay",
          danger: link.hasAttribute("data-confirm-danger"),
        }, function () {
          // POST, not navigate. Every destructive action is a POST carrying the
          // CSRF token — a GET that deletes can be fired by an <img> tag on a
          // hostile page using the admin's own session. The dialog lives in the
          // PARENT document, so there is no default action left to let through
          // and the form has to be built and submitted explicitly.
          post(link.href);
        });
      });
    });

    Array.prototype.forEach.call(document.querySelectorAll("[data-dirty-guard]"), function (form) {
      var dirty = false;

      form.addEventListener("change", function () { dirty = true; });
      form.addEventListener("input", function () { dirty = true; });
      form.addEventListener("submit", function () { dirty = false; });

      window.addEventListener("beforeunload", function (e) {
        if (!dirty) { return; }
        e.preventDefault();
        // Browsers ignore custom text here and show their own; returnValue is
        // still what triggers the prompt at all.
        e.returnValue = "";
      });
    });
  }

  repeats();
  toggles();
  collapsibles();
  guards();
})();
