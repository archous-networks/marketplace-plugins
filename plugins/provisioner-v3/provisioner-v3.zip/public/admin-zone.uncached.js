/**
 * Admin zone behaviour for the IP Provisioner plugin.
 *
 * Loaded by admin-zone.js with a cache-busting query string, so edits here take
 * effect on the next page load with no cache clearing.
 *
 * Runs on EVERY admin zone page. Two consequences worth keeping in mind:
 *
 *   1. Guard by pathname. Work out early whether this page is one you care
 *      about and return if not — otherwise every page in CRM pays for it.
 *   2. Nothing here is trusted. public/ is served unauthenticated, so treat this
 *      as a convenience layer over the plugin API, never as an access control.
 *      Any endpoint it calls must enforce its own rules.
 *
 * PLACEHOLDER — no behaviour yet.
 */
(function () {
  "use strict";

  var PLUGIN = "provisioner-v3";

  // Base for calls back into the plugin, derived rather than hardcoded so a
  // rename of the plugin directory does not silently break every request.
  var api = (function () {
    var script = Array.prototype.slice
      .call(document.getElementsByTagName("script"))
      .filter(function (s) {
        return s.src && s.src.indexOf("admin-zone.uncached.js") !== -1;
      })
      .pop();

    if (!script || !script.src) {
      return "/crm/_plugins/" + PLUGIN + "/public.php";
    }

    return script.src.replace(/\/public\/admin-zone\.uncached\.js.*$/, "/public.php");
  })();

  // Exposed so page-specific code can reach the plugin without re-deriving this.
  window.__provisioner = window.__provisioner || {};
  window.__provisioner.api = api;
  window.__provisioner.route = function (route) {
    return api + "?route=" + route;
  };

  // TODO: admin zone behaviour goes here.
})();
