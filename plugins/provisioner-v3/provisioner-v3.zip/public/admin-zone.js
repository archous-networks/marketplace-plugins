/**
 * Loaded automatically by UISP on EVERY admin zone page (UISP 1.1.0-beta2+).
 *
 * This file is only a cache-busting loader — put the real code in
 * admin-zone.uncached.js. UISP serves public/ as static assets with far-future
 * caching, and because this file loads on every admin page a stale copy is very
 * sticky: you end up iterating against code the browser will not re-fetch.
 * Carried over from v2, which needed exactly this.
 *
 * ⚠️ public/ is served WITHOUT AUTHENTICATION and without processing. Anything
 * here is readable by anyone who can reach the host. No secrets, no tokens, and
 * nothing that assumes the reader is an admin.
 *
 * ⚠️ This runs on every admin page load. Keep it cheap and guard by pathname —
 * do not fire network requests on pages that do not need them.
 */
(function () {
  "use strict";

  var TARGET = "admin-zone.uncached.js";

  // document.currentScript is null for async/deferred execution, so fall back to
  // locating our own tag by src.
  var currentScript =
    document.currentScript ||
    Array.prototype.slice
      .call(document.getElementsByTagName("script"))
      .filter(function (s) {
        return s.src && s.src.indexOf("admin-zone.js") !== -1;
      })
      .pop();

  if (!currentScript || !currentScript.src) {
    // Without our own tag we cannot know the plugin's public path. Guessing it
    // would break silently the moment the plugin directory is renamed, so do
    // nothing and say why.
    console.warn("[provisioner] admin-zone.js: cannot resolve public path; not loading " + TARGET);
    return;
  }

  var publicPath = currentScript.src.replace(/\/admin-zone\.js.*$/, "");

  var script = document.createElement("script");
  // Date.now() defeats caching on every load, which is what you want while
  // iterating. Before this ships widely, swap to the plugin version so the file
  // caches normally and busts only on release.
  script.src = publicPath + "/" + TARGET + "?v=" + Date.now();
  script.type = "text/javascript";

  if (currentScript.parentNode) {
    currentScript.parentNode.insertBefore(script, currentScript.nextSibling);
  } else {
    document.head.appendChild(script);
  }
})();
