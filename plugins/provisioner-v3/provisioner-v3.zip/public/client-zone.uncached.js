/**
 * Client zone behaviour for the IP Provisioner plugin.
 *
 * Loaded by client-zone.js with a cache-busting query string.
 *
 * CUSTOMER-FACING. Runs on every client zone page for every subscriber. Assume
 * the reader is hostile and unauthenticated: expose no internal URLs, no
 * provisioning detail, nothing about Nautobot, and nothing about any client
 * other than the one viewing the page — and even then, let the server decide
 * what they may see.
 *
 * PLACEHOLDER — no behaviour yet, and quite possibly none is ever needed. v3's
 * provisioning is an operator concern; delete this pair rather than inventing a
 * use for it.
 */
(function () {
  "use strict";

  // TODO: client zone behaviour, if any is ever required.
})();
