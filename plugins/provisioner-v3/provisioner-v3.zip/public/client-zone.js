/**
 * Loaded automatically by UISP on EVERY client zone page (UISP 1.1.0-beta2+).
 *
 * Cache-busting loader only — real code belongs in client-zone.uncached.js.
 * Same reasoning as admin-zone.js: public/ is served with far-future caching and
 * this file loads on every page, so a stale copy is very sticky.
 *
 * ⚠️ The client zone is CUSTOMER-FACING. Beyond the usual "public/ is
 * unauthenticated" rule, assume a hostile reader: no internal URLs, no
 * provisioning detail, nothing about other clients, nothing about Nautobot.
 */
(function () {
  "use strict";

  var TARGET = "client-zone.uncached.js";

  var currentScript =
    document.currentScript ||
    Array.prototype.slice
      .call(document.getElementsByTagName("script"))
      .filter(function (s) {
        return s.src && s.src.indexOf("client-zone.js") !== -1;
      })
      .pop();

  if (!currentScript || !currentScript.src) {
    console.warn("[provisioner] client-zone.js: cannot resolve public path; not loading " + TARGET);
    return;
  }

  var publicPath = currentScript.src.replace(/\/client-zone\.js.*$/, "");

  var script = document.createElement("script");
  script.src = publicPath + "/" + TARGET + "?v=" + Date.now();
  script.type = "text/javascript";

  if (currentScript.parentNode) {
    currentScript.parentNode.insertBefore(script, currentScript.nextSibling);
  } else {
    document.head.appendChild(script);
  }
})();
