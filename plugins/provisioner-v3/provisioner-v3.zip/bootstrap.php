<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Shared bootstrap for every entry point (public.php, main.php, hook_*.php).
 *
 * `Plugin::boot()` registers the plugin root and sets up error handling and the
 * log file. Both matter and neither is obvious — see the SDK for why the root
 * has to be STATED rather than derived (the code lives in vendor/, or is
 * symlinked in from another tree entirely), and why the log file is created
 * permissively (this plugin runs as more than one user, and error_log() fails
 * silently when it cannot write).
 *
 * Any new entry point must load this file.
 */

require_once __DIR__ . "/vendor/autoload.php";

SpaethTech\Ucrm\Plugin::boot(__DIR__);
