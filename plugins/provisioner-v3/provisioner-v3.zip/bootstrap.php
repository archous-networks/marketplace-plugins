<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Shared bootstrap for every entry point (public.php, main.php, hook_*.php).
 *
 * Errors are logged, never displayed: this runs inside the UISP admin UI, and a
 * PHP notice rendered into a JSON response or an embedded page is both a broken
 * response and an information leak.
 */

require_once __DIR__ . "/vendor/autoload.php";

ini_set("display_errors", "0");
ini_set("log_errors", "1");
error_reporting(E_ALL);

// UISP creates data/ at install time, but hooks can fire before that lands.
if (!is_dir(__DIR__ . "/data")) {
    @mkdir(__DIR__ . "/data", 0775, true);
}

$__log = __DIR__ . "/data/plugin.log";

// This plugin runs as more than one user: php-fpm serves public.php as the web
// user, while hooks and main.php run from the CLI — and a developer invoking a
// hook by hand may well be root. Whoever creates the log file owns it, and
// error_log() fails SILENTLY when it cannot write, so an ownership mismatch
// costs you every HTTP-side log line with no indication anything is wrong.
// Create it permissively so any of those callers can append.
if (!file_exists($__log)) {
    @touch($__log);
    @chmod($__log, 0666);
}

ini_set("error_log", $__log);
unset($__log);
