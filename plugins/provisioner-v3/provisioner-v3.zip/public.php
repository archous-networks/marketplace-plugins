<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Publicly reachable HTTP entry point.
 *
 * UISP serves ONLY this filename for a plugin — there is no public/index.php —
 * and reaches it as `.../public.php?route=/some/path`. QueryRoutingMiddleware
 * turns that query string back into a request path so the routes below read
 * like ordinary Slim routes.
 */

use Archous\Provisioner\Middleware\QueryRoutingMiddleware;
use DI\Bridge\Slim\Bridge;
use DI\ContainerBuilder;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Routing\RouteCollectorProxy;

require_once __DIR__ . "/bootstrap.php";

$builder = new ContainerBuilder();
$builder->addDefinitions(__DIR__ . "/container.php");
$container = $builder->build();

$app = Bridge::create($container);

// Cheap, throttled staleness check. Never updates from here — public.php
// bypasses UISP's execution lock, so it only asks UISP to run main.php, which
// is serialised. UISP's cron picks that request up within a minute.
try {
    \Archous\Provisioner\Updater::requestUpdateIfStale();
} catch (\Throwable $e) {
    error_log("(update) staleness check failed — " . $e->getMessage());
}

$app->addBodyParsingMiddleware();
$app->addRoutingMiddleware();

$app->addErrorMiddleware(
    (bool) $container->get("settings")["displayErrorDetails"],
    true,
    true
);

// Registered last so it runs FIRST — the path has to exist before routing
// resolves it. Slim's middleware stack is last-added, first-executed.
$app->add(new QueryRoutingMiddleware());

$json = static function (Response $response, mixed $data, int $status = 200): Response {
    $response->getBody()->write(
        json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );

    return $response->withStatus($status)->withHeader("Content-Type", "application/json");
};

// NOTE: php-di/slim-bridge injects controller arguments BY NAME — the parameters
// must be called `$request` and `$response` exactly. Renaming them to $req/$res
// throws NotEnoughParametersException at invoke time, not at boot.
$app->group("/api", function (RouteCollectorProxy $group) use ($json): void {

    // Liveness only. Deliberately unauthenticated, and deliberately says nothing
    // about configuration or credentials.
    $group->get(
        "/ping",
        fn(Request $request, Response $response) => $json($response, ["ping" => "pong"])
    );

    $group->map(
        ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
        "/{path:.*}",
        fn(Request $request, Response $response) => $json($response, ["error" => "Not Found"], 404)
    );
});

/**
 * Inbound UISP service-lifecycle webhooks.
 *
 * Registered automatically by hook_install.php (see Ucrm\WebhookRegistrar) —
 * UISP has no API for webhook endpoint management, so registration writes to its
 * database directly.
 *
 * UISP delivers over plain-HTTP loopback from inside its own container, so the
 * request never crosses the network. It is also UNAUTHENTICATED: UISP does not
 * sign webhook deliveries, and webhook_address carries no shared secret. Anything
 * able to reach this path locally can post to it, so treat the payload's
 * service id as a hint and re-read state from the CRM API before acting on it.
 */
$app->post("/webhook", function (Request $request, Response $response) use ($json): Response {
    $payload = $request->getParsedBody();

    $event    = is_array($payload) ? (string) ($payload["eventName"] ?? "unknown") : "unknown";
    $entity   = is_array($payload) ? (string) ($payload["entity"] ?? "unknown") : "unknown";
    $entityId = is_array($payload) ? (string) ($payload["entityId"] ?? "?") : "?";

    // Token names the trigger (which event arrived); the object is written as
    // `type:id` in the message so `grep 'service:404'` still follows it across
    // every subsystem. See *Log format* in CLAUDE.md.
    // TODO: push to Nautobot (SoT), then run the provision Job with this service_id.
    error_log(sprintf("(webhook:%s) %s:%s accepted", $event, $entity, $entityId));

    // Always 200: UISP retries on failure, and a retry storm helps nobody while
    // the handler is still a stub.
    return $json($response, ["received" => true]);
});

/**
 * Invalidate UISP's cached zone-JS lookup. LOOPBACK ONLY.
 *
 * `PluginCustomJavaScriptLoader` caches "which plugins ship admin/client zone
 * JS" in a Doctrine result cache backed by APCu. APCu is per-SAPI, so a CLI hook
 * cannot clear the copy php-fpm uses — but this route runs *in* php-fpm, so it
 * can. Ucrm\Server::invalidateZoneJsCache() calls it over loopback.
 *
 * Only ever deletes UISP's own PluginCustomJavaScriptLoader entries, which UISP
 * rebuilds on the next request. Restricted to loopback because public.php is
 * unauthenticated and there is no reason for this to be reachable externally.
 */
$app->post("/_internal/invalidate-zone-js-cache", function (Request $request, Response $response) use ($json): Response {
    $remote = $request->getServerParams()["REMOTE_ADDR"] ?? "";

    if (!in_array($remote, ["127.0.0.1", "::1"], true)) {
        return $json($response, ["error" => "Not Found"], 404);
    }

    if (!function_exists("apcu_cache_info")) {
        return $json($response, ["supported" => false, "deleted" => 0]);
    }

    $info    = @apcu_cache_info(false);
    $deleted = 0;

    foreach (($info["cache_list"] ?? []) as $entry) {
        $key = $entry["info"] ?? "";
        // Keys are URL-encoded by Symfony's cache adapter, e.g.
        // "<ns>:%5BAppBundle%5CService%5CPlugin%5CPluginCustomJavaScriptLoader%3AhasAdminZoneJs%5D%5B1%5D"
        if (stripos(rawurldecode((string) $key), "PluginCustomJavaScriptLoader") !== false) {
            if (apcu_delete($key)) {
                $deleted++;
            }
        }
    }

    return $json($response, ["supported" => true, "deleted" => $deleted]);
});

$app->map(
    ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
    "/{path:.*}",
    fn(Request $request, Response $response) => $json($response, ["error" => "Not Found"], 404)
);

$app->run();
