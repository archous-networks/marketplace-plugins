<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Publicly reachable HTTP entry point.
 *
 * UISP serves ONLY this filename for a plugin — there is no public/index.php —
 * and reaches it as `.../public.php?route=/some/path`. QueryRoutingMiddleware
 * turns that query string back into a request path so the routes below read
 * like ordinary Slim routes.
 */

use Archous\Provisioner\Middleware\QueryRoutingMiddleware;
use Archous\Provisioner\Middleware\RequireAdminMiddleware;
use Archous\Provisioner\Provisioning\BroadcastDomains;
use Archous\Provisioner\Provisioning\Configs;
use Archous\Provisioner\Provisioning\Logs;
use Archous\Provisioner\Provisioning\Options;
use Archous\Provisioner\Ucrm\Api;
use Archous\Provisioner\Ui\Pages;
use Archous\Provisioner\Ui\Sections;
use Archous\Provisioner\Ui\Vocabulary;
use DI\Bridge\Slim\Bridge;
use DI\ContainerBuilder;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Routing\RouteCollectorProxy;
use Slim\Views\Twig;
use Slim\Views\TwigMiddleware;

require_once __DIR__ . "/bootstrap.php";

$builder = new ContainerBuilder();
$builder->addDefinitions(__DIR__ . "/container.php");
$container = $builder->build();

$app = Bridge::create($container);

$app->add(TwigMiddleware::createFromContainer($app, Twig::class));

$app->addBodyParsingMiddleware();
$app->addRoutingMiddleware();

$app->addErrorMiddleware(
    (bool) $container->get("settings")["displayErrorDetails"],
    true,
    true
);

// Registered last so it runs FIRST — the path has to exist before routing
// resolves it. Slim's middleware stack is last-added, first-executed.
$app->add(new QueryRoutingMiddleware());

$json = static function (Response $response, mixed $data, int $status = 200): Response {
    $response->getBody()->write(
        json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
    );

    return $response->withStatus($status)->withHeader("Content-Type", "application/json");
};

/**
 * Render a page.
 *
 * `route()` and `asset()` are registered per REQUEST rather than once at boot,
 * because both are derived from how this request actually reached public.php.
 * See Ui\Pages for why that is not read from ucrm.json.
 */
$page = static function (
    Twig $twig,
    Request $request,
    Response $response,
    string $template,
    string $title,
    array $data = []
): Response {
    $twig->getEnvironment()->addFunction(new \Twig\TwigFunction(
        "route",
        static fn(string $path): string => Pages::base($request) . "?route=" . $path
    ));

    $twig->getEnvironment()->addFunction(new \Twig\TwigFunction(
        "asset",
        static fn(string $file): string => Pages::asset($request, $file)
    ));

    return $twig->render(
        $response,
        $template,
        array_merge(Pages::context($request, $title), $data)
    );
};

/** Back to a page after a POST, so a refresh cannot resubmit it. */
$redirect = static fn(Request $request, Response $response, string $path): Response
    => $response->withHeader("Location", Pages::base($request) . "?route=" . $path)->withStatus(303);

/**
 * The plugin's own pages — v2's Options and Sites, which lived in a SvelteKit app
 * behind an iframe. Here they are same-origin Twig, which is what removes the CSP
 * problem rather than working around it (see *No CSP manipulation* in CLAUDE.md).
 *
 * ⚠️ NOTHING BELOW TALKS TO NAUTOBOT YET. Reads and writes go to Store\LocalStore,
 * a deliberate placeholder, pending the source-of-truth decision. The seam is
 * Provisioning\Options and Provisioning\BroadcastDomains: when that lands, they
 * change and these routes do not.
 *
 * ⚠️ AND NOTHING BELOW IS AUTHENTICATED. Ubiquiti serves public.php without auth,
 * so anyone who can reach this URL can read and write these drafts. That is
 * tolerable only because it is all draft configuration on a PoC instance; before
 * this is used anywhere real it needs the same /crm/current-user check the
 * marketplace plugin's Auth class performs.
 */
/**
 * Everything below is ADMIN ONLY.
 *
 * public.php is served without authentication and is reachable from outside, so
 * each route establishes the caller itself — see Middleware\RequireAdminMiddleware
 * and Ucrm\Auth. Deliberately a group rather than global: /webhook has no session
 * to authenticate (UISP delivers server-to-server), /api/ping is liveness, and
 * /_internal/* is loopback-checked in its own handler.
 */
$app->group("", function (RouteCollectorProxy $group) use ($page, $redirect): void {

$app = $group;

$app->get("/", fn(Request $request, Response $response) => $redirect($request, $response, "/options"));

/**
 * Options — one route per tab.
 *
 * Tabs are routes, not client-side panels, because every tabbed page on the
 * instance works that way (see Ui\Sections). Each tab is therefore its own small
 * form saving only its own key, via Options::replace().
 */
$app->get("/options", fn(Request $request, Response $response)
    => $redirect($request, $response, "/options/general"));

/**
 * Add one row, on a page of its own — the way /crm/client/new is a page rather
 * than a form under /crm/client/active. Registered BEFORE /options/{key} so
 * "new" and "import" are not swallowed by it: Slim matches in declaration order.
 */
$app->get("/options/import", function (Request $request, Response $response, Twig $twig) use ($page): Response {
    return $page($twig, $request, $response, "options/import.html.twig", "Provisioner - Options", [
        "heading" => sprintf(
            '<a href="%s?route=/options/general">Options</a> / <span class="primary">Import</span>',
            htmlspecialchars(Pages::base($request), ENT_QUOTES)
        ),
    ]);
});

$app->post("/options/import", function (Request $request, Response $response) use ($redirect): Response {
    $body    = (array) $request->getParsedBody();
    $payload = json_decode((string) ($body["payload"] ?? ""), true);

    if (!is_array($payload)) {
        error_log("(page:options) import rejected — not a JSON object");
        return $redirect($request, $response, "/options/import");
    }

    // Merge over what is stored rather than replacing wholesale: a document
    // carrying only bng_devices should not silently clear everything else.
    $merged = array_merge(Options::load(), array_intersect_key($payload, Options::defaults()));

    $saved = Options::save($merged);

    error_log(sprintf(
        "(page:options) imported — %d bng, %d radius, %d routers, %d prtg",
        count($saved["bng_devices"]),
        count($saved["radius_servers"]),
        count($saved["managed_routers"]),
        count($saved["prtg_template_devices"])
    ));

    return $redirect($request, $response, "/options/general");
});

$app->get("/options/{key}/new", function (Request $request, Response $response, Twig $twig, string $key) use ($page, $redirect): Response {
    $section = Sections::find($key);

    if ($section === null || ($section["field"] ?? null) === null) {
        return $redirect($request, $response, "/options/general");
    }

    $base = Pages::base($request);

    return $page($twig, $request, $response, "options/new.html.twig", "Provisioner - Options", [
        "key"     => $key,
        "section" => $section,
        // Breadcrumb, not a prefixed title — see the uisp-ui skill.
        "heading" => sprintf(
            '<a href="%s?route=/options/%s">%s</a> / <span class="primary">Add %s</span>',
            htmlspecialchars($base, ENT_QUOTES),
            htmlspecialchars($key, ENT_QUOTES),
            htmlspecialchars($section["heading"], ENT_QUOTES),
            htmlspecialchars($section["noun"], ENT_QUOTES)
        ),
    ]);
});

$app->post("/options/{key}/new", function (Request $request, Response $response, string $key) use ($redirect): Response {
    $section = Sections::find($key);

    if ($section === null || ($section["field"] ?? null) === null) {
        return $redirect($request, $response, "/options/general");
    }

    $body = (array) $request->getParsedBody();
    $row  = [];

    foreach ($section["fields"] as $field) {
        $row[$field["key"]] = trim((string) ($body[$field["key"]] ?? ""));
    }

    // Options::normalise() drops a row whose free-text fields are all empty, so
    // an empty submit is a no-op — one place decides what "meaningful" means.
    $saved = Options::append($section["field"], $row);

    error_log(sprintf("(page:options) %s added — %d total", $key, count($saved[$section["field"]])));

    return $redirect($request, $response, "/options/" . $key);
});

$app->get("/options/{key}", function (Request $request, Response $response, Twig $twig, string $key) use ($page, $redirect): Response {
    $section = Sections::find($key);

    if ($section === null) {
        return $redirect($request, $response, "/options/general");
    }

    $options = Options::load();

    $context = [
        "key"     => $key,
        "section" => $section,
        "options" => $options,
        "tabs"    => Sections::tabs(Pages::base($request), $key),
    ];

    if ($key === "general") {
        $context["service_plans"] = Api::internetServicePlans();
        $context["add"]           = Sections::addMenu(Pages::base($request));

        return $page($twig, $request, $response, "options/general.html.twig", "Provisioner - Options", $context);
    }

    $context["rows"] = $options[$section["field"]] ?? [];
    $context["add"]  = Sections::addMenu(Pages::base($request));

    return $page($twig, $request, $response, "options/list.html.twig", "Provisioner - Options", $context);
});

$app->post("/options/general", function (Request $request, Response $response) use ($redirect): Response {
    $body = (array) $request->getParsedBody();

    $saved = Options::replace(
        "supported_service_plan_ids",
        (array) ($body["supported_service_plan_ids"] ?? [])
    );

    error_log(sprintf(
        "(page:options) general saved — %d service plan(s)",
        count($saved["supported_service_plan_ids"])
    ));

    return $redirect($request, $response, "/options/general");
});

$app->post("/options/{key}/delete/{index}", function (Request $request, Response $response, string $key, string $index) use ($redirect): Response {
    $section = Sections::find($key);

    if ($section !== null && ($section["field"] ?? null) !== null) {
        Options::removeAt($section["field"], (int) $index);
        error_log(sprintf("(page:options) %s row %d deleted", $key, (int) $index));
    }

    return $redirect($request, $response, "/options/" . $key);
});

/**
 * Configs — one row per supported service. v2's configs page.
 *
 * DERIVED, not stored: services come from the CRM API and are filtered to the
 * plans Options marks supported. See Provisioning\Configs.
 */
$app->get("/configs", function (Request $request, Response $response, Twig $twig) use ($page): Response {
    $query = $request->getQueryParams();
    $q     = trim((string) ($query["q"] ?? ""));

    $rows = Configs::all();

    if ($q !== "") {
        $needle = mb_strtolower($q);
        $rows   = array_values(array_filter($rows, static fn(array $r): bool => str_contains(
            mb_strtolower($r["client_name"] . " " . $r["service_name"] . " " . $r["address"] . " " . $r["mac_address"] . " " . $r["static_ip"]),
            $needle
        )));
    }

    // Paged in PHP because the filter above is applied after the fetch — asking
    // the API for page 2 would page the unfiltered set.
    $total = count($rows);
    $pages = max(1, (int) ceil($total / 20));
    $pageN = min($pages, max(1, (int) ($query["page"] ?? 1)));

    return $page($twig, $request, $response, "configs.html.twig", "Provisioner - Configs", [
        "rows"       => array_slice($rows, ($pageN - 1) * 20, 20),
        "q"          => $q,
        "page"       => $pageN,
        "pages"      => $pages,
        "total"      => $total,
        "meta"       => $total . " service" . ($total === 1 ? "" : "s"),
        "configured" => Options::load()["supported_service_plan_ids"] !== [],
    ]);
});

$app->get("/configs/{id}", function (Request $request, Response $response, Twig $twig, string $id) use ($page, $redirect): Response {
    $serviceId = (int) $id;

    $row = null;

    foreach (Configs::all() as $candidate) {
        if ($candidate["service_id"] === $serviceId) {
            $row = $candidate;
            break;
        }
    }

    if ($row === null) {
        return $redirect($request, $response, "/configs");
    }

    $domains = BroadcastDomains::all();
    $default = "";

    foreach ($domains as $domain) {
        if ($domain["is_default"]) {
            $default = $domain["name"];
            break;
        }
    }

    return $page($twig, $request, $response, "config.html.twig", "Provisioner - " . $row["service_name"], [
        "row"            => $row,
        // Merged over the blank shape, so a record stored by an older
        // version cannot 500 the editor by lacking a key it now reads.
        "record"         => array_merge(Configs::blank(), Configs::find($serviceId) ?? []),
        "domains"        => $domains,
        "default_domain" => $default,
        "heading"        => sprintf(
            '<a href="%s?route=/configs">Configs</a> / <span class="primary">%s</span>',
            htmlspecialchars(Pages::base($request), ENT_QUOTES),
            htmlspecialchars($row["client_name"] . " — " . $row["service_name"], ENT_QUOTES)
        ),
    ]);
});

$app->post("/configs/{id}", function (Request $request, Response $response, string $id) use ($redirect): Response {
    $body = (array) $request->getParsedBody();

    $body["static_routes"] = json_decode((string) ($body["static_routes"] ?? "[]"), true) ?: [];

    Configs::save((int) $id, $body);

    error_log(sprintf("(page:configs) saved service:%d", (int) $id));

    return $redirect($request, $response, "/configs/" . (int) $id);
});

$app->post("/configs/{id}/forget", function (Request $request, Response $response, string $id) use ($redirect): Response {
    if (Configs::forget((int) $id)) {
        error_log(sprintf("(page:configs) discarded record for service:%d", (int) $id));
    }

    return $redirect($request, $response, "/configs");
});

/**
 * Logs — data/plugin.log, parsed. See Provisioning\Logs.
 */
$app->get("/logs", function (Request $request, Response $response, Twig $twig) use ($page): Response {
    $q    = trim((string) ($request->getQueryParams()["q"] ?? ""));
    $rows = Logs::read($q);

    return $page($twig, $request, $response, "logs.html.twig", "Provisioner - Logs", [
        "rows"    => $rows,
        "q"       => $q,
        "sources" => Logs::sources(),
        "meta"    => count($rows) . " line" . (count($rows) === 1 ? "" : "s")
            . ($q !== "" ? " matching" : ""),
    ]);
});

$app->post("/logs/clear", function (Request $request, Response $response) use ($redirect): Response {
    Logs::clear();

    return $redirect($request, $response, "/logs");
});

$app->get("/domains", function (Request $request, Response $response, Twig $twig) use ($page): Response {
    $domains = BroadcastDomains::all();

    return $page($twig, $request, $response, "domains.html.twig", "Provisioner - " . Vocabulary::DOMAIN_PLURAL, [
        "domains" => $domains,
        "meta"    => count($domains) . " configured",
        "add"     => [
            "default" => ["href" => Pages::base($request) . "?route=/domains/new"],
            "items"   => [
                ["href"  => Pages::base($request) . "?route=/domains/new",
                 "label" => "Add " . Vocabulary::DOMAIN],
                ["href"  => Pages::base($request) . "?route=/domains/import",
                 "label" => "Import " . Vocabulary::DOMAIN_PLURAL],
            ],
        ],
    ]);
});

$app->get("/domains/new", function (Request $request, Response $response, Twig $twig) use ($page): Response {
    $existing = BroadcastDomains::all();

    return $page($twig, $request, $response, "domain-new.html.twig", "Provisioner - " . Vocabulary::DOMAIN, [
        "heading" => sprintf(
            '<a href="%s?route=/domains">%s</a> / <span class="primary">Add %s</span>',
            htmlspecialchars(Pages::base($request), ENT_QUOTES),
            htmlspecialchars(Vocabulary::DOMAIN_PLURAL, ENT_QUOTES),
            htmlspecialchars(strtolower(Vocabulary::DOMAIN), ENT_QUOTES)
        ),
        "suggested" => Vocabulary::DOMAIN . ($existing === [] ? "" : " " . (count($existing) + 1)),
        // The first one is the default whether or not the box is ticked
        // (BroadcastDomains::commit enforces it), so pre-tick it rather than let
        // the form imply otherwise.
        "first"     => $existing === [],
    ]);
});

$app->post("/domains/new", function (Request $request, Response $response) use ($redirect): Response {
    $body = (array) $request->getParsedBody();

    $domain = BroadcastDomains::save([
        "name"       => (string) ($body["name"] ?? ""),
        "is_default" => isset($body["is_default"]),
        "configured" => false,
    ]);

    error_log(sprintf("(page:domains) created domain:%s — %s", $domain["id"], $domain["name"]));

    // Straight into the full editor: the rest of a domain is chosen from Options,
    // which is where the operator was heading anyway.
    return $redirect($request, $response, "/domains/" . $domain["id"]);
});

$app->get("/domains/import", function (Request $request, Response $response, Twig $twig) use ($page): Response {
    return $page($twig, $request, $response, "domain-import.html.twig", "Provisioner - " . Vocabulary::DOMAIN_PLURAL, [
        "heading" => sprintf(
            '<a href="%s?route=/domains">%s</a> / <span class="primary">Import</span>',
            htmlspecialchars(Pages::base($request), ENT_QUOTES),
            htmlspecialchars(Vocabulary::DOMAIN_PLURAL, ENT_QUOTES)
        ),
    ]);
});

$app->post("/domains/import", function (Request $request, Response $response) use ($redirect): Response {
    $body    = (array) $request->getParsedBody();
    $payload = json_decode((string) ($body["payload"] ?? ""), true);
    $rows    = is_array($payload["domains"] ?? null) ? $payload["domains"] : null;

    if ($rows === null) {
        error_log("(page:domains) import rejected — no `domains` array");
        return $redirect($request, $response, "/domains/import");
    }

    BroadcastDomains::replaceAll($rows);

    error_log(sprintf("(page:domains) imported — %d %s", count($rows), strtolower(Vocabulary::DOMAIN_PLURAL)));

    return $redirect($request, $response, "/domains");
});

$app->get("/domains/{id}", function (Request $request, Response $response, Twig $twig, string $id) use ($page, $redirect): Response {
    $domain = BroadcastDomains::find($id);

    if ($domain === null) {
        return $redirect($request, $response, "/domains");
    }

    $options = Options::load();

    // The inventories a domain picks from, by name. See name-checklist.html.twig
    // for why a selection is a name rather than a copy.
    $names = static fn(array $rows): array => array_values(array_filter(array_map(
        static fn(array $row): string => (string) ($row["name"] ?? ""),
        $rows
    )));

    // Breadcrumb in the h1, which is what native detail pages do (plugins/show,
    // tariff/edit): parent as a link, current segment as `.primary`. A prefixed
    // title would read as a different page rather than a child of the list.
    $breadcrumb = sprintf(
        '<a href="%s?route=/domains">%s</a> / <span class="primary">%s</span>',
        htmlspecialchars(Pages::base($request), ENT_QUOTES),
        htmlspecialchars(Vocabulary::DOMAIN_PLURAL, ENT_QUOTES),
        htmlspecialchars($domain["name"], ENT_QUOTES)
    );

    return $page($twig, $request, $response, "domain.html.twig", "Provisioner - " . $domain["name"], [
        "heading"   => $breadcrumb,
        "domain"    => $domain,
        "available" => [
            "bng_devices"           => $names($options["bng_devices"]),
            "radius_servers"        => $names($options["radius_servers"]),
            "prtg_template_devices" => $names($options["prtg_template_devices"]),
        ],
    ]);
});

$app->post("/domains/{id}", function (Request $request, Response $response, string $id) use ($redirect): Response {
    $body = (array) $request->getParsedBody();

    // The id comes from the URL, not the body: a posted id would let one form
    // overwrite a different domain.
    $body["id"] = $id;

    // An unchecked checkbox posts nothing at all, so absence is the "off" signal
    // rather than a missing field.
    $body["is_default"]          = isset($body["is_default"]);
    $body["option_82_supported"] = isset($body["option_82_supported"]);
    $body["qos_supported"]       = isset($body["qos_supported"]);
    $body["configured"]          = true;

    foreach (["static_ip_blocks", "static_ip_exclusions", "static_route_blocks", "static_route_exclusions"] as $list) {
        $body[$list] = json_decode((string) ($body[$list] ?? "[]"), true) ?: [];
    }

    $body["created_at"] = BroadcastDomains::find($id)["created_at"] ?? null;

    $saved = BroadcastDomains::save($body);

    error_log(sprintf("(page:domains) saved domain:%s — %s", $saved["id"], $saved["name"]));

    return $redirect($request, $response, "/domains/" . $saved["id"]);
});

$app->post("/domains/{id}/delete", function (Request $request, Response $response, string $id) use ($redirect): Response {
    $domain = BroadcastDomains::find($id);

    // The default is what services fall back to; deleting it would leave them
    // pointing at nothing. The UI disables the button, and this is the half that
    // actually enforces it.
    if ($domain !== null && !$domain["is_default"] && BroadcastDomains::delete($id)) {
        error_log(sprintf("(page:domains) deleted domain:%s", $id));
    }

    return $redirect($request, $response, "/domains");
});

})->add(new RequireAdminMiddleware());

// NOTE: php-di/slim-bridge injects controller arguments BY NAME — the parameters
// must be called `$request` and `$response` exactly. Renaming them to $req/$res
// throws NotEnoughParametersException at invoke time, not at boot.
$app->group("/api", function (RouteCollectorProxy $group) use ($json): void {

    // Liveness only. Deliberately unauthenticated, and deliberately says nothing
    // about configuration or credentials.
    $group->get(
        "/ping",
        fn(Request $request, Response $response) => $json($response, ["ping" => "pong"])
    );

    $group->map(
        ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
        "/{path:.*}",
        fn(Request $request, Response $response) => $json($response, ["error" => "Not Found"], 404)
    );
});


/**
 * Inbound UISP service-lifecycle webhooks.
 *
 * Registered automatically by hook_install.php (see Ucrm\WebhookRegistrar) —
 * UISP has no API for webhook endpoint management, so registration writes to its
 * database directly.
 *
 * UISP delivers over plain-HTTP loopback from inside its own container, so the
 * request never crosses the network. It is also UNAUTHENTICATED: UISP does not
 * sign webhook deliveries, and webhook_address carries no shared secret. Anything
 * able to reach this path locally can post to it, so treat the payload's
 * service id as a hint and re-read state from the CRM API before acting on it.
 */
$app->post("/webhook", function (Request $request, Response $response) use ($json): Response {
    $payload = $request->getParsedBody();

    $event    = is_array($payload) ? (string) ($payload["eventName"] ?? "unknown") : "unknown";
    $entity   = is_array($payload) ? (string) ($payload["entity"] ?? "unknown") : "unknown";
    $entityId = is_array($payload) ? (string) ($payload["entityId"] ?? "?") : "?";

    // Token names the trigger (which event arrived); the object is written as
    // `type:id` in the message so `grep 'service:404'` still follows it across
    // every subsystem. See *Log format* in CLAUDE.md.
    // TODO: push to Nautobot (SoT), then run the provision Job with this service_id.
    error_log(sprintf("(webhook:%s) %s:%s accepted", $event, $entity, $entityId));

    // Always 200: UISP retries on failure, and a retry storm helps nobody while
    // the handler is still a stub.
    return $json($response, ["received" => true]);
});

/**
 * Invalidate one of UISP's own APCu caches. LOOPBACK ONLY.
 *
 * Several things UISP derives from a plugin's files are cached in APCu and
 * rebuilt on a miss — which zone JS a plugin ships
 * (`PluginCustomJavaScriptLoader`), and the assembled sidebar menu
 * (`PluginsMenuItemsLoader`). UISP invalidates them from its own plugin
 * transactions; editing files in place, which is the dev loop here, does not.
 *
 * **APCu is per-SAPI.** A CLI hook clearing these does nothing to the copy
 * php-fpm reads — `apc.enable_cli` is On and a CLI process still reports zero
 * entries while php-fpm holds hundreds. This route runs *in* php-fpm, which is
 * the entire reason it exists. Ucrm\Server calls it over loopback.
 *
 * Only ever deletes entries whose key names one of the loaders below, all of
 * which UISP rebuilds on the next request. The allow-list is not decoration: the
 * key comes from a query string, and an unbounded match here would let a loopback
 * caller flush UISP's entire cache.
 */
$app->post("/_internal/invalidate-cache", function (Request $request, Response $response) use ($json): Response {
    $remote = $request->getServerParams()["REMOTE_ADDR"] ?? "";

    if (!in_array($remote, ["127.0.0.1", "::1"], true)) {
        return $json($response, ["error" => "Not Found"], 404);
    }

    $marker = (string) ($request->getQueryParams()["cache"] ?? "");

    if (!in_array($marker, ["PluginCustomJavaScriptLoader", "PluginsMenuItemsLoader"], true)) {
        return $json($response, ["error" => "unknown cache"], 400);
    }

    if (!function_exists("apcu_cache_info")) {
        return $json($response, ["supported" => false, "deleted" => 0]);
    }

    $info    = @apcu_cache_info(false);
    $deleted = 0;

    foreach (($info["cache_list"] ?? []) as $entry) {
        $key = $entry["info"] ?? "";
        // Symfony's cache adapter URL-encodes the id, e.g.
        // "<ns>:%5BAppBundle%5CService%5CPlugin%5CPluginCustomJavaScriptLoader%3AhasAdminZoneJs%5D%5B1%5D"
        if (stripos(rawurldecode((string) $key), $marker) !== false) {
            if (apcu_delete($key)) {
                $deleted++;
            }
        }
    }

    return $json($response, ["supported" => true, "deleted" => $deleted, "cache" => $marker]);
});

$app->map(
    ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"],
    "/{path:.*}",
    fn(Request $request, Response $response) => $json($response, ["error" => "Not Found"], 404)
);

$app->run();
