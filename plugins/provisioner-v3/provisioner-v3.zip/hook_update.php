<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Runs after the plugin's version changes.
 *
 * Fired by UISP after an admin-UI update, and by Updater after a self-update —
 * in the latter case as a FRESH process, so this file and everything it loads is
 * the new code, with PLUGIN_UPDATE_FROM / PLUGIN_UPDATE_TO in the environment.
 *
 * Keep this idempotent and cheap: it may run twice for the same version if an
 * update is retried, and it runs while UISP holds the plugin's execution lock.
 */

require_once __DIR__ . "/bootstrap.php";

use Archous\Provisioner\Ucrm\Server;
use Archous\Provisioner\Ucrm\WebhookRegistrar;

$from = getenv("PLUGIN_UPDATE_FROM") ?: "?";
$to   = getenv("PLUGIN_UPDATE_TO") ?: "?";

error_log(sprintf("(hook:update) %s -> %s", $from, $to));

// Re-assert the webhook. The URL is version-independent so this is normally a
// no-op, but an update that changes the route would otherwise leave UISP
// delivering to a path that no longer exists.
try {
    $result = WebhookRegistrar::install();
    error_log(sprintf("(hook:update) webhook %s (%d events)", $result["action"], $result["events"]));
} catch (\Throwable $e) {
    error_log(sprintf("(hook:update) webhook registration FAILED — %s", $e->getMessage()));
}

// A version that newly ships public/ assets needs the web-root symlink and a
// cache invalidation; UISP does both itself on an admin-UI update, but a
// self-update has to.
try {
    if (Server::createPublicSymlink()) {
        error_log("(hook:update) public/ symlink created in web root");
    }

    $cleared = Server::invalidateZoneJsCache();

    if ($cleared !== null && $cleared > 0) {
        error_log(sprintf("(hook:update) zone JS cache invalidated (%d)", $cleared));
    }
} catch (\Throwable $e) {
    error_log(sprintf("(hook:update) public asset refresh FAILED — %s", $e->getMessage()));
}
