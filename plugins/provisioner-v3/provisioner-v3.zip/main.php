<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * CRM-triggered execution: the manual "Execute" button and UISP's scheduler.
 *
 * Bulk provision — the Nautobot Job called WITHOUT a service_id. That is now the
 * ONLY job of this file, so the plugin's execution period can be set to whatever
 * provisioning actually needs.
 *
 * Updating this plugin is the `marketplace` plugin's responsibility. It was
 * briefly done here, which meant a scheduled run sometimes spent its slot
 * updating and exited before provisioning. Worth remembering if self-update is
 * ever reconsidered: a plugin cannot use UISP's own PluginFacade on itself —
 * updatePlugin() refuses while the target is running, and plugins.sh holds that
 * lock for the whole of this file. Everything needed to work around that
 * (a second lock, backup/rollback, a health check in a fresh process, telling our
 * own run from another) existed here and is now deleted, because updating from a
 * DIFFERENT plugin removes the hazard instead of mitigating it.
 */

require_once __DIR__ . "/bootstrap.php";

use SpaethTech\Ucrm\Log;

// TODO: call the Nautobot provision Job with no service_id (=> bulk).
Log::write("cron", "bulk provision — not yet implemented");
