<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * CRM-triggered execution: the manual "Execute" button, UISP's scheduler, and
 * `.ucrm-plugin-execution-requested` (picked up every minute).
 *
 * Two jobs, in this order and for a reason:
 *
 *   1. Self-update, if one is available.
 *   2. Bulk provision — the Nautobot Job called WITHOUT a service_id.
 *
 * UISP serialises this file behind `.ucrm-plugin-running`, which is exactly why
 * the update lives here and not in public.php: replacing the plugin's own files
 * must never happen concurrently, and public.php explicitly bypasses that lock.
 */

require_once __DIR__ . "/bootstrap.php";

use Archous\Provisioner\Plugin;

// ── 1. update ───────────────────────────────────────────────────────────────
$result = Plugin::update();

if ($result["updated"]) {
    error_log(sprintf("(update) %s -> %s applied", $result["from"], $result["to"]));

    // STOP. Every file this process loaded from — src/, vendor/, main.php itself
    // — has just been replaced on disk, and Composer's autoloader resolves
    // lazily, so anything not already in memory would resolve against new files
    // with a stale map. Bulk provisioning runs on the next tick, on the new code.
    // UISP's cron fires within a minute, so nothing is meaningfully delayed.
    error_log("(update) stopping this run; bulk provision resumes next tick on the new version");
    exit(0);
}

if ($result["reason"] !== null) {
    error_log(sprintf("(update) not applied — %s", $result["reason"]));
}

// ── 2. bulk provision ───────────────────────────────────────────────────────
// TODO: call the Nautobot provision Job with no service_id (=> bulk).
error_log("(cron) bulk provision — not yet implemented");
