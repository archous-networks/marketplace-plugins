<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * PHP-DI definitions. Returned to ContainerBuilder in public.php.
 */

use Psr\Container\ContainerInterface;
use Slim\Views\Twig;

return [
    "settings" => [
        // TODO: drive from an environment/debug flag before this ships anywhere real.
        "displayErrorDetails" => true,
    ],

    "twig" => [
        "cache" => false,
        "debug" => true,
        "auto_reload" => true,
        "strict_variables" => true,
    ],

    Twig::class => function (ContainerInterface $c): Twig {
        $settings = $c->get("twig");

        return Twig::create(__DIR__ . "/views", [
            "cache" => $settings["cache"],
            "debug" => $settings["debug"],
            "auto_reload" => $settings["auto_reload"],
            "strict_variables" => $settings["strict_variables"],
        ]);
    },
];
