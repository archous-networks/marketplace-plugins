<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 *
 * Runs once when UISP installs the plugin.
 *
 * Registers the service-lifecycle webhook so an operator never has to configure
 * it by hand per instance. Idempotent — re-running changes nothing.
 */

require_once __DIR__ . "/bootstrap.php";

use Archous\Provisioner\Ucrm\Server;
use Archous\Provisioner\Ucrm\WebhookRegistrar;

// Repair the web-root symlink for public/ assets. UISP creates this itself when
// installing a ZIP that already contains public/, so this is normally a no-op —
// it matters in the development loop, where files are copied into an already
// installed plugin and UISP never re-runs createPublicSymlink().
try {
    if (Server::createPublicSymlink()) {
        error_log("(hook:install) public/ symlink created in web root");
    }

    // UISP caches "which plugins ship zone JS" in APCu, and APCu is per-SAPI, so
    // this hook cannot clear php-fpm's copy directly — it asks our own public.php
    // to do it, which runs in the right process. Without this, a freshly created
    // symlink serves assets that UISP still does not reference.
    $cleared = Server::invalidateZoneJsCache();

    if ($cleared !== null && $cleared > 0) {
        error_log(sprintf("(hook:install) zone JS cache invalidated (%d entr%s)", $cleared, $cleared === 1 ? "y" : "ies"));
    } elseif ($cleared === null) {
        error_log("(hook:install) could not reach public.php to invalidate the zone JS cache");
    }

    if (Server::hasZoneJsRegistered() === false) {
        error_log(
            "(hook:install) zone JS present on disk but has_*_zone_js is false in UISP — "
            . "re-install or re-enable the plugin so UISP re-scans the files"
        );
    }
} catch (\Throwable $e) {
    error_log(sprintf("(hook:install) public asset check FAILED — %s", $e->getMessage()));
}

try {
    $result = WebhookRegistrar::install();

    error_log(sprintf(
        "(hook:install) webhook %s — %s (%d events)",
        $result["action"],
        $result["url"],
        $result["events"]
    ));
} catch (\Throwable $e) {
    // Do not rethrow: a failed webhook registration should not abort the install.
    // The plugin still works for scheduled and manual runs, and this is
    // recoverable by reinstalling once the cause is fixed.
    error_log(sprintf(
        "(hook:install) webhook registration FAILED — %s [%s:%d]",
        $e->getMessage(),
        $e->getFile(),
        $e->getLine()
    ));
}
