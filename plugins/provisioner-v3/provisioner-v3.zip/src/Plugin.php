<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner;

use RuntimeException;

/**
 * Read-only access to what UISP writes for this plugin.
 *
 *   /ucrm.json          at the plugin ROOT (not in data/) — URLs, pluginAppKey, pluginId
 *   /data/config.json   the manifest `configuration` values — nautobot_url, nautobot_token
 *
 * Both hold live secrets. Never log a value from either; see *Credentials and
 * tenancy* in CLAUDE.md.
 */
final class Plugin
{
    /** @var array<string,mixed>|null */
    private static ?array $ucrm = null;

    /** @var array<string,mixed>|null */
    private static ?array $config = null;

    public static function dir(): string
    {
        return dirname(__DIR__);
    }

    /**
     * UISP-written plugin metadata. Lives at the plugin root — NOT in data/.
     *
     * @return array<string,mixed>
     */
    public static function ucrm(): array
    {
        return self::$ucrm ??= self::readJson(self::dir() . "/ucrm.json");
    }

    /**
     * Operator-supplied configuration from the manifest's `configuration` block.
     *
     * @return array<string,mixed>
     */
    public static function config(): array
    {
        return self::$config ??= self::readJson(self::dir() . "/data/config.json");
    }

    public static function name(): string
    {
        // Derived from the install directory rather than duplicated in code, so
        // it cannot drift from what UISP actually calls this plugin.
        return basename(self::dir());
    }

    /**
     * The plugin's own HTTP entry point as reachable from INSIDE UISP.
     *
     * Deliberately built on `ucrmLocalUrl` rather than `pluginPublicUrl`: UISP
     * delivers webhooks from its own container, so looping back over the public
     * hostname needs working hairpin NAT and a valid certificate to reach a
     * service already running locally. v2 hardcoded `http://localhost/...` for
     * the same reason; this derives it instead.
     */
    public static function localUrl(string $route = ""): string
    {
        $ucrm = self::ucrm();

        $local  = (string) ($ucrm["ucrmLocalUrl"] ?? "");
        $public = (string) ($ucrm["pluginPublicUrl"] ?? "");

        $scheme = parse_url($local, PHP_URL_SCHEME);
        $host   = parse_url($local, PHP_URL_HOST);
        $port   = parse_url($local, PHP_URL_PORT);
        $path   = parse_url($public, PHP_URL_PATH);

        if (!is_string($scheme) || !is_string($host) || !is_string($path) || $path === "") {
            throw new RuntimeException("ucrm.json is missing or malformed: ucrmLocalUrl / pluginPublicUrl");
        }

        // Take ONLY scheme/host/port from ucrmLocalUrl and the whole path from
        // pluginPublicUrl. ucrmLocalUrl is "http://localhost/crm/" — it already
        // carries the /crm prefix that pluginPublicUrl's path also has, so naive
        // concatenation yields "/crm/crm/_plugins/...". That registers a webhook
        // UISP will happily accept and then never deliver anywhere useful.
        $origin = $scheme . "://" . $host . ($port !== null ? ":" . $port : "");

        return $origin . $path . ($route !== "" ? "?route=" . $route : "");
    }

    /**
     * @return array<string,mixed>
     */
    private static function readJson(string $path): array
    {
        if (!is_readable($path)) {
            throw new RuntimeException("cannot read $path — has UISP finished installing the plugin?");
        }

        $data = json_decode((string) file_get_contents($path), true);

        if (!is_array($data)) {
            throw new RuntimeException("$path is not valid JSON");
        }

        return $data;
    }
}
