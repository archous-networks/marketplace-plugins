<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ucrm;

use RuntimeException;

/**
 * The slim CRM API client. Read side only, so far.
 *
 * CLAUDE.md's *Layout*: there is no standalone SDK in v3 — the API layer is part
 * of the plugin and lives under src/ with everything else. This is that layer,
 * and it stays small on purpose.
 *
 * ── AUTH ────────────────────────────────────────────────────────────────────
 * `X-Auth-App-Key` with `ucrm.json`'s `pluginAppKey`, which UISP writes at
 * install and regenerates on demand. No credential is stored by the plugin and
 * none is committed — see *Credentials and tenancy*.
 *
 * ⚠️ The app key must never reach a browser. Every call here is server-side, from
 * PHP, which is also why the CSP question never arises for these pages.
 *
 * ── LOOPBACK ────────────────────────────────────────────────────────────────
 * `ucrmLocalUrl` rather than `ucrmPublicUrl`: the request never leaves the
 * container, so no public hostname, DNS or certificate is involved. Note that it
 * already ends in `/crm/` — concatenating a path that also starts with `crm/`
 * yields `/crm/crm/...`, which UISP accepts and then never serves.
 */
final class Api
{
    /**
     * Internet service plans, as the Options page offers them.
     *
     * @return array<int,array{id:int,name:string}>
     */
    public static function internetServicePlans(): array
    {
        $plans = self::get("service-plans", ["servicePlanType" => "internet"]);

        if ($plans === null) {
            return [];
        }

        $out = [];

        foreach ($plans as $plan) {
            if (is_array($plan) && isset($plan["id"])) {
                $out[] = ["id" => (int) $plan["id"], "name" => (string) ($plan["name"] ?? "")];
            }
        }

        return $out;
    }

    /**
     * Every service, paged through to the end.
     *
     * The CRM API has no filter for "services on these plans", so the whole set is
     * fetched and filtered here. Acceptable at this instance's size (a few hundred)
     * and bounded by MAX_PAGES so a runaway cannot walk forever — but it IS a full
     * fetch per page load, and the first thing to reconsider if this gets slow.
     * Nautobot owning provisioning state would remove the need entirely.
     *
     * @return array<int,array<string,mixed>>
     */
    public static function services(): array
    {
        return self::paged("clients/services");
    }

    /** @return array<int,array<string,mixed>> */
    public static function clients(): array
    {
        return self::paged("clients");
    }

    /**
     * A client's display name, matching how UISP writes it in a grid.
     *
     * @param array<string,mixed> $client
     */
    public static function clientName(array $client): string
    {
        $company = trim((string) ($client["companyName"] ?? ""));

        if ($company !== "") {
            return $company;
        }

        // "Last, First" — the order UISP's own client grid uses.
        $name = trim(trim((string) ($client["lastName"] ?? "")) . ", " . trim((string) ($client["firstName"] ?? "")));

        return trim($name, " ,") !== "" ? trim($name, " ,") : "#" . (string) ($client["id"] ?? "?");
    }

    private const PAGE      = 500;
    private const MAX_PAGES = 20;

    /** @return array<int,array<string,mixed>> */
    private static function paged(string $path): array
    {
        $out = [];

        for ($page = 0; $page < self::MAX_PAGES; $page++) {
            $batch = self::get($path, [
                "limit"  => (string) self::PAGE,
                "offset" => (string) ($page * self::PAGE),
            ]);

            if (!is_array($batch) || $batch === []) {
                break;
            }

            foreach ($batch as $row) {
                if (is_array($row)) {
                    $out[] = $row;
                }
            }

            if (count($batch) < self::PAGE) {
                break;
            }
        }

        return $out;
    }

    /**
     * @param array<string,string> $query
     * @return array<int|string,mixed>|null null when the call could not be made
     *         or UISP refused it — callers render an empty list rather than an
     *         error page, because a missing inventory is not a broken page.
     */
    public static function get(string $path, array $query = []): ?array
    {
        [$base, $key] = self::credentials();

        $url = rtrim($base, "/") . "/api/v1.0/" . ltrim($path, "/")
             . ($query !== [] ? "?" . http_build_query($query) : "");

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER     => [
                "Content-Type: application/json",
                "X-Auth-App-Key: " . $key,
            ],
        ]);

        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        // `type:id` in the message so one object can be grepped across every
        // subsystem — see *Log format* in CLAUDE.md. Never the key.
        if ($code !== 200 || !is_string($body)) {
            error_log(sprintf(
                "(ucrm:%s) GET -> %d%s",
                $path,
                $code,
                $err !== "" ? " — " . $err : ""
            ));

            return null;
        }

        $data = json_decode($body, true);

        return is_array($data) ? $data : null;
    }

    /**
     * @return array{0:string,1:string} [ucrmLocalUrl, pluginAppKey]
     */
    private static function credentials(): array
    {
        // ucrm.json is at the plugin ROOT, not in data/ — confirmed against a real
        // install, and the reason the archive has to exclude it explicitly.
        $path = dirname(__DIR__, 2) . "/ucrm.json";

        if (!is_readable($path)) {
            throw new RuntimeException("cannot read $path — has UISP finished installing the plugin?");
        }

        $u = json_decode((string) file_get_contents($path), true);

        $base = (string) ($u["ucrmLocalUrl"] ?? "");
        $key  = (string) ($u["pluginAppKey"] ?? "");

        if ($base === "" || $key === "") {
            throw new RuntimeException("ucrm.json is missing ucrmLocalUrl or pluginAppKey");
        }

        return [$base, $key];
    }
}
