<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ucrm;

use Archous\Provisioner\Plugin;
use RuntimeException;

/**
 * Who is calling public.php, and may they be here?
 *
 * **`public.php` is served with NO authentication.** Ubiquiti's own docs say so,
 * and it is reachable from outside whether or not the operator ever opens a plugin
 * page. Every route that reads or writes provisioning configuration therefore has
 * to establish the caller itself — the surrounding UISP chrome protects the page
 * that FRAMES us, not us.
 *
 * The supported way to identify a caller is to hand its cookies back to UISP and
 * ask (see docs/security.md in the `plugins` skill):
 *
 *     GET /crm/current-user  with  nms-crm-php-session-id + nms-session
 *
 * 403 means not authenticated. A 200 carries `isClient`, `permissions` and
 * `specialPermissions`.
 *
 * Note the cookies changed in UISP 1.0: the old `PHPSESSID` / `/current-user`
 * shape belongs to standalone UCRM 2.x and does not apply here.
 *
 * ── ADMIN ONLY ──────────────────────────────────────────────────────────────
 * Two independent conditions, and both must hold:
 *
 * 1. `isClient === false`. A client-zone session is perfectly authenticated and
 *    has no business here at all. Checked explicitly rather than inferred from
 *    permissions, because a client's `permissions` map is empty — so a
 *    permission-only check would fail open if the map were ever populated.
 *
 * 2. `permissions["system/plugins"]` is `view` or `edit`. This is the same
 *    permission UISP gates the framing page on — `PluginPublicPageController`
 *    carries `@PermissionControllerName(PluginController::class)` and
 *    `@Permission("view")`. Matching it means an operator who cannot see the
 *    plugin in UISP cannot reach its pages by URL either.
 *
 * Writes additionally require `edit`, so a view-only admin can read the
 * configuration without changing it.
 */
final class Auth
{
    /** The permission UISP itself gates plugin pages on. */
    private const PERMISSION = "system/plugins";

    /** @var array<string,mixed>|null resolved once per request */
    private static ?array $user = null;
    private static bool $resolved = false;

    /**
     * The current admin, or null.
     *
     * @return array<string,mixed>|null
     */
    public static function admin(): ?array
    {
        if (self::$resolved) {
            return self::$user;
        }

        self::$resolved = true;
        $user = self::currentUser();

        if ($user === null) {
            return self::$user = null;
        }

        // A client-zone session is authenticated and still not welcome.
        if (($user["isClient"] ?? true) !== false) {
            return self::$user = null;
        }

        if (!in_array($user["permissions"][self::PERMISSION] ?? null, ["view", "edit"], true)) {
            return self::$user = null;
        }

        return self::$user = $user;
    }

    /** May the current admin change things, or only look? */
    public static function canEdit(): bool
    {
        $user = self::admin();

        return $user !== null
            && ($user["permissions"][self::PERMISSION] ?? null) === "edit";
    }

    /**
     * A CSRF token bound to this session.
     *
     * Cookies alone are not enough for a state-changing request: an authenticated
     * admin browsing a hostile page would otherwise have their session used to
     * rewrite this instance's provisioning configuration. The marketplace plugin
     * solves this with a custom header, which works there because every call is
     * `fetch()` — it cannot work here, because these are ordinary form posts from
     * ordinary page loads and a browser sends no such header.
     *
     * So: HMAC the session id with `ucrm.json`'s app key. Stateless (no storage,
     * no expiry to manage), unforgeable without the key, and automatically invalid
     * for a different session. The key never leaves the server; only the digest
     * reaches the page.
     */
    public static function token(): string
    {
        $session = "";

        foreach (["nms-crm-php-session-id", "nms-session"] as $name) {
            $session .= (string) ($_COOKIE[$name] ?? "");
        }

        return hash_hmac("sha256", $session, self::appKey());
    }

    /** Constant-time comparison, so a wrong token cannot be found by timing. */
    public static function validToken(?string $given): bool
    {
        return is_string($given) && hash_equals(self::token(), $given);
    }

    private static function appKey(): string
    {
        // ucrm.json is at the plugin ROOT, not in data/. UISP writes it at install.
        $path = dirname(__DIR__, 2) . "/ucrm.json";

        if (!is_readable($path)) {
            throw new RuntimeException("cannot read $path — has UISP finished installing the plugin?");
        }

        $key = (string) (json_decode((string) file_get_contents($path), true)["pluginAppKey"] ?? "");

        if ($key === "") {
            throw new RuntimeException("ucrm.json has no pluginAppKey");
        }

        return $key;
    }

    /**
     * Ask UISP who the session belongs to, or null when it says nobody.
     *
     * @return array<string,mixed>|null
     */
    private static function currentUser(): ?array
    {
        $cookies = [];

        foreach (["nms-crm-php-session-id", "nms-session"] as $name) {
            $raw = (string) ($_COOKIE[$name] ?? "");

            // Session ids are opaque tokens; strip anything that is not one so a
            // crafted cookie cannot inject a header.
            $clean = preg_replace('~[^a-zA-Z0-9._-]~', "", $raw);

            if ($clean !== "" && $clean !== null) {
                $cookies[] = $name . "=" . $clean;
            }
        }

        if ($cookies === []) {
            return null;
        }

        // Loopback, so no public hostname or certificate is involved.
        $url = rtrim(Plugin::ucrmLocalUrl(), "/") . "/current-user";

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER     => [
                "Content-Type: application/json",
                "Cookie: " . implode("; ", $cookies),
            ],
        ]);

        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code !== 200 || !is_string($body)) {
            return null;
        }

        $user = json_decode($body, true);

        return is_array($user) ? $user : null;
    }
}
