<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ucrm;

use Archous\Provisioner\Plugin;

/**
 * Operations against the UISP installation itself, for the cases where UISP does
 * something on our behalf that we sometimes need to reproduce or repair.
 *
 * Everything here reaches outside the plugin directory and is therefore
 * inherently fragile across UISP upgrades. Each method documents what it is
 * mirroring, so a behaviour change upstream is traceable rather than mysterious.
 * Prefer letting UISP do its own work — reach for this only when it has not.
 */
final class Server
{
    /** Where UISP materialises the publicly-served view of each enabled plugin. */
    private const PUBLIC_PLUGINS_DIR = "/usr/src/ucrm/web/_plugins";

    /** UISP's own Symfony console — the same binary `plugins.sh` drives. */
    private const CONSOLE = "/usr/src/ucrm/app/console";

    /** Compiled Twig templates. Removing this forces a re-compile. */
    private const TWIG_CACHE_DIR = "/usr/src/ucrm/app/cache/prod/twig";

    /**
     * Run one of UISP's own console commands.
     *
     * **Prefer this over reimplementing anything.** UISP ships commands that do
     * the housekeeping a self-update needs, and calling them means a change to
     * UISP's internals is picked up for free rather than silently diverging from
     * a copy of its logic:
     *
     *   crm:plugin:update-database-information   version + has_*_zone_js, from manifests
     *   crm:plugin:symlink                       regenerate web-root public/ symlinks
     *   crm:plugin:ucrm-config                   regenerate ucrm.json for every plugin
     *
     * Verified against a deliberately broken install: with ucrm.json deleted, the
     * symlink removed and the database showing version 0.0.0 with zone JS off,
     * those three restored every one of them.
     *
     * ⚠️ What they CANNOT do is invalidate the zone-JS cache the web sees. They
     * run under the CLI SAPI, and APCu segments are per-SAPI — `apc.enable_cli`
     * is On here and a CLI process still reports 0 entries while php-fpm holds
     * hundreds. Use invalidateZoneJsCache() for that; it goes through public.php
     * precisely because that runs in the right process.
     *
     * Returns false if the console is missing or the command fails; callers
     * should treat that as "fall back", not "give up".
     */
    public static function console(string $command, array $args = []): bool
    {
        if (!is_file(self::CONSOLE)) {
            error_log(sprintf("(ucrm) console not found at %s", self::CONSOLE));
            return false;
        }

        $parts = [escapeshellarg(self::php()), escapeshellarg(self::CONSOLE), escapeshellarg($command)];

        foreach ($args as $arg) {
            $parts[] = escapeshellarg((string) $arg);
        }

        $parts[] = "--env=prod";
        $parts[] = "--no-interaction";

        exec(implode(" ", $parts) . " 2>&1", $out, $code);

        if ($code !== 0) {
            error_log(sprintf("(ucrm) %s exited %d: %s", $command, $code, implode(" | ", array_slice($out, 0, 3))));
            return false;
        }

        return true;
    }

    /** UISP's Symfony autoloader — boots its kernel, not ours. */
    private const UCRM_AUTOLOAD = "/usr/src/ucrm/app/autoload.php";

    /**
     * A PHP binary that can actually run `-r`.
     *
     * NOT PHP_BINARY. Under php-fpm that constant is the FPM master
     * (/usr/local/sbin/php-fpm), which rejects `-r` with a usage message and
     * exit 64 — so a subprocess launched this way works from cron and fails from
     * a web request. Everything here is CLI-only today, which is exactly why the
     * bug would sit unnoticed until something called it from public.php.
     * PHP_BINDIR is a compile-time constant, identical across SAPIs.
     */
    public static function php(): string
    {
        $cli = PHP_BINDIR . "/php";

        return is_executable($cli) ? $cli : PHP_BINARY;
    }

    /**
     * Run PHP inside a booted UISP kernel, with any of its services available.
     *
     * This is the general form of console(): where that runs a command UISP
     * happens to ship, this reaches **any** service in its container — the same
     * objects its own controllers use.
     *
     * Two things make it work, both established by experiment:
     *
     * 1. **A separate process.** The child loads UISP's autoloader ONLY, so
     *    `$snippet` cannot use this plugin's classes and must talk to UISP through
     *    `$container`.
     *
     *    An earlier version of this note claimed the two autoloaders *collide* and
     *    that in-process was impossible. **That is not true, and the correction
     *    matters.** Measured against this install, our vendor/ and UISP's share
     *    only 8 leaf packages — we do not ship the framework, just Slim, Twig and
     *    symfony/yaml — and loading both autoloaders then booting the kernel
     *    in-process works: the ORM reads, facades resolve, even UISP's own twig
     *    service constructs.
     *
     *    It is still the wrong default, for a reason worth stating exactly.
     *    Whichever autoloader registers first wins every shared class, so UISP's
     *    code would run against OUR versions of them — and the overlap includes
     *    `psr/http-message` 1.1 vs 2.0, a deliberately breaking major. The path
     *    that happened to work touched none of it. "It booted" is not "it is
     *    safe", and a subprocess costs ~200ms to remove the entire question.
     *
     *    Where that 200ms is unaffordable, in-process is available and should be
     *    treated as an experiment each time, not a pattern.
     *
     * 2. **A dispatched ConsoleCommandEvent.** UISP records an audit context for
     *    every change, and `LogContextDetector` builds it from either a Request or
     *    a console command. A bare kernel boot has neither, so service calls die
     *    with `LogContextDetectorException: Unable to detect log context` — and
     *    they die PART WAY THROUGH. Calling PluginFacade::handleUpdate() without
     *    it swapped the plugin's files, deleted ucrm.json, and *then* threw,
     *    leaving the install broken. Dispatching the event first is what makes
     *    the kernel behave as it does for UISP itself.
     *
     * `$snippet` runs with `$kernel` and `$container` in scope.
     *
     * @return string|null the child's output, or null if it failed
     */
    public static function kernel(string $snippet, string $as = "plugin:provisioner"): ?string
    {
        if (!is_file(self::UCRM_AUTOLOAD)) {
            error_log(sprintf("(ucrm) kernel autoloader not found at %s", self::UCRM_AUTOLOAD));
            return null;
        }

        $bootstrap = <<<'PHP'
            require %s;

            $kernel = new AppKernel("prod", false);
            $kernel->boot();
            $container = $kernel->getContainer();

            // Establish the audit context UISP expects. Without this, services
            // that record changes throw mid-operation.
            $container->get("event_dispatcher")->dispatch(
                new Symfony\Component\Console\Event\ConsoleCommandEvent(
                    new Symfony\Component\Console\Command\Command(%s),
                    new Symfony\Component\Console\Input\ArrayInput([]),
                    new Symfony\Component\Console\Output\NullOutput()
                ),
                Symfony\Component\Console\ConsoleEvents::COMMAND
            );

            %s
            PHP;

        $code = sprintf(
            $bootstrap,
            var_export(self::UCRM_AUTOLOAD, true),
            var_export($as, true),
            $snippet
        );

        exec(sprintf("%s -r %s 2>&1", escapeshellarg(self::php()), escapeshellarg($code)), $out, $exit);

        if ($exit !== 0) {
            error_log(sprintf("(ucrm) kernel call failed (%d): %s", $exit, implode(" | ", array_slice($out, 0, 3))));
            return null;
        }

        return implode("\n", $out);
    }

    /**
     * Call a method on one of UISP's own container services.
     *
     *     use AppBundle\Facade\WebhookFacade;
     *     Server::proxy(WebhookFacade::class, "handleDeleteMultiple", [[7, 9]]);
     *
     * ── WHY THE `use` STATEMENT WORKS ───────────────────────────────────────
     * `WebhookFacade::class` is resolved BY THE COMPILER to the string
     * "AppBundle\Facade\WebhookFacade". It does not autoload, does not require the
     * class to exist, and does not care that this process could never load it. So
     * the import buys editor completion and a static analyser that can check the
     * method name and argument types, while emitting nothing at runtime but a
     * string this hands to the kernel process.
     *
     * Run `bin/ucrm-src.sh` to put UISP's source where an editor can see it. It is
     * gitignored and archive-excluded — author-time only, never shipped.
     *
     * ── WHAT CAN CROSS ──────────────────────────────────────────────────────
     * Arguments are var_export'd into the snippet, so they must be **scalars,
     * arrays or nulls**. An object cannot cross a process boundary this way, which
     * rules out the facade methods taking entities — `handleCreate(WebhookAddress)`
     * has to build its entity on the far side, and that is what kernel() is for.
     * This covers the id/scalar-shaped half of the API, which is most of it.
     *
     * Returns whatever the call echoed, or null if the kernel call failed. A
     * method returning a value rather than printing one needs kernel() and a
     * json_encode — deliberately not guessed at here.
     *
     * `class-string` rather than `string` so a static analyser rejects a typo'd or
     * invented name. It CANNOT check `$method` — that is a plain string, and no
     * amount of annotation makes a dynamic method name checkable against a class
     * the analyser only scanned. Treat the method name as the unverified part.
     *
     * @param class-string $service UISP service id, i.e. `SomeFacade::class`
     * @param mixed[]      $args
     */
    public static function proxy(string $service, string $method, array $args = []): ?string
    {
        foreach ($args as $arg) {
            if (is_object($arg) || is_resource($arg)) {
                error_log(sprintf(
                    "(ucrm) proxy %s::%s refused — arguments must be scalars or arrays",
                    $service,
                    $method
                ));

                return null;
            }
        }

        // Opportunistic typo guard. `$method` is a plain string and no static
        // analyser can check it — but with composer.json's autoload-dev PSR-4 rule
        // the class IS loadable on a dev box, so the mistake can be caught here
        // instead of surfacing as an empty result 200ms later. Inert on an
        // installed instance, where ucrm-src/ does not exist and class_exists()
        // is simply false.
        if (class_exists($service) && !method_exists($service, $method)) {
            error_log(sprintf("(ucrm) proxy %s has no method %s()", $service, $method));

            return null;
        }

        return self::kernel(sprintf(
            '$s = $container->get(%s); $r = $s->%s(...%s); if ($r !== null) { echo is_scalar($r) ? $r : json_encode($r); }',
            var_export($service, true),
            $method,
            var_export(array_values($args), true)
        ));
    }

    /**
     * Ensure `<webroot>/_plugins/<name>/public` points at our `public/` directory.
     *
     * Mirrors `AppBundle\FileManager\PluginDataFileManager::createPublicSymlink()`.
     * UISP writes a small `public.php` shim into the web root, then symlinks
     * `public/` — **but only if that directory already exists at the moment it
     * runs**:
     *
     *     $publicDirPath = …/public;
     *     if (! $this->filesystem->exists($publicDirPath)) { return; }
     *     $this->filesystem->symlink($publicDirPath, …/public);
     *
     * So a plugin that gains a `public/` directory after its initial install ends
     * up with assets on disk that 404 forever, because nginx serves them from the
     * web root and there is nothing there to serve. Installing a ZIP that already
     * contains `public/` avoids this entirely; this exists for the development
     * loop, where files are copied into place rather than installed.
     *
     * Idempotent. Returns false when there is nothing to link or the link is
     * already correct.
     */
    public static function createPublicSymlink(): bool
    {
        $source = Plugin::dir() . "/public";

        if (!is_dir($source)) {
            return false;
        }

        $linkDir = self::PUBLIC_PLUGINS_DIR . "/" . Plugin::name();

        // If UISP has not materialised this plugin at all, it is disabled or not
        // installed — creating the directory ourselves would fake a state UISP
        // does not believe in.
        if (!is_dir($linkDir)) {
            return false;
        }

        $link = $linkDir . "/public";

        if (is_link($link)) {
            if (realpath(readlink($link)) === realpath($source)) {
                return false;   // already correct
            }
            @unlink($link);
        }

        return @symlink($source, $link);
    }

    /**
     * Delete UISP's compiled Twig cache, forcing templates to re-compile.
     *
     * Only needed after editing UISP's own templates — see moveClientServiceWidget()
     * in v2. It does **not** help with plugin metadata changes: the admin/client
     * zone script tags come from a Doctrine result cache, not from Twig.
     */
    public static function clearTwigCache(): bool
    {
        if (!is_dir(self::TWIG_CACHE_DIR)) {
            return false;
        }

        exec("rm -rf " . escapeshellarg(self::TWIG_CACHE_DIR), $out, $code);

        return $code === 0;
    }

    /**
     * Whether UISP currently believes this plugin ships zone JavaScript.
     *
     * `AppBundle\Service\Plugin\PluginCustomJavaScriptLoader` selects plugins
     * where `enabled = TRUE AND has_admin_zone_js = TRUE`, then emits
     * `/crm/_plugins/<name>/public/<file>?v=<plugin version>`.
     *
     * That query is wrapped in a Doctrine **result cache** backed by APCu
     * (`ucrm_cache_adapter: cache.adapter.apcu`), which UISP invalidates from
     * inside its own request when a plugin is installed, enabled or disabled.
     * See invalidateZoneJsCache() for clearing it from here.
     */
    public static function hasZoneJsRegistered(): ?bool
    {
        $pdo = Database::ucrm();

        $stmt = $pdo->prepare(
            'SELECT enabled, has_admin_zone_js, has_client_zone_js
               FROM plugin WHERE name = :name LIMIT 1'
        );
        $stmt->execute(["name" => Plugin::name()]);
        $row = $stmt->fetch();

        if (!$row) {
            return null;
        }

        $wantsAdmin  = is_file(Plugin::dir() . "/public/admin-zone.js");
        $wantsClient = is_file(Plugin::dir() . "/public/client-zone.js");

        return (!$wantsAdmin  || (bool) $row["has_admin_zone_js"])
            && (!$wantsClient || (bool) $row["has_client_zone_js"]);
    }

    /**
     * Clear UISP's cached zone-JS lookup so a flag change takes effect at once.
     *
     * The cache is APCu, and APCu is **per-SAPI**: hooks run under CLI, while the
     * cache that matters belongs to php-fpm. Deleting the key from a hook does
     * nothing to the copy the web requests read — which is why changing
     * `has_admin_zone_js` in the database alone appears to work and does not.
     *
     * The way through is to run the deletion *inside* php-fpm. The plugin already
     * has a php-fpm entry point — its own `public.php` — so this calls the
     * loopback-only `/_internal/invalidate-zone-js-cache` route, which deletes
     * UISP's `PluginCustomJavaScriptLoader` entries and lets UISP rebuild them
     * from current database state on the next request.
     *
     * Loopback, so no certificate or public hostname is involved. Returns the
     * number of entries deleted, or null if the call could not be made.
     */
    public static function invalidateZoneJsCache(): ?int
    {
        return self::invalidateCache("PluginCustomJavaScriptLoader");
    }

    /**
     * Make UISP re-read `manifest.json`'s `menu` block.
     *
     * `PluginsMenuItemsLoader` caches the assembled menu in APCu under one key
     * and rebuilds it from every enabled plugin's manifest on a miss. UISP
     * invalidates it from a plugin transaction (see
     * InvalidatePluginMenuItemsCacheSubscriber) — so editing a manifest in place,
     * which is the whole dev loop here, leaves the sidebar showing the old menu
     * with nothing to indicate why.
     *
     * Same per-SAPI trap as the zone JS: clearing it from a CLI hook cannot touch
     * the segment php-fpm reads.
     */
    public static function invalidateMenuCache(): ?int
    {
        return self::invalidateCache("PluginsMenuItemsLoader");
    }

    /**
     * Delete UISP's APCu entries whose key contains $marker, from inside php-fpm.
     *
     * @param string $marker the loader class name UISP namespaces the cache with
     */
    private static function invalidateCache(string $marker): ?int
    {
        $url = Plugin::localUrl("/_internal/invalidate-cache")
             . "&cache=" . rawurlencode($marker);

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => "",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
        ]);

        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code !== 200 || !is_string($body)) {
            return null;
        }

        $data = json_decode($body, true);

        return is_array($data) && isset($data["deleted"]) ? (int) $data["deleted"] : null;
    }
}
