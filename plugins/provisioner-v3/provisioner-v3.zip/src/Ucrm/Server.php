<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ucrm;

use Archous\Provisioner\Plugin;

/**
 * Operations against the UISP installation itself, for the cases where UISP does
 * something on our behalf that we sometimes need to reproduce or repair.
 *
 * Everything here reaches outside the plugin directory and is therefore
 * inherently fragile across UISP upgrades. Each method documents what it is
 * mirroring, so a behaviour change upstream is traceable rather than mysterious.
 * Prefer letting UISP do its own work — reach for this only when it has not.
 */
final class Server
{
    /** Where UISP materialises the publicly-served view of each enabled plugin. */
    private const PUBLIC_PLUGINS_DIR = "/usr/src/ucrm/web/_plugins";

    /** UISP's own Symfony console — the same binary `plugins.sh` drives. */
    private const CONSOLE = "/usr/src/ucrm/app/console";

    /** Compiled Twig templates. Removing this forces a re-compile. */
    private const TWIG_CACHE_DIR = "/usr/src/ucrm/app/cache/prod/twig";

    /**
     * Run one of UISP's own console commands.
     *
     * **Prefer this over reimplementing anything.** UISP ships commands that do
     * the housekeeping a self-update needs, and calling them means a change to
     * UISP's internals is picked up for free rather than silently diverging from
     * a copy of its logic:
     *
     *   crm:plugin:update-database-information   version + has_*_zone_js, from manifests
     *   crm:plugin:symlink                       regenerate web-root public/ symlinks
     *   crm:plugin:ucrm-config                   regenerate ucrm.json for every plugin
     *
     * Verified against a deliberately broken install: with ucrm.json deleted, the
     * symlink removed and the database showing version 0.0.0 with zone JS off,
     * those three restored every one of them.
     *
     * ⚠️ What they CANNOT do is invalidate the zone-JS cache the web sees. They
     * run under the CLI SAPI, and APCu segments are per-SAPI — `apc.enable_cli`
     * is On here and a CLI process still reports 0 entries while php-fpm holds
     * hundreds. Use invalidateZoneJsCache() for that; it goes through public.php
     * precisely because that runs in the right process.
     *
     * Returns false if the console is missing or the command fails; callers
     * should treat that as "fall back", not "give up".
     */
    public static function console(string $command, array $args = []): bool
    {
        if (!is_file(self::CONSOLE)) {
            error_log(sprintf("(ucrm) console not found at %s", self::CONSOLE));
            return false;
        }

        $parts = [escapeshellarg(PHP_BINARY), escapeshellarg(self::CONSOLE), escapeshellarg($command)];

        foreach ($args as $arg) {
            $parts[] = escapeshellarg((string) $arg);
        }

        $parts[] = "--env=prod";
        $parts[] = "--no-interaction";

        exec(implode(" ", $parts) . " 2>&1", $out, $code);

        if ($code !== 0) {
            error_log(sprintf("(ucrm) %s exited %d: %s", $command, $code, implode(" | ", array_slice($out, 0, 3))));
            return false;
        }

        return true;
    }

    /** UISP's Symfony autoloader — boots its kernel, not ours. */
    private const UCRM_AUTOLOAD = "/usr/src/ucrm/app/autoload.php";

    /**
     * Run PHP inside a booted UISP kernel, with any of its services available.
     *
     * This is the general form of console(): where that runs a command UISP
     * happens to ship, this reaches **any** service in its container — the same
     * objects its own controllers use.
     *
     * Two things make it work, both established by experiment:
     *
     * 1. **A separate process.** Our vendor/ carries Symfony 6.4 components while
     *    UISP runs Symfony 5.4. Loading both autoloaders in one process collides.
     *    The child loads UISP's autoloader ONLY — `$snippet` therefore cannot use
     *    this plugin's classes, and must talk to UISP through `$container`.
     *
     * 2. **A dispatched ConsoleCommandEvent.** UISP records an audit context for
     *    every change, and `LogContextDetector` builds it from either a Request or
     *    a console command. A bare kernel boot has neither, so service calls die
     *    with `LogContextDetectorException: Unable to detect log context` — and
     *    they die PART WAY THROUGH. Calling PluginFacade::handleUpdate() without
     *    it swapped the plugin's files, deleted ucrm.json, and *then* threw,
     *    leaving the install broken. Dispatching the event first is what makes
     *    the kernel behave as it does for UISP itself.
     *
     * `$snippet` runs with `$kernel` and `$container` in scope.
     *
     * @return string|null the child's output, or null if it failed
     */
    public static function kernel(string $snippet, string $as = "plugin:provisioner"): ?string
    {
        if (!is_file(self::UCRM_AUTOLOAD)) {
            error_log(sprintf("(ucrm) kernel autoloader not found at %s", self::UCRM_AUTOLOAD));
            return null;
        }

        $bootstrap = <<<'PHP'
            require %s;

            $kernel = new AppKernel("prod", false);
            $kernel->boot();
            $container = $kernel->getContainer();

            // Establish the audit context UISP expects. Without this, services
            // that record changes throw mid-operation.
            $container->get("event_dispatcher")->dispatch(
                new Symfony\Component\Console\Event\ConsoleCommandEvent(
                    new Symfony\Component\Console\Command\Command(%s),
                    new Symfony\Component\Console\Input\ArrayInput([]),
                    new Symfony\Component\Console\Output\NullOutput()
                ),
                Symfony\Component\Console\ConsoleEvents::COMMAND
            );

            %s
            PHP;

        $code = sprintf(
            $bootstrap,
            var_export(self::UCRM_AUTOLOAD, true),
            var_export($as, true),
            $snippet
        );

        exec(sprintf("%s -r %s 2>&1", escapeshellarg(PHP_BINARY), escapeshellarg($code)), $out, $exit);

        if ($exit !== 0) {
            error_log(sprintf("(ucrm) kernel call failed (%d): %s", $exit, implode(" | ", array_slice($out, 0, 3))));
            return null;
        }

        return implode("\n", $out);
    }

    /**
     * Ensure `<webroot>/_plugins/<name>/public` points at our `public/` directory.
     *
     * Mirrors `AppBundle\FileManager\PluginDataFileManager::createPublicSymlink()`.
     * UISP writes a small `public.php` shim into the web root, then symlinks
     * `public/` — **but only if that directory already exists at the moment it
     * runs**:
     *
     *     $publicDirPath = …/public;
     *     if (! $this->filesystem->exists($publicDirPath)) { return; }
     *     $this->filesystem->symlink($publicDirPath, …/public);
     *
     * So a plugin that gains a `public/` directory after its initial install ends
     * up with assets on disk that 404 forever, because nginx serves them from the
     * web root and there is nothing there to serve. Installing a ZIP that already
     * contains `public/` avoids this entirely; this exists for the development
     * loop, where files are copied into place rather than installed.
     *
     * Idempotent. Returns false when there is nothing to link or the link is
     * already correct.
     */
    public static function createPublicSymlink(): bool
    {
        $source = Plugin::dir() . "/public";

        if (!is_dir($source)) {
            return false;
        }

        $linkDir = self::PUBLIC_PLUGINS_DIR . "/" . Plugin::name();

        // If UISP has not materialised this plugin at all, it is disabled or not
        // installed — creating the directory ourselves would fake a state UISP
        // does not believe in.
        if (!is_dir($linkDir)) {
            return false;
        }

        $link = $linkDir . "/public";

        if (is_link($link)) {
            if (realpath(readlink($link)) === realpath($source)) {
                return false;   // already correct
            }
            @unlink($link);
        }

        return @symlink($source, $link);
    }

    /**
     * Delete UISP's compiled Twig cache, forcing templates to re-compile.
     *
     * Only needed after editing UISP's own templates — see moveClientServiceWidget()
     * in v2. It does **not** help with plugin metadata changes: the admin/client
     * zone script tags come from a Doctrine result cache, not from Twig.
     */
    public static function clearTwigCache(): bool
    {
        if (!is_dir(self::TWIG_CACHE_DIR)) {
            return false;
        }

        exec("rm -rf " . escapeshellarg(self::TWIG_CACHE_DIR), $out, $code);

        return $code === 0;
    }

    /**
     * Whether UISP currently believes this plugin ships zone JavaScript.
     *
     * `AppBundle\Service\Plugin\PluginCustomJavaScriptLoader` selects plugins
     * where `enabled = TRUE AND has_admin_zone_js = TRUE`, then emits
     * `/crm/_plugins/<name>/public/<file>?v=<plugin version>`.
     *
     * That query is wrapped in a Doctrine **result cache** backed by APCu
     * (`ucrm_cache_adapter: cache.adapter.apcu`), which UISP invalidates from
     * inside its own request when a plugin is installed, enabled or disabled.
     * See invalidateZoneJsCache() for clearing it from here.
     */
    public static function hasZoneJsRegistered(): ?bool
    {
        $pdo = Database::ucrm();

        $stmt = $pdo->prepare(
            'SELECT enabled, has_admin_zone_js, has_client_zone_js
               FROM plugin WHERE name = :name LIMIT 1'
        );
        $stmt->execute(["name" => Plugin::name()]);
        $row = $stmt->fetch();

        if (!$row) {
            return null;
        }

        $wantsAdmin  = is_file(Plugin::dir() . "/public/admin-zone.js");
        $wantsClient = is_file(Plugin::dir() . "/public/client-zone.js");

        return (!$wantsAdmin  || (bool) $row["has_admin_zone_js"])
            && (!$wantsClient || (bool) $row["has_client_zone_js"]);
    }

    /**
     * Clear UISP's cached zone-JS lookup so a flag change takes effect at once.
     *
     * The cache is APCu, and APCu is **per-SAPI**: hooks run under CLI, while the
     * cache that matters belongs to php-fpm. Deleting the key from a hook does
     * nothing to the copy the web requests read — which is why changing
     * `has_admin_zone_js` in the database alone appears to work and does not.
     *
     * The way through is to run the deletion *inside* php-fpm. The plugin already
     * has a php-fpm entry point — its own `public.php` — so this calls the
     * loopback-only `/_internal/invalidate-zone-js-cache` route, which deletes
     * UISP's `PluginCustomJavaScriptLoader` entries and lets UISP rebuild them
     * from current database state on the next request.
     *
     * Loopback, so no certificate or public hostname is involved. Returns the
     * number of entries deleted, or null if the call could not be made.
     */
    public static function invalidateZoneJsCache(): ?int
    {
        $url = Plugin::localUrl("/_internal/invalidate-zone-js-cache");

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => "",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
        ]);

        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code !== 200 || !is_string($body)) {
            return null;
        }

        $data = json_decode($body, true);

        return is_array($data) && isset($data["deleted"]) ? (int) $data["deleted"] : null;
    }
}
