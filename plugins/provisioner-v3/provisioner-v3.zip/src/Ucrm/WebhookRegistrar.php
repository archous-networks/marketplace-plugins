<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ucrm;

use Archous\Provisioner\Plugin;
use PDO;

/**
 * Registers and removes this plugin's UISP webhook endpoint.
 *
 * UISP exposes NO supported API for webhook endpoint management — confirmed
 * twice, independently: the container's route cache has only admin-UI routes
 * (`webhook_endpoint_new` / `_edit` / `_delete`), and the published API blueprint's
 * entire `Webhook Events` group is a single read endpoint,
 * `GET /webhook-events/{uuid}`. Writing to `webhook_address` directly is
 * therefore the only programmatic route, not a shortcut. See the `ucrm-api` skill.
 */
final class WebhookRegistrar
{
    /**
     * Service lifecycle events this plugin subscribes to.
     *
     * `service.edit` is deliberately EXCLUDED — v2 excluded it too. It fires on
     * any field change, so subscribing would turn routine edits into provisioning
     * traffic. Add it only with a debounce story.
     */
    public const EVENTS = [
        "service.activate",
        "service.add",
        "service.archive",
        "service.end",
        "service.postpone",
        "service.suspend",
        "service.suspend_cancel",
    ];

    public const ROUTE = "/webhook";

    /**
     * Create or reactivate the webhook endpoint. Idempotent: safe to run on every
     * install, and safe to run twice.
     *
     * @return array{action:string,url:string,events:int}
     */
    public static function install(): array
    {
        $pdo = Database::ucrm();
        $url = Plugin::localUrl(self::ROUTE);

        $pdo->beginTransaction();

        try {
            $find = $pdo->prepare('SELECT id FROM webhook_address WHERE url = :url LIMIT 1');
            $find->execute(["url" => $url]);
            $id = $find->fetchColumn();

            if ($id === false) {
                // verify_ssl_certificate is off because the URL is plain-HTTP
                // loopback inside the container — there is no certificate to verify.
                $insert = $pdo->prepare(
                    'INSERT INTO webhook_address (url, is_active, any_event, verify_ssl_certificate)
                     VALUES (:url, true, false, false)
                     RETURNING id'
                );
                $insert->execute(["url" => $url]);
                $id = (int) $insert->fetchColumn();
                $action = "created";
            } else {
                // Reactivate rather than duplicate: UISP soft-deletes via deleted_at.
                $id = (int) $id;
                $pdo->prepare(
                    'UPDATE webhook_address
                        SET deleted_at = NULL, is_active = true, any_event = false,
                            verify_ssl_certificate = false
                      WHERE id = :id'
                )->execute(["id" => $id]);
                $action = "reactivated";
            }

            $events = self::syncEvents($pdo, $id);

            $pdo->commit();

            return ["action" => $action, "url" => $url, "events" => $events];
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /**
     * Remove the webhook endpoint entirely. Idempotent.
     *
     * A hard delete, not a soft one: the plugin is being removed, so leaving a
     * soft-deleted row behind would have UISP retain an endpoint pointing at a
     * path that no longer serves anything.
     *
     * @return array{removed:bool,url:string}
     */
    public static function remove(): array
    {
        $pdo = Database::ucrm();
        $url = Plugin::localUrl(self::ROUTE);

        $pdo->beginTransaction();

        try {
            $find = $pdo->prepare('SELECT id FROM webhook_address WHERE url = :url LIMIT 1');
            $find->execute(["url" => $url]);
            $id = $find->fetchColumn();

            if ($id === false) {
                $pdo->commit();
                return ["removed" => false, "url" => $url];
            }

            $id = (int) $id;

            $pdo->prepare('DELETE FROM webhook_address_webhook_event_type WHERE webhook_address_id = :id')
                ->execute(["id" => $id]);

            $pdo->prepare('DELETE FROM webhook_address WHERE id = :id')
                ->execute(["id" => $id]);

            $pdo->commit();

            return ["removed" => true, "url" => $url];
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /**
     * Point the endpoint at exactly self::EVENTS — adding what's missing and
     * dropping anything else, so re-running converges rather than accumulating.
     *
     * Event type IDs are resolved BY NAME. v2 hardcoded the integers (19 =
     * service.activate, 20 = service.add, ...); those are undocumented internals
     * that a UISP upgrade can renumber, and nothing would fail loudly. Looking
     * them up costs one query and removes the whole class of problem.
     */
    private static function syncEvents(PDO $pdo, int $addressId): int
    {
        $placeholders = implode(",", array_fill(0, count(self::EVENTS), "?"));

        $lookup = $pdo->prepare(
            "SELECT id, event_name FROM webhook_event_type WHERE event_name IN ($placeholders)"
        );
        $lookup->execute(self::EVENTS);
        $rows = $lookup->fetchAll();

        $ids = array_map(static fn(array $r): int => (int) $r["id"], $rows);

        // A UISP upgrade renaming or dropping an event should be loud, not silent.
        if (count($ids) !== count(self::EVENTS)) {
            $found   = array_map(static fn(array $r): string => (string) $r["event_name"], $rows);
            $missing = array_diff(self::EVENTS, $found);
            throw new \RuntimeException(
                "unknown webhook event(s) in this UISP version: " . implode(", ", $missing)
            );
        }

        $pdo->prepare('DELETE FROM webhook_address_webhook_event_type WHERE webhook_address_id = :id')
            ->execute(["id" => $addressId]);

        $link = $pdo->prepare(
            'INSERT INTO webhook_address_webhook_event_type (webhook_address_id, webhook_event_type_id)
             VALUES (:address, :event)'
        );

        foreach ($ids as $eventId) {
            $link->execute(["address" => $addressId, "event" => $eventId]);
        }

        return count($ids);
    }
}
