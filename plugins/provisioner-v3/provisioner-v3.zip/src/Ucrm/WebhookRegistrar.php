<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ucrm;

use AppBundle\Entity\WebhookAddress;
use AppBundle\Entity\WebhookEventType;
use AppBundle\Facade\WebhookFacade;
use Archous\Provisioner\Plugin;
use RuntimeException;

/**
 * Registers and removes this plugin's UISP webhook endpoint.
 *
 * UISP exposes NO supported API for webhook endpoint management — confirmed
 * twice, independently: the container's route cache has only admin-UI routes
 * (`webhook_endpoint_new` / `_edit` / `_delete`), and the published API blueprint's
 * entire `Webhook Events` group is a single read endpoint,
 * `GET /webhook-events/{uuid}`. So this has to reach into UISP itself. See the
 * `ucrm-api` skill.
 *
 * ── IT GOES THROUGH UISP'S OWN FACADE, NOT RAW SQL ──────────────────────────
 * This used to write `webhook_address` and its join table with PDO. Going through
 * `WebhookFacade` and Doctrine instead buys three things, in ascending order of
 * how much they matter:
 *
 * 1. **The join table stops being our problem.** Event types are a Doctrine
 *    collection; adding to it writes `webhook_address_webhook_event_type` for us.
 *    That deleted a whole method of DELETE-then-INSERT.
 *
 * 2. **`databaseTableSizeChecker->invalidate()` fires**, which the SQL version
 *    skipped entirely because it had no idea it was expected.
 *
 * 3. **Removal is a SOFT delete, which is what UISP means by removal.**
 *    `webhook_event_request.webhook_address_id` is a foreign key with `NO ACTION`,
 *    so a hard `DELETE FROM webhook_address` is refused by Postgres the moment
 *    that endpoint has any delivery-log rows. The old code did exactly that, and
 *    `hook_remove.php` catches Throwable — so an uninstall would have logged
 *    "cleanup FAILED" and left an ACTIVE webhook pointing at a URL that no longer
 *    serves anything, with UISP still delivering to it. Latent rather than firing
 *    (that table is empty on this instance), but latent on Ubiquiti's retention
 *    behaviour rather than on anything we control.
 *
 * The cost is ~200ms per call, because `Server::kernel()` boots UISP's kernel in a
 * child process. Everything here runs from `hook_install` / `hook_update` /
 * `hook_remove`, once, so it does not matter. It would matter in a request path.
 *
 * ⚠️ These are UISP's internals, no more a public API than the table was. The
 * argument is not that they are stable — it is that they **fail loudly**: a
 * renamed class or method throws, where a renumbered `webhook_event_type_id`
 * silently subscribed us to the wrong events.
 *
 * The `use` statements above are author-time only. `::class` is resolved by the
 * compiler to a string and never autoloads — run `composer sync:src` and they
 * resolve in the editor and in PHPStan. See *Reaching UISP's own code* in
 * CLAUDE.md.
 */
final class WebhookRegistrar
{
    /**
     * Service lifecycle events this plugin subscribes to.
     *
     * `service.edit` is deliberately EXCLUDED — v2 excluded it too. It fires on
     * any field change, so subscribing would turn routine edits into provisioning
     * traffic. Add it only with a debounce story.
     */
    public const EVENTS = [
        "service.activate",
        "service.add",
        "service.archive",
        "service.end",
        "service.postpone",
        "service.suspend",
        "service.suspend_cancel",
    ];

    public const ROUTE = "/webhook";

    /**
     * Create or reactivate the webhook endpoint. Idempotent: safe on every
     * install, and safe to run twice.
     *
     * Converges rather than accumulates — the subscription is set to exactly
     * self::EVENTS, so a re-run after the list changes adds and drops as needed.
     *
     * @return array{action:string,url:string,events:int}
     */
    public static function install(): array
    {
        $url = Plugin::localUrl(self::ROUTE);

        $result = self::run(<<<'SNIPPET'
            $url  = {{URL}};
            $want = {{EVENTS}};

            $em     = $container->get("doctrine.orm.entity_manager");
            $facade = $container->get({{FACADE}});

            $types = $em->getRepository({{EVENT_TYPE}})->findBy(["eventName" => $want]);

            // A UISP upgrade renaming or dropping an event should be loud, not
            // silent — subscribing to six of seven events would otherwise look
            // exactly like success.
            if (count($types) !== count($want)) {
                $found = array_map(static fn($t) => $t->getEventName(), $types);
                throw new RuntimeException(
                    "unknown webhook event(s) in this UISP version: "
                    . implode(", ", array_diff($want, $found))
                );
            }

            // Deliberately NOT filtered on deletedAt: a soft-deleted row still
            // occupies the URL, so ignoring it would create a duplicate endpoint
            // rather than revive the one already there.
            $w = $em->getRepository({{ADDRESS}})->findOneBy(["url" => $url]);

            $action = $w === null ? "created" : "reactivated";

            if ($w === null) {
                $w = new AppBundle\Entity\WebhookAddress();
                $w->setUrl($url);
            }

            $w->setDeletedAt(null);
            $w->setIsActive(true);
            $w->setAnyEvent(false);
            // No certificate to verify: the URL is plain-HTTP loopback inside the
            // container, so UISP never leaves the host.
            $w->setVerifySslCertificate(false);

            // Converge the collection: drop what is no longer wanted, add what is
            // missing. Doctrine writes the join table from this.
            foreach ($w->getWebhookEventTypes() as $have) {
                if (!in_array($have->getEventName(), $want, true)) {
                    $w->removeWebhookEventType($have);
                }
            }

            foreach ($types as $t) {
                if (!$w->getWebhookEventTypes()->contains($t)) {
                    $w->addWebhookEventType($t);
                }
            }

            $action === "created" ? $facade->handleCreate($w) : $facade->handleUpdate($w);

            echo json_encode([
                "action" => $action,
                "url"    => $url,
                "events" => count($w->getWebhookEventTypes()),
            ]);
            SNIPPET,
            ["URL" => $url, "EVENTS" => self::EVENTS]
        );

        return [
            "action" => (string) ($result["action"] ?? "unknown"),
            "url"    => (string) ($result["url"] ?? $url),
            "events" => (int) ($result["events"] ?? 0),
        ];
    }

    /**
     * Remove the webhook endpoint. Idempotent.
     *
     * A SOFT delete, via the facade — see the class docblock. UISP retains the row
     * so its delivery log keeps referring to something, and stops delivering
     * because the endpoint is no longer active.
     *
     * @return array{removed:bool,url:string}
     */
    public static function remove(): array
    {
        $url = Plugin::localUrl(self::ROUTE);

        $result = self::run(<<<'SNIPPET'
            $url = {{URL}};

            $em     = $container->get("doctrine.orm.entity_manager");
            $facade = $container->get({{FACADE}});

            $w = $em->getRepository({{ADDRESS}})->findOneBy(["url" => $url]);

            // Already gone, or already soft-deleted: either way there is nothing
            // to do and this is not a failure.
            if ($w === null || $w->getDeletedAt() !== null) {
                echo json_encode(["removed" => false, "url" => $url]);
                return;
            }

            $facade->handleDelete($w);

            echo json_encode(["removed" => true, "url" => $url]);
            SNIPPET,
            ["URL" => $url]
        );

        return [
            "removed" => (bool) ($result["removed"] ?? false),
            "url"     => (string) ($result["url"] ?? $url),
        ];
    }

    /**
     * Run a snippet in UISP's kernel and decode its JSON.
     *
     * Placeholders are NAMED (`{{URL}}`, `{{ADDRESS}}` …) rather than positional.
     * With sprintf, install() taking five arguments and remove() three meant one
     * shared helper silently substituted the wrong class into the shorter of them
     * — a bug that type-checks, runs, and queries the wrong repository.
     *
     * The class tokens are always available, so a snippet names only what it uses.
     * Values are var_export'd, and the snippets are NOWDOCs precisely so `$em`,
     * `$w` and friends survive to the child process instead of being expanded
     * here.
     *
     * Wrapped so a throw inside the kernel comes back as a message rather than a
     * non-zero exit with the reason buried in stderr.
     *
     * @param array<string,mixed> $tokens
     * @return array<string,mixed>
     */
    private static function run(string $snippet, array $tokens = []): array
    {
        $tokens += [
            "FACADE"     => WebhookFacade::class,
            "ADDRESS"    => WebhookAddress::class,
            "EVENT_TYPE" => WebhookEventType::class,
        ];

        $filled = $snippet;

        foreach ($tokens as $name => $value) {
            $filled = str_replace("{{" . $name . "}}", var_export($value, true), $filled);
        }

        if (preg_match('/\{\{([A-Z_]+)\}\}/', $filled, $m) === 1) {
            throw new RuntimeException("unfilled placeholder in kernel snippet: " . $m[1]);
        }

        $wrapped = sprintf(
            '(function () use ($container) { try { %s } catch (\Throwable $e) {
                 echo json_encode(["error" => get_class($e) . ": " . $e->getMessage()]);
             } })();',
            $filled
        );

        $out = Server::kernel($wrapped, "plugin:provisioner:webhook");

        if ($out === null) {
            throw new RuntimeException("could not reach UISP's kernel");
        }

        $data = json_decode(trim($out), true);

        if (!is_array($data)) {
            throw new RuntimeException("unexpected response from UISP's kernel: " . trim($out));
        }

        if (isset($data["error"])) {
            throw new RuntimeException((string) $data["error"]);
        }

        return $data;
    }
}
