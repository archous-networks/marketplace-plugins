<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Middleware;

use Archous\Provisioner\Ucrm\Auth;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface as Handler;
use Slim\Psr7\Response as Psr7Response;

/**
 * Admin-only, on every page route.
 *
 * ── WHY THIS IS NOT OPTIONAL ────────────────────────────────────────────────
 * UISP serves `public.php` with no authentication of its own, and it is reachable
 * from outside regardless of whether anyone opens a plugin page. The chrome that
 * frames these pages is gated; the pages are not. Without this, anyone who can
 * reach the URL could read and rewrite this instance's provisioning configuration.
 *
 * Applied as a GROUP middleware rather than globally, because three routes must
 * stay open and each for a different reason:
 *
 *   /webhook                          UISP delivers server-to-server with NO
 *                                     session — an authenticated webhook route
 *                                     would simply never fire.
 *   /api/ping                         liveness. Deliberately says nothing about
 *                                     configuration or credentials.
 *   /_internal/invalidate-cache       loopback-only, checked in the handler.
 *
 * ── WRITES NEED MORE ────────────────────────────────────────────────────────
 * A GET needs an authenticated admin. Anything that changes state needs, in
 * addition:
 *
 *  - `edit` on `system/plugins`, so a view-only admin can read the configuration
 *    without altering it; and
 *  - a valid CSRF token, because cookies alone would let a hostile page use a
 *    logged-in admin's session to rewrite this instance's configuration. See
 *    Ucrm\Auth::token() for why the marketplace plugin's custom-header approach
 *    cannot be reused here.
 *
 * A refusal is deliberately plain and identical in shape for every cause: it does
 * not distinguish "not logged in" from "wrong permission" from "bad token", since
 * that difference is only useful to someone probing.
 */
final class RequireAdminMiddleware implements MiddlewareInterface
{
    private const SAFE = ["GET", "HEAD", "OPTIONS"];

    public function process(Request $request, Handler $handler): Response
    {
        $user = Auth::admin();

        if ($user === null) {
            return self::deny($request, "not an authenticated admin");
        }

        if (!in_array($request->getMethod(), self::SAFE, true)) {
            if (!Auth::canEdit()) {
                return self::deny($request, sprintf(
                    "%s lacks edit on system/plugins",
                    (string) ($user["username"] ?? "?")
                ));
            }

            $body = (array) $request->getParsedBody();

            if (!Auth::validToken(is_scalar($body["_token"] ?? null) ? (string) $body["_token"] : null)) {
                return self::deny($request, sprintf(
                    "bad or missing CSRF token from %s",
                    (string) ($user["username"] ?? "?")
                ));
            }
        }

        // Downstream can read it without asking UISP again — Auth caches per
        // request, but passing it makes the dependency visible.
        return $handler->handle($request->withAttribute("admin", $user));
    }

    private static function deny(Request $request, string $why): Response
    {
        // Logged with the route so a genuine misconfiguration is diagnosable,
        // without telling the caller which check failed.
        error_log(sprintf(
            "(auth) denied %s %s — %s",
            $request->getMethod(),
            $request->getUri()->getPath(),
            $why
        ));

        $response = new Psr7Response();
        $response->getBody()->write(
            "<!DOCTYPE html><meta charset=\"utf-8\">"
            . "<title>Forbidden</title>"
            . "<p style=\"font:14px/1.5 sans-serif;padding:2rem\">"
            . "You need to be signed in to UISP as an administrator with access to plugins."
            . "</p>"
        );

        return $response->withStatus(403)->withHeader("Content-Type", "text/html; charset=utf-8");
    }
}
