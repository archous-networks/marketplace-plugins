<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;

/**
 * Translates UISP's query-string plugin access into a normal request path, so
 * Slim's routing works unmodified.
 *
 * UISP only ever serves `public.php`, and everything a caller wants to address
 * has to ride in the query string. Two forms are accepted:
 *
 *   public.php?/api/ping          bare key starting with "/", empty value
 *   public.php?route=/api/ping    explicit `route` parameter
 *
 * Either becomes the request path `/api/ping`. Every other query parameter is
 * preserved, so `public.php?route=/changelog&q=foo` still yields `q=foo`.
 *
 * Add this AFTER `addRoutingMiddleware()` in the Slim pipeline: middleware runs
 * last-added-first, so the rewrite must be registered later in order to execute
 * *before* routing resolves.
 */
class QueryRoutingMiddleware implements MiddlewareInterface
{
    /**
     * @param string $fallback Path used when no route is present in the query string.
     * @param array<string,string> $rewrites Ordered `preg_replace` pairs applied to the
     *                                       resolved route, e.g. ['#^/old#' => '/new'].
     */
    public function __construct(
        protected string $fallback = "/",
        protected array $rewrites = []
    ) {
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        $route = $this->fallback;
        $query = [];

        foreach ($request->getQueryParams() as $key => $value) {
            // `?/api/ping` — the path arrives as a valueless parameter key.
            if (is_string($key) && str_starts_with($key, "/") && $value === "") {
                $route = $key;
                continue;
            }

            // `?route=/api/ping`
            if ($key === "route" && is_string($value) && str_starts_with($value, "/")) {
                $route = $value;
                continue;
            }

            $query[$key] = $value;
        }

        foreach ($this->rewrites as $from => $to) {
            $route = preg_replace($from, $to, $route) ?? $route;
        }

        // PSR-7: withQuery() takes the query WITHOUT a leading "?". Some Uri
        // implementations strip one defensively; relying on that is not portable.
        $uri = $request->getUri()
            ->withPath($route)
            ->withQuery($query ? http_build_query($query) : "");

        return $handler->handle(
            $request->withUri($uri)->withQueryParams($query)
        );
    }
}
