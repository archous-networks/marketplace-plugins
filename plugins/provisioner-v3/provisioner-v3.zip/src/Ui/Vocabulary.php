<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ui;

/**
 * The words and closed sets the pages render.
 *
 * Ported from v2's `settings.json`, which sat at the repo root and was read at
 * request time. Kept as constants here because nothing writes them and a file
 * read per page load bought nothing.
 *
 * ── WHY THE LABEL IS CONFIGURABLE ───────────────────────────────────────────
 * v2 called this concept a "site" everywhere in its code and displayed it as
 * whatever `site_text` said — the client's term is "Broadcast Domain". v3 keeps
 * the indirection but flips the default: the code says `domain`, so the term the
 * operator reads and the term the code uses agree out of the box.
 *
 * That also sidesteps a collision that would have arrived on its own. Nautobot
 * has its own `Site`, and it is NOT this — reusing the word would have made
 * "which site?" ambiguous in exactly the layer that has to talk to both.
 *
 * ── THESE ARE VOCABULARY, NOT LOGIC ─────────────────────────────────────────
 * A list of device types a dropdown can offer is not proprietary, so it does not
 * violate the public-artifact rule (see CLAUDE.md). But it is also not obviously
 * ours to own long-term: once Nautobot is the SoT these become a query, not a
 * constant. Treat this file as scaffolding that shrinks.
 */
final class Vocabulary
{
    /** What the operator calls a broadcast domain, singular and plural. */
    public const DOMAIN       = "Broadcast Domain";
    public const DOMAIN_PLURAL = "Broadcast Domains";

    /** @var array<string,string> */
    public const BNG_DEVICE_TYPES = [
        "edge_os"    => "EdgeOS",
        "router_os"  => "RouterOS",
        "netelastic" => "netElastic",
    ];

    /** @var array<string,string> */
    public const RADIUS_SERVER_TYPES = [
        "freeradius" => "FreeRADIUS",
        "mikrotik"   => "MikroTik Userman",
    ];

    /** @var array<string,string> */
    public const MANAGED_ROUTER_TYPES = [
        "tplink" => "TP-Link",
        "eero"   => "Eero",
    ];

    /** @var array<string,string> */
    public const AUTHENTICATION_MODES = [
        "bng_device"    => "BNG Device",
        "radius_server" => "RADIUS Server",
    ];

    /** @var array<string,string> */
    public const AUTHENTICATION_TYPES = [
        "mac_address"       => "MAC Address",
        "username_password" => "Username / Password",
    ];

    /** @return array<int,array{id:string,name:string}> for rendering a <select> */
    public static function choices(array $map): array
    {
        $out = [];

        foreach ($map as $id => $name) {
            $out[] = ["id" => (string) $id, "name" => (string) $name];
        }

        return $out;
    }
}
