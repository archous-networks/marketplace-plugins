<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ui;

use SpaethTech\Ucrm\Auth;
use Psr\Http\Message\ServerRequestInterface as Request;

/**
 * What every page template needs, and the two URL helpers it builds links with.
 *
 * ── WHY LINKS NEED A HELPER ─────────────────────────────────────────────────
 * UISP serves a plugin from ONE filename and routes with a query string, so a
 * page's own URL is `.../public.php?route=/domains`, not `/domains`. A bare href
 * would leave the plugin entirely. Templates call `route()` and `asset()` rather
 * than hardcoding that shape, so the day it changes it changes here.
 *
 * The base is read from the REQUEST rather than from ucrm.json's
 * `pluginPublicUrl`, which is the public hostname — following it would bounce a
 * loopback or reverse-proxied visitor out to the internet and back.
 */
final class Pages
{
    /**
     * @return array<string,mixed> globals for the layout
     *
     * No navigation is built here. Each page is an independent
     * `manifest.menu` entry, so UISP's own sidebar lists them and marks the
     * current one — see the note at the top of views/layout.html.twig.
     */
    public static function context(Request $request, string $title): array
    {
        return [
            "title"                => $title,
            // Every state-changing request carries this. See Ucrm\Auth::token().
            "csrf"                 => Auth::token(),
            "can_edit"             => Auth::canEdit(),
            "domain_label"         => Vocabulary::DOMAIN,
            "domain_label_plural"  => Vocabulary::DOMAIN_PLURAL,
            "authentication_modes" => Vocabulary::AUTHENTICATION_MODES,
            "authentication_types" => Vocabulary::AUTHENTICATION_TYPES,
            "bng_device_types"     => Vocabulary::choices(Vocabulary::BNG_DEVICE_TYPES),
            "radius_server_types"  => Vocabulary::choices(Vocabulary::RADIUS_SERVER_TYPES),
            "managed_router_types" => Vocabulary::choices(Vocabulary::MANAGED_ROUTER_TYPES),
            "flash"                => null,
        ];
    }

    /** This plugin's public.php, as the current request reached it. */
    public static function base(Request $request): string
    {
        $uri  = $request->getUri();
        $path = $uri->getPath();

        // QueryRoutingMiddleware has already rewritten the path by the time a
        // handler runs, so recover public.php from the ORIGINAL script name
        // rather than from what the router sees.
        $script = $request->getServerParams()["SCRIPT_NAME"] ?? $path;

        return (string) $script;
    }

    /**
     * A file under public/, which UISP serves from a sibling web-root path.
     *
     * CACHE-BUSTED on mtime, and that is not optional. `public/` is a plain
     * static path with no version in it, so a browser holds the old copy
     * indefinitely — which cost a real debugging session here: a rewritten
     * pages.js never ran, the page kept the previous behaviour, and every server
     * check said the new file was deployed. It was; the browser just was not
     * asking for it.
     *
     * mtime rather than the plugin version, because it changes on every deploy
     * (the whole dev loop is copying files into place) as well as on every
     * release. A version string would only be right for one of those.
     */
    public static function asset(Request $request, string $file): string
    {
        $file = ltrim($file, "/");

        // .../public.php  ->  .../public/<file>
        $url = preg_replace('~/public\.php$~', "/public/" . $file, self::base($request))
            ?? "public/" . $file;

        $path  = dirname(__DIR__, 2) . "/public/" . $file;
        $stamp = is_readable($path) ? (int) filemtime($path) : 0;

        return $stamp > 0 ? $url . "?v=" . $stamp : $url;
    }
}
