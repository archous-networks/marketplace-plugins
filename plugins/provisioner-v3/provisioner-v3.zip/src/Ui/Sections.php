<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Ui;

/**
 * The Options page's tabs, and the fields each one edits.
 *
 * ── WHY TABS ARE ROUTES ─────────────────────────────────────────────────────
 * Every tabbed page on the instance — clients, invoices, settings, backup — is a
 * set of LINKS to separate URLs, each its own controller marking itself
 * `selected`. Not a client-side panel switcher. Copying that gets bookmarking,
 * the back button and correct behaviour for free, and is the difference between
 * looking native and looking like a plugin. See the `uisp-ui` skill.
 *
 * It also makes each tab its own small form with its own Save, instead of one
 * page-sized form where an unrelated edit rides along with the one you meant.
 *
 * ── ONE DEFINITION, THREE CONSUMERS ─────────────────────────────────────────
 * The tab strip, the table columns and the add-form fields are all generated
 * from the table below. Three hand-maintained copies of "a BNG device has a
 * name, an IP and a port" is three chances to disagree.
 */
final class Sections
{
    /**
     * `field` names the key in the stored Options record; a section without one
     * is bespoke (General). `fields` describes one row of that list.
     *
     * @return array<string,array<string,mixed>>
     */
    public static function all(): array
    {
        return [
            "general" => [
                "label"   => "General",
                "heading" => "General",
                "field"   => null,
            ],

            "bng" => [
                "label"   => "BNG",
                "heading" => "BNG Devices",
                "field"   => "bng_devices",
                "noun"    => "BNG device",
                "help"    => "Devices that authenticate subscribers directly.",
                "fields"  => [
                    ["key" => "type",     "label" => "Type", "type" => "select",
                     "choices" => Vocabulary::BNG_DEVICE_TYPES],
                    ["key" => "name",     "label" => "Name",     "required" => true],
                    ["key" => "ip",       "label" => "IP Address", "required" => true],
                    ["key" => "port",     "label" => "Port",     "type" => "number"],
                    ["key" => "username", "label" => "Username"],
                    ["key" => "password", "label" => "Password", "type" => "password"],
                ],
            ],

            "radius" => [
                "label"   => "RADIUS",
                "heading" => "RADIUS Servers",
                "field"   => "radius_servers",
                "noun"    => "RADIUS server",
                "help"    => "Used when a broadcast domain authenticates via RADIUS rather than a BNG.",
                "fields"  => [
                    ["key" => "type",   "label" => "Type", "type" => "select",
                     "choices" => Vocabulary::RADIUS_SERVER_TYPES],
                    ["key" => "name",   "label" => "Name",       "required" => true],
                    ["key" => "ip",     "label" => "IP Address", "required" => true],
                    ["key" => "secret", "label" => "Shared Secret", "type" => "password"],
                ],
            ],

            "cpe" => [
                "label"   => "CPEs",
                "heading" => "Managed Routers",
                "field"   => "managed_routers",
                "noun"    => "managed router",
                "help"    => "CPE models the provisioner can configure on a subscriber’s behalf.",
                "fields"  => [
                    ["key" => "type", "label" => "Type", "type" => "select",
                     "choices" => Vocabulary::MANAGED_ROUTER_TYPES],
                    ["key" => "name", "label" => "Name", "required" => true],
                ],
            ],

            "prtg" => [
                "label"   => "PRTG",
                "heading" => "PRTG Template Devices",
                "field"   => "prtg_template_devices",
                "noun"    => "template device",
                "help"    => "Templates a monitored device is cloned from.",
                "fields"  => [
                    ["key" => "name",      "label" => "Name",      "required" => true],
                    ["key" => "device_id", "label" => "Device ID", "required" => true],
                ],
            ],
        ];
    }

    /**
     * The header's "+" split button: what it does by default, and the rest.
     *
     * The default is BNG — the first thing an operator configures, and what the
     * other lists are chosen from. Native repeats the default as the dropdown's
     * first item rather than omitting it, so the menu reads as the complete list
     * of what the button can do.
     *
     * @return array{default:array{href:string},items:array<int,array{href:string,label:string}>}
     */
    public static function addMenu(string $base): array
    {
        $route = static fn(string $path): string => $base . "?route=" . $path;

        return [
            "default" => ["href" => $route("/options/bng/new")],
            "items"   => [
                ["href" => $route("/options/bng/new"),    "label" => "Add BNG Device"],
                ["href" => $route("/options/radius/new"), "label" => "Add RADIUS Server"],
                ["href" => $route("/options/cpe/new"),    "label" => "Add CPE Type"],
                ["href" => $route("/options/import"),     "label" => "Import Options"],
            ],
        ];
    }

    /** @return array<string,mixed>|null */
    public static function find(string $key): ?array
    {
        return self::all()[$key] ?? null;
    }

    /**
     * The tab strip, ready to render.
     *
     * @return array<int,array{href:string,label:string,selected:bool}>
     */
    public static function tabs(string $base, string $active): array
    {
        $tabs = [];

        foreach (self::all() as $key => $section) {
            $tabs[] = [
                "href"     => $base . "?route=/options/" . $key,
                "label"    => $section["label"],
                "selected" => $key === $active,
            ];
        }

        return $tabs;
    }
}
