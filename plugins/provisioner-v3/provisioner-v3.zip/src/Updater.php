<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner;

use Archous\Provisioner\Ucrm\Database;
use Archous\Provisioner\Ucrm\Server;
use RuntimeException;
use ZipArchive;

/**
 * Self-update: reproduces UISP's own plugin upgrade from inside the plugin.
 *
 * UISP has no API for installing or updating a plugin — `plugin_upload` and
 * `plugin_install` exist only as admin-UI routes — so a plugin that wants to
 * update itself has to redo what `AppBundle\Facade\PluginFacade::updatePlugin()`
 * does:
 *
 *   1. refuse while the plugin is running          (isRunning check)
 *   2. stage data/, delete, extract, restore data/ (PluginFileManager::upgrade)
 *   3. rescan files -> has_admin_zone_js/_client    (setPluginFilesMetadata)
 *   4. record the new version from the manifest     (setInformationFromManifest)
 *   5. recreate the web-root public/ symlink        (createPublicSymlink)
 *   6. invalidate the cached zone-JS lookup         (pluginsChecker->invalidate)
 *
 * ...then fire hook_update.php, which UISP calls after a version change.
 *
 * ── ARTIFACT CONTRACT ───────────────────────────────────────────────────────
 * `update_url` in the plugin configuration points at a directory serving:
 *
 *   <update_url>/latest                      plain text, e.g. "3.0.1"
 *   <update_url>/provisioner-<version>.zip   the bundle
 *
 * Same shape v2 used, where `composer archive` wrote `latest` beside the ZIP.
 *
 * ── WHY CLI ONLY ────────────────────────────────────────────────────────────
 * This deletes and replaces the very files the running process loads from. Under
 * php-fpm that is unsafe twice over: public.php bypasses UISP's execution lock
 * so several requests could update at once, and a class autoloaded *after* the
 * swap would resolve to a file that no longer exists. main.php runs under
 * UISP's `.ucrm-plugin-running` lock and is serialised for free, so updates
 * happen there and public.php only ever *requests* a run.
 */
final class Updater
{
    /** Config key holding the base URL of the artifact host. */
    private const CONFIG_KEY = "update_url";

    /** Nothing may be autoloaded after the swap — see preload(). */
    private static bool $preloaded = false;

    /**
     * Version currently installed, from manifest.json.
     */
    public static function currentVersion(): string
    {
        $manifest = json_decode((string) @file_get_contents(Plugin::dir() . "/manifest.json"), true);

        return (string) ($manifest["information"]["version"] ?? "0.0.0");
    }

    /**
     * Version advertised by the artifact host, or null if unreachable/unset.
     */
    public static function latestVersion(int $timeout = 30, int $connectTimeout = 10): ?string
    {
        $base = self::updateUrl();

        if ($base === null) {
            return null;
        }

        $body = self::fetch($base . "/latest", $timeout, $connectTimeout);

        if ($body === null) {
            return null;
        }

        $version = trim($body);

        // Guard against fetching an HTML error page and treating it as a version.
        return preg_match('/^\d+\.\d+\.\d+/', $version) === 1 ? $version : null;
    }

    /**
     * True when the artifact host advertises a newer version than is installed.
     */
    public static function isAvailable(): bool
    {
        $latest = self::latestVersion();

        return $latest !== null && version_compare($latest, self::currentVersion(), ">");
    }

    /**
     * Cheap staleness check for the request path: if an update is available, ask
     * UISP to run the plugin, and let main.php do the work.
     *
     * `.ucrm-plugin-execution-requested` is UISP's own mechanism for scheduling a
     * run outside the configured period, and its cron picks it up **every
     * minute** (`plugins.sh --execution-period manually-requested`). So this is
     * near-immediate without updating from a web request, which would be unsafe:
     * public.php bypasses UISP's execution lock, so concurrent requests could
     * each start replacing the files the others are executing.
     *
     * Throttled by a stamp file so only one request per TTL touches the network,
     * and with a short timeout so a slow artifact host cannot stall a webhook
     * delivery for long.
     */
    public static function requestUpdateIfStale(int $ttlSeconds = 900): bool
    {
        $stamp = Plugin::dir() . "/data/.update-check";

        if (is_file($stamp) && (time() - (int) @filemtime($stamp)) < $ttlSeconds) {
            return false;
        }

        @touch($stamp);

        // Short timeouts: this runs on the request path, and one of those
        // requests may be a webhook delivery. A hung artifact host must cost a
        // couple of seconds, not a UISP-side timeout and retry.
        $latest = self::latestVersion(3, 2);

        if ($latest === null || !version_compare($latest, self::currentVersion(), ">")) {
            return false;
        }

        $requested = Plugin::dir() . "/.ucrm-plugin-execution-requested";

        if (!is_file($requested)) {
            @touch($requested);
            error_log(sprintf(
                "(update) %s available (have %s) — requested a plugin run",
                $latest,
                self::currentVersion()
            ));
        }

        return true;
    }

    /**
     * Perform the update. CLI only. Returns a short outcome for logging.
     *
     * @return array{updated:bool,from:string,to:?string,reason:?string}
     */
    public static function update(): array
    {
        $from = self::currentVersion();

        if (PHP_SAPI !== "cli") {
            return self::outcome(false, $from, null, "refusing to self-update outside CLI");
        }

        // Refuse while a DIFFERENT plugin run is in flight. Our own lock below
        // only guards against a second *updater*; a bulk provision holds no such
        // lock, and replacing files underneath one would be just as bad.
        if (self::isPluginRunningElsewhere()) {
            return self::outcome(false, $from, null, "another plugin run is in progress");
        }

        // Serialise against another updater. UISP holds `.ucrm-plugin-running`
        // for the duration of a scheduled or manual run, and its own
        // PluginFacade::updatePlugin() refuses outright while it is held — but
        // that lock does not cover someone invoking `php main.php` by hand, which
        // is exactly what a developer does. Two updaters replacing the same
        // directory would interleave a delete with an extract.
        //
        // An atomic mkdir is the lock primitive UISP itself uses for the same
        // job: it either creates the directory or it does not, with no window
        // between checking and taking it.
        $lock = Plugin::dir() . "/.update-running";

        if (!@mkdir($lock, 0775)) {
            $age = time() - (int) @filemtime($lock);

            // Never wedge permanently on a lock left by a crashed run.
            if ($age < 3600) {
                return self::outcome(false, $from, null, "another update is in progress");
            }

            @rmdir($lock);

            if (!@mkdir($lock, 0775)) {
                return self::outcome(false, $from, null, "could not take the update lock");
            }
        }

        try {
            return self::runUpdate($from);
        } finally {
            @rmdir($lock);
        }
    }

    /**
     * @return array{updated:bool,from:string,to:?string,reason:?string}
     */
    private static function runUpdate(string $from): array
    {

        $latest = self::latestVersion();

        if ($latest === null) {
            return self::outcome(false, $from, null, "no update_url configured, or host unreachable");
        }

        if (!version_compare($latest, $from, ">")) {
            return self::outcome(false, $from, $latest, null);   // already current
        }

        $zipPath = self::download($latest);

        if ($zipPath === null) {
            return self::outcome(false, $from, $latest, "download failed");
        }

        // Integrity before anything destructive. A truncated download can still
        // be a *valid* ZIP — fewer entries, opens cleanly — so "it extracted" is
        // not evidence the artifact was complete.
        $checksumError = self::verifyChecksum($zipPath, $latest);

        if ($checksumError !== null) {
            @unlink($zipPath);
            return self::outcome(false, $from, $latest, $checksumError);
        }

        try {
            self::preload();
            self::verify($zipPath, $latest);
            self::swap($zipPath);

            // From here on the code on disk is the NEW code, while this process
            // still holds the OLD classes. Do not autoload anything further.
            self::reconcileWithUcrm($latest);

            self::fireUpdateHook($from, $latest);

            return self::outcome(true, $from, $latest, null);
        } catch (\Throwable $e) {
            // A failed update must not take the plugin run down with it. swap()
            // has already rolled back by this point, so the install is intact —
            // report it as an outcome and let main.php get on with its work.
            // Letting this escape produced an uncaught fatal in testing, which
            // is both alarming and useless: it buries the rollback message under
            // a stack trace and aborts everything else main.php had to do.
            error_log(sprintf("(update) failed: %s [%s:%d]", $e->getMessage(), basename($e->getFile()), $e->getLine()));

            return self::outcome(false, $from, $latest, $e->getMessage());
        } finally {
            @unlink($zipPath);
        }
    }

    // ── internals ───────────────────────────────────────────────────────────

    /**
     * Is `.ucrm-plugin-running` held by a run OTHER than this one?
     *
     * The naive check — "does the lock exist?" — is actively wrong here. UISP's
     * `plugins.sh` takes it *before* invoking main.php:
     *
     *     mkdir "${pluginDirectory}/.ucrm-plugin-running"
     *     env --ignore-environment PATH="…" TMPDIR="/tmp/plugins" \
     *         timeout -s KILL 3600 php "${pluginDirectory}/main.php"
     *
     * so during every scheduled run the lock is present and belongs to us.
     * Refusing on its mere existence would block the only path updates normally
     * take.
     *
     * The distinguishing signal is in that same line: `plugins.sh` clears the
     * environment and sets `TMPDIR=/tmp/plugins`. Seeing that means we are the
     * run the lock was taken for.
     *
     * It is a heuristic, and the failure mode is deliberately the safe one: if
     * someone hand-runs main.php with TMPDIR spoofed to /tmp/plugins, the check
     * is skipped and behaviour is what it was before this existed.
     *
     * Stale locks are ignored on the same 60-minute rule UISP applies itself
     * (`find … -mmin +60 -name ".ucrm-plugin-running" -delete`). That matters
     * because UISP kills an overrunning plugin with SIGKILL at 3600s, so no
     * cleanup ever runs and an abandoned lock is normal, not exceptional.
     */
    private static function isPluginRunningElsewhere(): bool
    {
        $lock = Plugin::dir() . "/.ucrm-plugin-running";

        if (!is_dir($lock)) {
            return false;
        }

        if ((string) getenv("TMPDIR") === "/tmp/plugins") {
            return false;   // this is the run the lock was taken for
        }

        return (time() - (int) @filemtime($lock)) < 3600;
    }

    private static function updateUrl(): ?string
    {
        $url = trim((string) (Plugin::config()[self::CONFIG_KEY] ?? ""));

        return $url === "" ? null : rtrim($url, "/");
    }

    private static function fetch(string $url, int $timeout = 30, int $connectTimeout = 10): ?string
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $connectTimeout,
        ]);

        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return ($code === 200 && is_string($body)) ? $body : null;
    }

    private static function download(string $version): ?string
    {
        $base = self::updateUrl();
        $body = $base === null ? null : self::fetch(sprintf("%s/provisioner-%s.zip", $base, $version));

        if ($body === null || $body === "") {
            return null;
        }

        $tmp = sys_get_temp_dir() . "/provisioner-update-" . getmypid() . ".zip";

        return @file_put_contents($tmp, $body) !== false ? $tmp : null;
    }

    /**
     * Load every class the swap depends on, before any file is touched.
     *
     * Composer's autoloader resolves lazily. Once the plugin directory has been
     * replaced, a class not yet loaded resolves to a path that no longer holds
     * the file we expect — a fatal in the middle of an update, with the plugin
     * half-swapped. Touching them here forces resolution while the old files
     * still exist.
     */
    private static function preload(): void
    {
        if (self::$preloaded) {
            return;
        }

        class_exists(Server::class);
        class_exists(Database::class);
        class_exists(Plugin::class);
        class_exists(ZipArchive::class);

        self::$preloaded = true;
    }

    /**
     * Compare the download against `<zip>.sha256` from the artifact host.
     *
     * Optional by design: a host that publishes no checksum still works, because
     * requiring one would break every existing publishing setup. When one IS
     * published it is enforced strictly — an artifact host that serves a
     * checksum and then a file that does not match it is a strong signal
     * something is wrong, not something to shrug at.
     *
     * @return string|null error message, or null when acceptable
     */
    private static function verifyChecksum(string $zipPath, string $version): ?string
    {
        $base = self::updateUrl();

        if ($base === null) {
            return null;
        }

        $expected = self::fetch(sprintf("%s/provisioner-%s.zip.sha256", $base, $version), 15, 5);

        if ($expected === null) {
            return null;   // not published — accept, as before
        }

        // Accept both a bare digest and `sha256sum` output ("<hash>  <file>").
        $expected = strtolower(trim(explode(" ", trim($expected))[0]));

        if (!preg_match('/^[0-9a-f]{64}$/', $expected)) {
            return "checksum file is not a sha256 digest";
        }

        $actual = hash_file("sha256", $zipPath);

        if ($actual !== $expected) {
            return sprintf("checksum mismatch (expected %s…, got %s…)", substr($expected, 0, 12), substr((string) $actual, 0, 12));
        }

        return null;
    }

    /**
     * Reject anything that is not plausibly this plugin, before deleting files.
     */
    private static function verify(string $zipPath, string $expectedVersion): void
    {
        $zip = new ZipArchive();

        if ($zip->open($zipPath) !== true) {
            throw new RuntimeException("downloaded file is not a readable ZIP");
        }

        try {
            $raw = $zip->getFromName("manifest.json");

            if ($raw === false) {
                throw new RuntimeException("ZIP has no manifest.json at its root");
            }

            $manifest = json_decode($raw, true);
            $name     = $manifest["information"]["name"] ?? null;
            $version  = $manifest["information"]["version"] ?? null;

            if ($name !== Plugin::name()) {
                throw new RuntimeException(sprintf(
                    "ZIP is for plugin '%s', expected '%s'",
                    (string) $name,
                    Plugin::name()
                ));
            }

            if ($version !== $expectedVersion) {
                throw new RuntimeException(sprintf(
                    "ZIP manifest says %s but 'latest' advertised %s",
                    (string) $version,
                    $expectedVersion
                ));
            }

            if ($zip->locateName("public.php") === false) {
                throw new RuntimeException("ZIP has no public.php at its root");
            }
        } finally {
            $zip->close();
        }
    }

    /**
     * Replace the plugin's files, preserving data/.
     *
     * Mirrors PluginFileManager::upgrade(): move data/ aside, remove everything
     * else, extract, put data/ back. data/ holds config.json — the Nautobot
     * token — and plugin.log, so losing it would be self-inflicted and
     * unrecoverable.
     */
    /**
     * Replace the plugin's files, preserving what UISP owns, with rollback.
     *
     * Sequence, chosen so every step is reversible until the last one:
     *
     *   1. stage data/ aside          — if this fails nothing has been touched
     *   2. move replaceable files to a backup directory (rename, not copy)
     *   3. extract the new ZIP
     *   4. restore data/
     *   5. health-check the result in a FRESH php process
     *   6. on success drop the backup; on any failure put it back
     *
     * The backup is a rename rather than a copy: same filesystem, so it is fast
     * and cannot half-finish for want of disk space. Step 5 is what makes this
     * resilient rather than merely careful — an archive can extract perfectly and
     * still be unloadable, and without a check the first symptom would be every
     * request failing.
     */
    private static function swap(string $zipPath): void
    {
        $dir  = Plugin::dir();
        $data = $dir . "/data";

        // Stage INSIDE the plugin directory. rename() cannot cross filesystems,
        // and /tmp is a separate mount from /data inside the ucrm container — so
        // staging to sys_get_temp_dir() fails outright. (It failed exactly that
        // way in testing, before anything had been deleted, which is the point of
        // doing it first.)
        $pid        = getmypid();
        $stagedName = ".data-staging-" . $pid;
        $backupName = ".update-backup-" . $pid;
        $staged     = $dir . "/" . $stagedName;
        $backup     = $dir . "/" . $backupName;

        $hadData = is_dir($data);

        if ($hadData && !@rename($data, $staged)) {
            throw new RuntimeException("could not stage data/ — aborting before deleting anything");
        }

        if (!@mkdir($backup, 0775)) {
            if ($hadData) {
                @rename($staged, $data);
            }
            throw new RuntimeException("could not create the backup directory — aborting");
        }

        $moved = [];

        try {
            // Move rather than delete, so the old version is recoverable.
            foreach (self::entries($dir, [$stagedName, $backupName]) as $entry) {
                $name = basename($entry);

                if (!@rename($entry, $backup . "/" . $name)) {
                    throw new RuntimeException("could not back up '$name' — aborting with nothing lost");
                }

                $moved[] = $name;
            }

            $zip = new ZipArchive();

            if ($zip->open($zipPath) !== true) {
                throw new RuntimeException("could not reopen the ZIP for extraction");
            }

            $ok = $zip->extractTo($dir);
            $zip->close();

            if (!$ok) {
                throw new RuntimeException("extraction failed");
            }

            // data/ must be back before the health check — the plugin reads
            // config.json during bootstrap.
            if ($hadData) {
                if (is_dir($data)) {
                    self::removeRecursive($data);
                }

                if (!@rename($staged, $data)) {
                    throw new RuntimeException("could not restore data/");
                }

                $hadData = false;   // restored; the catch block must not redo it
            }

            if (!self::healthCheck($dir)) {
                throw new RuntimeException("new version failed its health check");
            }

            // Committed. Drop the old version.
            self::removeRecursive($backup);
        } catch (\Throwable $e) {
            self::rollback($dir, $backup, $moved);

            if ($hadData) {
                if (is_dir($data)) {
                    self::removeRecursive($data);
                }
                @rename($staged, $data);
            }

            throw $e;
        }
    }

    /**
     * Put the previous version back after a failed update.
     *
     * Deliberately best-effort and silent about individual failures: this runs
     * while an exception is already propagating, and throwing here would replace
     * a useful error with a confusing one. What it must never do is leave the
     * directory empty.
     */
    private static function rollback(string $dir, string $backup, array $moved): void
    {
        if (!is_dir($backup)) {
            return;
        }

        // Clear whatever the failed extraction left behind, so the restore has
        // somewhere to land.
        foreach (self::entries($dir, [basename($backup)]) as $entry) {
            self::removeRecursive($entry);
        }

        foreach ($moved as $name) {
            @rename($backup . "/" . $name, $dir . "/" . $name);
        }

        @rmdir($backup);

        error_log("(update) rolled back to the previous version");
    }

    /**
     * Does the newly extracted tree actually load?
     *
     * Runs in a FRESH php process: this process still holds the old classes in
     * memory, so it cannot tell whether the new files are loadable. The child
     * boots the new autoloader and touches the classes an update depends on, so
     * a truncated vendor/ or a missing src/ file is caught here rather than by
     * every subsequent web request.
     */
    private static function healthCheck(string $dir): bool
    {
        $probe = <<<'PHP'
            $dir = $argv[1];
            require $dir . "/vendor/autoload.php";
            foreach ([
                "Archous\\Provisioner\\Plugin",
                "Archous\\Provisioner\\Updater",
                "Archous\\Provisioner\\Ucrm\\Server",
                "Archous\\Provisioner\\Middleware\\QueryRoutingMiddleware",
            ] as $c) {
                if (!class_exists($c)) { fwrite(STDERR, "missing $c\n"); exit(1); }
            }
            if (!is_file($dir . "/public.php") || !is_file($dir . "/main.php")) {
                fwrite(STDERR, "entry point missing\n"); exit(1);
            }
            exit(0);
            PHP;

        $cmd = sprintf(
            "%s -r %s %s 2>&1",
            escapeshellarg(PHP_BINARY),
            escapeshellarg($probe),
            escapeshellarg($dir)
        );

        exec($cmd, $out, $code);

        if ($code !== 0) {
            error_log(sprintf("(update) health check failed: %s", implode(" | ", $out)));
        }

        return $code === 0;
    }

    /**
     * Bring UISP's own bookkeeping back in line after the files changed.
     *
     * Delegates to the commands UISP ships rather than reimplementing them, so a
     * change to UISP's internals is inherited instead of quietly diverging from a
     * copy of its logic:
     *
     *   crm:plugin:update-database-information   version + has_*_zone_js
     *   crm:plugin:symlink                       web-root public/ symlink
     *   crm:plugin:ucrm-config                   regenerate ucrm.json
     *
     * ucrm-config runs even though the swap preserves ucrm.json: it costs a
     * moment and it is the supported way to get that file back if anything ever
     * removes it. Deleting it once already broke the plugin during development,
     * and this is the repair UISP itself uses.
     *
     * Each falls back to our own implementation, because a console that has moved
     * or been renamed in a future UISP must degrade to "slightly less correct",
     * never to "update leaves the install broken".
     *
     * The zone-JS cache is invalidated separately and unconditionally: the
     * console runs under CLI and cannot reach php-fpm's APCu segment, so no
     * console command can do it — see Server::invalidateZoneJsCache().
     */
    private static function reconcileWithUcrm(string $version): void
    {
        if (!Server::console("crm:plugin:update-database-information")) {
            error_log("(update) console unavailable — recording metadata directly");
            self::recordMetadata($version);
        }

        if (!Server::console("crm:plugin:symlink")) {
            Server::createPublicSymlink();
        }

        Server::console("crm:plugin:ucrm-config");

        Server::invalidateZoneJsCache();
    }

    /**
     * Fallback for reconcileWithUcrm(): reproduces setPluginFilesMetadata() +
     * setInformationFromManifest() when UISP's console cannot be reached.
     *
     * UISP derives has_admin_zone_js / has_client_zone_js purely from file
     * presence; the version comes from the manifest.
     */
    private static function recordMetadata(string $version): void
    {
        $pdo = Database::ucrm();

        $stmt = $pdo->prepare(
            'UPDATE plugin
                SET version = :version,
                    has_admin_zone_js = :admin,
                    has_client_zone_js = :client
              WHERE name = :name'
        );

        $stmt->execute([
            "version" => $version,
            "admin"   => is_file(Plugin::dir() . "/public/admin-zone.js")  ? "true" : "false",
            "client"  => is_file(Plugin::dir() . "/public/client-zone.js") ? "true" : "false",
            "name"    => Plugin::name(),
        ]);
    }

    /**
     * Run hook_update.php in a FRESH process, so it executes the new code with a
     * new autoloader rather than this process's stale one.
     */
    private static function fireUpdateHook(string $from, string $to): void
    {
        $hook = Plugin::dir() . "/hook_update.php";

        if (!is_file($hook)) {
            return;
        }

        $cmd = sprintf(
            "cd %s && PLUGIN_UPDATE_FROM=%s PLUGIN_UPDATE_TO=%s %s hook_update.php 2>&1",
            escapeshellarg(Plugin::dir()),
            escapeshellarg($from),
            escapeshellarg($to),
            escapeshellarg(PHP_BINARY)
        );

        exec($cmd, $out, $code);

        if ($code !== 0) {
            error_log(sprintf("(hook:update) hook_update.php exited %d: %s", $code, implode(" | ", $out)));
        }
    }

    /**
     * Files UISP owns, which the archive therefore must NOT contain and the swap
     * must NOT delete.
     *
     * `AbstractPluginFileManager::RESERVED_FILES` — "reserved by UCRM and cannot
     * be contained in the plugin archive". Because they are absent from the ZIP,
     * deleting them leaves nothing to restore them: ucrm.json holds pluginAppKey
     * and every URL the plugin knows about itself, and UISP only rewrites it when
     * CRM settings change. An update that removed it would leave the plugin
     * unable to call the CRM API or work out its own address, with no error until
     * something tried.
     *
     * This list and composer.json's `archive.exclude` describe the same set for
     * the same reason. Keep them in step.
     */
    private const PRESERVE = [
        "data",                              // config.json (Nautobot token), plugin.log
        "ucrm.json",                         // URLs + pluginAppKey + pluginId
        ".ucrm-plugin-running",              // execution lock — may be held right now
        ".ucrm-plugin-execution-requested",  // a queued run we must not swallow
        ".update-running",                   // our own lock — held by the caller right now
    ];

    /**
     * @param string[] $alsoKeep additional basenames to leave alone
     * @return string[] absolute paths of everything in $dir that may be replaced
     */
    private static function entries(string $dir, array $alsoKeep = []): array
    {
        $keep  = array_merge(self::PRESERVE, $alsoKeep);
        $paths = [];

        foreach (scandir($dir) ?: [] as $name) {
            if ($name === "." || $name === ".." || in_array($name, $keep, true)) {
                continue;
            }
            $paths[] = $dir . "/" . $name;
        }

        return $paths;
    }

    private static function removeRecursive(string $path): void
    {
        if (is_link($path) || is_file($path)) {
            @unlink($path);
            return;
        }

        if (!is_dir($path)) {
            return;
        }

        foreach (scandir($path) ?: [] as $name) {
            if ($name === "." || $name === "..") {
                continue;
            }
            self::removeRecursive($path . "/" . $name);
        }

        @rmdir($path);
    }

    /**
     * @return array{updated:bool,from:string,to:?string,reason:?string}
     */
    private static function outcome(bool $updated, string $from, ?string $to, ?string $reason): array
    {
        return ["updated" => $updated, "from" => $from, "to" => $to, "reason" => $reason];
    }
}
