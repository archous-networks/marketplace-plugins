<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Provisioning;

use Archous\Provisioner\Store\LocalStore;
use Archous\Provisioner\Ucrm\Api;

/**
 * One provisioning record per UISP service — v2's `Config` model.
 *
 * ── WHAT A CONFIG IS ────────────────────────────────────────────────────────
 * The join between a service UISP knows about and the provisioning decisions made
 * for it: which broadcast domain it belongs to, its MAC or RADIUS credentials, its
 * static IP and routes. The service is UISP's; the rest is ours.
 *
 * Which means the list is **derived, not stored**. Services come from the CRM API
 * and are filtered to the plans Options marks as supported; a stored record is
 * attached where one exists. A service with no record is not missing — it is
 * simply not provisioned yet, and shows as such.
 *
 * That ordering matters: storing the list would let it drift from UISP the moment
 * a service is added, renamed or cancelled, and the plugin has no business being
 * a second register of what services exist.
 *
 * ⚠️ **Nothing here reaches Nautobot yet, and nothing provisions.** Records are
 * read from LocalStore, a placeholder — see its docblock. This page currently
 * answers "what would be provisioned, and with what?", which is the question worth
 * being able to answer before anything is pushed anywhere.
 */
final class Configs
{
    private const STORE = "configs";

    /**
     * Every supported service, with its record attached.
     *
     * @return array<int,array<string,mixed>>
     */
    public static function all(): array
    {
        $options   = Options::load();
        $supported = $options["supported_service_plan_ids"];
        $stored    = self::stored();

        // Domains are looked up by id so a row can name the one it points at, and
        // say plainly when it points at nothing.
        $domains = [];

        foreach (BroadcastDomains::all() as $domain) {
            $domains[$domain["id"]] = $domain;
        }

        $default = null;

        foreach ($domains as $domain) {
            if ($domain["is_default"]) {
                $default = $domain;
                break;
            }
        }

        $clients = [];

        foreach (Api::clients() as $client) {
            $clients[(int) ($client["id"] ?? 0)] = $client;
        }

        $rows = [];

        foreach (Api::services() as $service) {
            $planId = (int) ($service["servicePlanId"] ?? 0);

            // An empty supported list means nothing is provisioned yet, not
            // everything — Options is the switch that turns this on.
            if (!in_array($planId, $supported, true)) {
                continue;
            }

            $id     = (int) ($service["id"] ?? 0);
            $config = $stored[$id] ?? [];
            $client = $clients[(int) ($service["clientId"] ?? 0)] ?? null;

            $domainId = (string) ($config["domain_id"] ?? "");
            $domain   = $domains[$domainId] ?? null;

            $rows[] = [
                "service_id"     => $id,
                "service_name"   => (string) ($service["name"] ?? ""),
                "service_status" => (int) ($service["status"] ?? 0),
                "client_id"      => (int) ($service["clientId"] ?? 0),
                "client_name"    => $client !== null ? Api::clientName($client) : "",
                "address"        => (string) ($service["fullAddress"] ?? ""),

                "mac_address"    => (string) ($config["mac_address"] ?? ""),
                "static_ip"      => (string) ($config["static_ip"] ?? ""),
                "static_routes"  => is_array($config["static_routes"] ?? null) ? $config["static_routes"] : [],

                // Falling back to the default is what provisioning would actually
                // do, so the page shows it — flagged as inherited rather than
                // presented as a choice someone made.
                "domain_name"    => $domain["name"] ?? ($default["name"] ?? ""),
                "domain_id"      => $domain["id"] ?? ($default["id"] ?? ""),
                "domain_default" => $domain === null,

                "configured"     => $config !== [],
            ];
        }

        return $rows;
    }

    /** @return array<string,mixed>|null the stored record for one service */
    public static function find(int $serviceId): ?array
    {
        return self::stored()[$serviceId] ?? null;
    }

    /**
     * The shape of an unsaved record.
     *
     * Every key present and empty rather than an empty array: Twig runs with
     * `strict_variables`, so a template reading a key the fallback happens not to
     * carry is a 500 rather than a blank field. One definition of the shape means
     * the editor cannot ask for something this does not answer.
     *
     * @return array<string,mixed>
     */
    public static function blank(): array
    {
        return [
            "domain_id"     => "",
            "mac_address"   => "",
            "static_ip"     => "",
            "static_routes" => [],
            "updated_at"    => null,
        ];
    }

    /**
     * @param array<string,mixed> $input
     * @return array<string,mixed> what was stored
     */
    public static function save(int $serviceId, array $input): array
    {
        $record = [
            "domain_id"     => trim((string) ($input["domain_id"] ?? "")),
            "mac_address"   => strtoupper(trim((string) ($input["mac_address"] ?? ""))),
            "static_ip"     => trim((string) ($input["static_ip"] ?? "")),
            "static_routes" => self::routes($input["static_routes"] ?? []),
            "updated_at"    => gmdate("c"),
        ];

        $all             = self::stored();
        $all[$serviceId] = $record;

        // Keys are service ids, which JSON turns into strings on the way out and
        // back. Written as an object so a sparse set of ids does not become a
        // list with holes.
        LocalStore::write(self::STORE, ["configs" => $all]);

        return $record;
    }

    public static function forget(int $serviceId): bool
    {
        $all = self::stored();

        if (!array_key_exists($serviceId, $all)) {
            return false;
        }

        unset($all[$serviceId]);
        LocalStore::write(self::STORE, ["configs" => $all]);

        return true;
    }

    /** @return array<int,array<string,mixed>> keyed by service id */
    private static function stored(): array
    {
        $raw  = LocalStore::read(self::STORE, ["configs" => []]);
        $rows = is_array($raw["configs"] ?? null) ? $raw["configs"] : [];

        $out = [];

        foreach ($rows as $id => $row) {
            if (is_array($row)) {
                $out[(int) $id] = $row;
            }
        }

        return $out;
    }

    /**
     * @return array<int,array{cidr:string,gateway:string}>
     *
     * Deliberately not validated as real routing. Whether a prefix is usable is a
     * question for whatever provisions it, and answering it here would be exactly
     * the business logic the public-artifact rule keeps out of the plugin.
     */
    private static function routes(mixed $rows): array
    {
        if (!is_array($rows)) {
            return [];
        }

        $out = [];

        foreach ($rows as $row) {
            $cidr = is_array($row) ? trim((string) ($row["cidr"] ?? "")) : trim((string) $row);

            if ($cidr === "") {
                continue;
            }

            $out[] = [
                "cidr"    => $cidr,
                "gateway" => is_array($row) ? trim((string) ($row["gateway"] ?? "")) : "",
            ];
        }

        return $out;
    }
}
