<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Provisioning;

use Archous\Provisioner\Store\LocalStore;
use Archous\Provisioner\Ui\Vocabulary;

/**
 * Instance-wide provisioning options — v2's `Options` model.
 *
 * One record per instance: the service plans the provisioner acts on, and the
 * inventories a broadcast domain then picks from (BNG devices, RADIUS servers,
 * managed routers, PRTG template devices).
 *
 * ⚠️ **Nothing here reaches Nautobot yet.** Reads and writes go to LocalStore,
 * which is a placeholder — see its docblock. This class is the seam: when the SoT
 * conversation lands, `load()` and `save()` change and the pages do not.
 *
 * Every list is normalised on the way IN rather than trusted on the way out. The
 * browser posts these as a JSON blob in a hidden input (v2's shape, kept), so the
 * shape is whatever a form said it was until this says otherwise.
 */
final class Options
{
    private const STORE = "options";

    /** @return array<string,mixed> */
    public static function defaults(): array
    {
        return [
            "supported_service_plan_ids" => [],
            "bng_devices"                => [],
            "radius_servers"             => [],
            "managed_routers"            => [],
            "prtg_template_devices"      => [],
            "configured"                 => false,
            "updated_at"                 => null,
        ];
    }

    /** @return array<string,mixed> */
    public static function load(): array
    {
        return self::normalise(LocalStore::read(self::STORE, self::defaults()));
    }

    /**
     * @param array<string,mixed> $input
     * @return array<string,mixed> what was actually stored
     */
    public static function save(array $input): array
    {
        $options = self::normalise($input);

        // `configured` is v2's flag for "an operator has been here", which is what
        // distinguishes an empty install from one deliberately left empty.
        $options["configured"] = true;
        $options["updated_at"] = gmdate("c");

        LocalStore::write(self::STORE, $options);

        return $options;
    }

    /**
     * Replace ONE key of the record, leaving the rest as stored.
     *
     * Each Options tab is its own form (see Ui\Sections for why), so a save must
     * not carry the other tabs' values with it — a full replace from a partial
     * form would blank every list the operator was not looking at.
     *
     * @return array<string,mixed> the whole record as stored
     */
    public static function replace(string $key, mixed $value): array
    {
        $options = self::load();

        if (!array_key_exists($key, self::defaults())) {
            return $options;
        }

        $options[$key] = $value;

        return self::save($options);
    }

    /** Append one row to a list, then store. @return array<string,mixed> */
    public static function append(string $key, array $row): array
    {
        $rows   = self::load()[$key] ?? [];
        $rows[] = $row;

        return self::replace($key, $rows);
    }

    /**
     * Drop one row from a list by position.
     *
     * By INDEX, because these rows have no identity of their own — they are a
     * JSON list, and the index is what the rendered table's delete link can
     * carry. Fine while the page is the only writer; the day two things edit
     * concurrently, rows need ids.
     *
     * @return array<string,mixed>
     */
    public static function removeAt(string $key, int $index): array
    {
        $rows = self::load()[$key] ?? [];

        if (!array_key_exists($index, $rows)) {
            return self::load();
        }

        array_splice($rows, $index, 1);

        return self::replace($key, $rows);
    }

    /**
     * Coerce whatever arrived into the documented shape.
     *
     * Unknown keys are dropped rather than preserved: this is the whole record,
     * so anything not listed is either a stale field from an older version or a
     * field someone posted that we do not have. Keeping either would quietly grow
     * the document into a shape nothing validates.
     *
     * @param array<string,mixed> $input
     * @return array<string,mixed>
     */
    public static function normalise(array $input): array
    {
        return [
            "supported_service_plan_ids" => array_values(array_unique(array_map(
                "intval",
                array_filter((array) ($input["supported_service_plan_ids"] ?? []), "is_numeric")
            ))),

            "bng_devices" => self::rows($input["bng_devices"] ?? [], [
                "type" => Vocabulary::BNG_DEVICE_TYPES,
                "name" => null, "ip" => null, "port" => null,
                "username" => null, "password" => null,
            ]),

            "radius_servers" => self::rows($input["radius_servers"] ?? [], [
                "type" => Vocabulary::RADIUS_SERVER_TYPES,
                "name" => null, "ip" => null, "secret" => null,
            ]),

            "managed_routers" => self::rows($input["managed_routers"] ?? [], [
                "type" => Vocabulary::MANAGED_ROUTER_TYPES,
                "name" => null,
            ]),

            "prtg_template_devices" => self::rows($input["prtg_template_devices"] ?? [], [
                "name" => null, "device_id" => null,
            ]),

            "configured" => (bool) ($input["configured"] ?? false),
            "updated_at" => isset($input["updated_at"]) && is_string($input["updated_at"])
                ? $input["updated_at"]
                : null,
        ];
    }

    /**
     * Normalise a list of uniform rows.
     *
     * @param mixed $rows
     * @param array<string,array<string,string>|null> $fields field => closed set,
     *        or null for free text. A value outside its closed set falls back to
     *        the first member rather than being rejected: these come from a
     *        <select> we rendered, so an unknown one means the vocabulary moved
     *        under an existing record, and blanking the row would lose the rest
     *        of it.
     * @return array<int,array<string,string>>
     */
    private static function rows(mixed $rows, array $fields): array
    {
        if (!is_array($rows)) {
            return [];
        }

        $out = [];

        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }

            $clean = [];

            foreach ($fields as $field => $allowed) {
                $value = is_scalar($row[$field] ?? null) ? trim((string) $row[$field]) : "";

                if ($allowed !== null && !array_key_exists($value, $allowed)) {
                    $value = (string) array_key_first($allowed);
                }

                $clean[$field] = $value;
            }

            // A row with nothing but its type defaulted is an empty row the form
            // submitted; it is not worth storing.
            $meaningful = array_filter($clean, static fn(string $v, string $k): bool
                => $v !== "" && $fields[$k] === null, ARRAY_FILTER_USE_BOTH);

            if ($meaningful !== []) {
                $out[] = $clean;
            }
        }

        return $out;
    }
}
