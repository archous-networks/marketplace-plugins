<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Provisioning;

use Archous\Provisioner\Store\LocalStore;
use Archous\Provisioner\Ui\Vocabulary;

/**
 * Broadcast domains — v2's `Site` model, under the name the operator actually
 * uses for it.
 *
 * A domain is where a service gets provisioned: which BNG or RADIUS server
 * authenticates it, how (MAC vs username/password), which address space its
 * static IPs and routes come from, and what QoS applies. Options supplies the
 * inventories; a domain picks from them.
 *
 * The rename is not cosmetic. v2 called this a "site" in code and "Broadcast
 * Domain" in the UI via `settings.site_text`, which was survivable while the two
 * never met. v3 has to talk to Nautobot, where `Site` already means something
 * else — so the word is spent, and this takes the unambiguous one. See
 * Ui\Vocabulary.
 *
 * ⚠️ **Nothing here reaches Nautobot yet.** Storage is LocalStore, a placeholder.
 */
final class BroadcastDomains
{
    private const STORE = "broadcast-domains";

    /** @return array<int,array<string,mixed>> */
    public static function all(): array
    {
        $stored = LocalStore::read(self::STORE, ["domains" => []]);
        $rows   = is_array($stored["domains"] ?? null) ? $stored["domains"] : [];

        return array_values(array_map([self::class, "normalise"], array_filter($rows, "is_array")));
    }

    /** @return array<string,mixed>|null */
    public static function find(string $id): ?array
    {
        foreach (self::all() as $domain) {
            if ($domain["id"] === $id) {
                return $domain;
            }
        }

        return null;
    }

    /**
     * Insert or update one domain, keyed on its id.
     *
     * @param array<string,mixed> $input
     * @return array<string,mixed> what was actually stored
     */
    public static function save(array $input): array
    {
        $domain  = self::normalise($input);
        $domains = self::all();
        $found   = false;

        foreach ($domains as $i => $existing) {
            if ($existing["id"] === $domain["id"]) {
                // Preserve the original creation time; everything else is replaced.
                $domain["created_at"] = $existing["created_at"];
                $domains[$i]          = $domain;
                $found                = true;
                break;
            }
        }

        if (!$found) {
            $domains[] = $domain;
        }

        self::commit($domains);

        return $domain;
    }

    /**
     * Replace the whole collection — the import path.
     *
     * Wholesale rather than merged: a domain is one record, so a partial document
     * would leave the ones it omits orphaned rather than merged. commit() still
     * enforces exactly one default, so an import that names none or several
     * arrives consistent either way.
     *
     * @param array<int,array<string,mixed>> $rows
     */
    public static function replaceAll(array $rows): void
    {
        self::commit(array_map([self::class, "normalise"], array_filter($rows, "is_array")));
    }

    public static function delete(string $id): bool
    {
        $domains = self::all();
        $kept    = array_values(array_filter($domains, static fn(array $d): bool => $d["id"] !== $id));

        if (count($kept) === count($domains)) {
            return false;
        }

        self::commit($kept);

        return true;
    }

    /** @return array<string,mixed> a new, unsaved domain */
    public static function blank(): array
    {
        return self::normalise([
            "id"   => self::id(),
            "name" => Vocabulary::DOMAIN,
        ]);
    }

    /**
     * @param array<int,array<string,mixed>> $domains
     *
     * Exactly one domain is the default, and it is the one a service falls back
     * to when nothing else matches. Enforced on write rather than checked on
     * read: two defaults is a state the rest of the code should never have to
     * consider, and the alternative is every reader picking a tie-break.
     */
    private static function commit(array $domains): void
    {
        $seenDefault = false;

        foreach ($domains as $i => $domain) {
            if ($domain["is_default"] && !$seenDefault) {
                $seenDefault = true;
                continue;
            }

            $domains[$i]["is_default"] = false;
        }

        if (!$seenDefault && $domains !== []) {
            $domains[0]["is_default"] = true;
        }

        LocalStore::write(self::STORE, ["domains" => array_values($domains)]);
    }

    /**
     * @param array<string,mixed> $input
     * @return array<string,mixed>
     */
    public static function normalise(array $input): array
    {
        $mode = (string) ($input["authentication_mode"] ?? "bng_device");
        $type = (string) ($input["authentication_type"] ?? "mac_address");

        $qos = (bool) ($input["qos_supported"] ?? false);

        return [
            "id"         => self::identifier($input["id"] ?? null),
            "name"       => self::text($input["name"] ?? "", Vocabulary::DOMAIN),
            "is_default" => (bool) ($input["is_default"] ?? false),
            "configured" => (bool) ($input["configured"] ?? false),
            "created_at" => is_string($input["created_at"] ?? null) ? $input["created_at"] : gmdate("c"),
            "updated_at" => gmdate("c"),

            "authentication_mode" => array_key_exists($mode, Vocabulary::AUTHENTICATION_MODES)
                ? $mode : "bng_device",
            "authentication_type" => array_key_exists($type, Vocabulary::AUTHENTICATION_TYPES)
                ? $type : "mac_address",

            // Names, not copies. A domain points at inventory that Options owns,
            // so duplicating the device here would let the two drift and leave no
            // answer to which is right.
            "bng_devices"    => self::names($input["bng_devices"] ?? []),
            "radius_servers" => self::names($input["radius_servers"] ?? []),

            "option_82_supported" => (bool) ($input["option_82_supported"] ?? false),

            "static_ip_blocks"        => self::cidrs($input["static_ip_blocks"] ?? []),
            "static_ip_exclusions"    => self::cidrs($input["static_ip_exclusions"] ?? []),
            "static_route_blocks"     => self::cidrs($input["static_route_blocks"] ?? []),
            "static_route_exclusions" => self::cidrs($input["static_route_exclusions"] ?? []),

            "qos_supported" => $qos,
            // Speeds only mean something when QoS is on. Zeroing them otherwise
            // keeps a disabled-but-populated record from reading as configured.
            "qos_download"  => $qos ? max(0, (int) ($input["qos_download"] ?? 0)) : 0,
            "qos_upload"    => $qos ? max(0, (int) ($input["qos_upload"] ?? 0)) : 0,

            "prtg_template_devices" => self::names($input["prtg_template_devices"] ?? []),
        ];
    }

    /** @return string[] */
    private static function names(mixed $values): array
    {
        if (!is_array($values)) {
            return [];
        }

        $out = [];

        foreach ($values as $value) {
            if (is_scalar($value) && trim((string) $value) !== "") {
                $out[] = trim((string) $value);
            }
        }

        return array_values(array_unique($out));
    }

    /**
     * @return array<int,array{cidr:string,note:string}>
     *
     * Deliberately NOT validated as real CIDR here. A half-typed block should
     * survive a save so the operator can come back to it; whether an address
     * space is usable is a question for whatever provisions it, and answering it
     * in the plugin would be exactly the business logic the public-artifact rule
     * keeps out. The field is marked in the UI instead.
     */
    private static function cidrs(mixed $rows): array
    {
        if (!is_array($rows)) {
            return [];
        }

        $out = [];

        foreach ($rows as $row) {
            $cidr = is_array($row) ? (string) ($row["cidr"] ?? "") : (string) $row;
            $cidr = trim($cidr);

            if ($cidr === "") {
                continue;
            }

            $out[] = [
                "cidr" => $cidr,
                "note" => is_array($row) && is_scalar($row["note"] ?? null)
                    ? trim((string) $row["note"]) : "",
            ];
        }

        return $out;
    }

    private static function text(mixed $value, string $fallback): string
    {
        $value = is_scalar($value) ? trim((string) $value) : "";

        return $value !== "" ? $value : $fallback;
    }

    private static function identifier(mixed $value): string
    {
        $value = is_scalar($value) ? trim((string) $value) : "";

        return preg_match('/^[a-f0-9]{32}$/', $value) === 1 ? $value : self::id();
    }

    private static function id(): string
    {
        return bin2hex(random_bytes(16));
    }
}
