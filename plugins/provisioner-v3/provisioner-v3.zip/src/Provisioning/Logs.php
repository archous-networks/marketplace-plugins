<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Provisioning;

/**
 * `data/plugin.log`, read back as rows.
 *
 * ── WHY THIS EXISTS WHEN UISP ALREADY SHOWS THE LOG ─────────────────────────
 * UISP renders the file verbatim in a textarea on the plugin detail page, which is
 * fine for a glance and useless for finding anything. This parses the two fields
 * every line already has and lets them be filtered — which is the whole reason
 * CLAUDE.md's log format puts a source token on every line.
 *
 * ── THE FORMAT IT PARSES ────────────────────────────────────────────────────
 *
 *     [06-Aug-2026 19:34:31 UTC] (page:options) radius row 1 deleted
 *     └────── PHP's own ───────┘ └── source ──┘ └───── message ─────┘
 *
 * The timestamp is `error_log()`'s, not ours. The parenthesised token is the
 * convention from *Log format* in CLAUDE.md, and nothing enforces it — a stray
 * `error_log("something broke")` produces a line with no source, so that case is
 * kept rather than dropped, with an empty source. A log page that silently hides
 * the malformed lines would hide exactly the ones worth seeing.
 *
 * ── NO LEVELS ───────────────────────────────────────────────────────────────
 * v2's page had a Level column because it logged to Postgres through monolog. v3
 * uses plain `error_log()` by design, so there is no level to show and inventing
 * one by grepping for "FAILED" would be a guess presented as a fact.
 */
final class Logs
{
    /** Read from the tail, so a long-running instance does not load a huge file. */
    private const MAX_BYTES = 512 * 1024;

    public static function path(): string
    {
        return dirname(__DIR__, 2) . "/data/plugin.log";
    }

    /**
     * @return array<int,array{time:string,source:string,message:string,raw:string}>
     *         newest first
     */
    public static function read(string $filter = ""): array
    {
        $path = self::path();

        if (!is_readable($path)) {
            return [];
        }

        $size   = (int) filesize($path);
        $handle = @fopen($path, "rb");

        if ($handle === false) {
            return [];
        }

        if ($size > self::MAX_BYTES) {
            fseek($handle, $size - self::MAX_BYTES);
            fgets($handle); // discard the partial line the seek landed in
        }

        $rows   = [];
        $filter = trim(mb_strtolower($filter));

        while (($line = fgets($handle)) !== false) {
            $line = rtrim($line, "\r\n");

            if (trim($line) === "") {
                continue;
            }

            $row = self::parse($line);

            if ($filter !== "" && !str_contains(mb_strtolower($row["raw"]), $filter)) {
                continue;
            }

            $rows[] = $row;
        }

        fclose($handle);

        // Newest first: a log page is read from the top, and the file grows at the
        // bottom.
        return array_reverse($rows);
    }

    /** @return array{time:string,source:string,message:string,raw:string} */
    private static function parse(string $line): array
    {
        $row = ["time" => "", "source" => "", "message" => $line, "raw" => $line];

        if (preg_match('/^\[([^\]]+)\]\s*(.*)$/', $line, $m) === 1) {
            $row["time"]    = $m[1];
            $row["message"] = $m[2];
        }

        // Only a token at the START of the message is the source. A parenthesis
        // later in the line is part of what was said.
        if (preg_match('/^\(([^)]+)\)\s*(.*)$/', $row["message"], $m) === 1) {
            $row["source"]  = $m[1];
            $row["message"] = $m[2];
        }

        return $row;
    }

    /**
     * Truncate the log, leaving one line saying so.
     *
     * An empty log cannot distinguish "nothing has happened yet" from "someone
     * wiped the history", and the second is the one worth knowing when reading a
     * log that starts mid-story. Same reasoning as the marketplace plugin's Clear.
     */
    public static function clear(): bool
    {
        $line = sprintf("[%s] (page:logs) log cleared%s", date("d-M-Y H:i:s e"), PHP_EOL);

        return @file_put_contents(self::path(), $line, LOCK_EX) !== false;
    }

    /** @return string[] every source token present, for the filter's datalist */
    public static function sources(): array
    {
        $seen = [];

        foreach (self::read() as $row) {
            if ($row["source"] !== "") {
                $seen[$row["source"]] = true;
            }
        }

        $sources = array_keys($seen);
        sort($sources);

        return $sources;
    }
}
