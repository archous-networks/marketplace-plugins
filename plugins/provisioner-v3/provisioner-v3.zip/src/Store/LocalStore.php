<?php declare(strict_types=1);
/**
 * @author Ryan Spaeth <rspaeth@spaethtech.com>
 * @copyright 2026 - Spaeth Technologies, Archous Networks
 */

namespace Archous\Provisioner\Store;

use RuntimeException;

/**
 * TEMPORARY local persistence for the Options and Broadcast Domain pages.
 *
 * ⚠️ THIS IS A PLACEHOLDER, AND DELIBERATELY A CRUDE ONE.
 *
 * **Nautobot is the source of truth.** Everything written here is destined to
 * live there, and this class exists only so the pages can be built and reviewed
 * before that conversation happens. It is scoped to be easy to delete: the pages
 * talk to `Options` and `BroadcastDomains`, not to this, so replacing the storage
 * means reimplementing those two and dropping this file.
 *
 * What it is NOT, and must not grow into:
 *
 * - a second source of truth. If this file and Nautobot ever disagree, Nautobot
 *   is right by definition, and reconciling them is not a feature to build here.
 * - a place for business logic. Per the public-artifact rule in CLAUDE.md, the
 *   plugin is UI and transport; this is the "UI needs somewhere to put a draft"
 *   half of that, nothing more.
 *
 * `data/` survives plugin updates, so drafts written here outlive an upgrade —
 * convenient during the PoC, and one more reason to be explicit that they are
 * drafts rather than records.
 */
final class LocalStore
{
    private function __construct()
    {
    }

    public static function dir(): string
    {
        return dirname(__DIR__, 2) . "/data";
    }

    /** @return array<string,mixed> */
    public static function read(string $name, array $default = []): array
    {
        $path = self::path($name);

        if (!is_readable($path)) {
            return $default;
        }

        $data = json_decode((string) file_get_contents($path), true);

        return is_array($data) ? $data : $default;
    }

    /**
     * @param array<string,mixed> $data
     *
     * Written via a temp file in the SAME directory and renamed, so a reader
     * never sees a half-written document. rename() is atomic within a
     * filesystem, which is why the temp file cannot live in /tmp — that is a
     * separate mount here, and the rename would fail.
     */
    public static function write(string $name, array $data): void
    {
        $path = self::path($name);
        $tmp  = $path . ".tmp";

        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($json === false) {
            throw new RuntimeException("could not encode $name");
        }

        if (@file_put_contents($tmp, $json . "\n", LOCK_EX) === false) {
            throw new RuntimeException("could not write $tmp");
        }

        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            throw new RuntimeException("could not replace $path");
        }
    }

    private static function path(string $name): string
    {
        // The caller names a document, not a path. Anything else is a bug here,
        // not input to sanitise — but this file is one route away from a query
        // string, so it is checked rather than trusted.
        if (preg_match('/^[a-z0-9-]+$/', $name) !== 1) {
            throw new RuntimeException("invalid store name: $name");
        }

        return self::dir() . "/" . $name . ".json";
    }
}
